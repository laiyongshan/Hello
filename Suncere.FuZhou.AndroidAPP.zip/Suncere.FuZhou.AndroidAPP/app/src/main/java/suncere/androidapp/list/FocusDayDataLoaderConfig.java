package suncere.androidapp.list;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class FocusDayDataLoaderConfig extends DataLoaderConfigBase {

	@Override
	public String APIURL() {

//		http://218.5.4.125:18086/AQMFPWebAPI/api/Rank/GetAQRRPAAQIDatasAttension?codes=360100,110000,150900,654000
		return "Rank/GetAQRRPAAQIDatasAttensionByTime";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return FocusDayDataLoaderConfig.GET_ARRAY;
	}
}
