package suncere.androidapp.list;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import suncere.androidapp.attributes.AQIResConvertAttribute;
import suncere.androidapp.attributes.CheckerAttribute;
import suncere.androidapp.attributes.DateTimeConvertAttribute;
import suncere.androidapp.attributes.IClassAttribute;
import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.autobasemodule.LastTimePointChecker;
import suncere.androidapp.basemodule.BaseModel;
import suncere.fuzhou.androidapp.R;

/**
 * Created by Hjo on 2017/3/17.
 */

public class ListDataModel extends AutoBaseModel {
    private static ListDataModel _default=new ListDataModel();
    @Override
    protected void FillingFieldColumnMapping(HashMap<String, String> fieldColumnMapping) {

    }

    @Override
    protected void FillingFieldAtrributes(HashMap<String, List<Object>> fieldAtrributes) {

        this.BatchAddFieldAttribute("Code",//区分不同城市
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);

        this.BatchAddFieldAttribute("districtType",
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);

        this.BatchAddFieldAttribute("type",
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);

        this.BatchAddFieldAttribute("Time",
                this.TIMEPOINT_FIELD,
                new DateTimeConvertAttribute("putTime","MM月dd日" ));

        this.BatchAddFieldAttribute("Time",
                this.TIMEPOINT_FIELD,
                new DateTimeConvertAttribute("YearTime","yyyy-MM-dd日" ));

        List<Object> bgLst=new ArrayList<>();
        bgLst.add(R.drawable.round_rect_aqi_1);
        bgLst.add(R.drawable.round_rect_aqi_2);
        bgLst.add(R.drawable.round_rect_aqi_3);
        bgLst.add(R.drawable.round_rect_aqi_4);
        bgLst.add(R.drawable.round_rect_aqi_5);
        bgLst.add(R.drawable.round_rect_aqi_6);
        bgLst.add(R.drawable.round_rect_aqi_na);

        this.BatchAddFieldAttribute("AQI", new AQIResConvertAttribute("AQIBg",AQIResConvertAttribute.AQI,bgLst));
    }

    @Override
    public BaseModel GetDefaultInstance() {
        return _default;
    }

    @Override
    protected void FillingClassAttributes(List<IClassAttribute> collection)
    {
        collection.add(new CheckerAttribute( new LastTimePointChecker(-1,30,60) ));
    }
    @Override
    public String MappingTableName() {
        return "ListData";
    }

//    <AQRRPAAQIData>
//    <AQI>51</AQI>
//    <Code>360100</Code>
//    <Name>南昌市</Name>
//    <PrimaryPollutant>PM10</PrimaryPollutant>
//    <Rank>1</Rank>
//    <Time>2017-03-16T00:00:00</Time>
//    </AQRRPAAQIData>

    private String AQI;
    private String AQCI;
    private String Code;
    private String Name;
    private String PrimaryPollutant;
    private String Rank;
    private String Time;

    private String districtType;//区分不同的地区  关注城市0
    private String type;

    public String getAQCI() {
        return AQCI;
    }

    public void setAQCI(String AQCI) {
        this.AQCI = AQCI;
    }

    public String getDistrictType() {
        return districtType;
    }

    public void setDistrictType(String districtType) {
        this.districtType = districtType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    /***
 * 以下districtType 和  type  缺项补0
 * 日均：
 *         关注：
 *         全省：districtType=1
 *         全国：districtType=2
     *      74城市：districtType=3
 *
 * 月排：  关注：                 type=1
 *         全省：districtType=1   type=1
 *         全国：districtType=2   type=1
     *     74城市：districtType=3  type=1
 *
 * 年排：  关注：                 type=2
 *         全省：districtType=1   type=2
 *         全国：districtType=2   type=2
     * 自定义时间：  关注：                 type=3
     *                       全省：districtType=1   type=3
     *                       全国：districtType=2   type=3
     *                       74城市：districtType=3  type=3
     *
 */


    public String getAQI() {
        return AQI;
    }

    public void setAQI(String AQI) {
        this.AQI = AQI;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    public String getPrimaryPollutant() {
        return PrimaryPollutant;
    }

    public void setPrimaryPollutant(String primaryPollutant) {
        PrimaryPollutant = primaryPollutant;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        if (time!=null)time=time.replace("T"," ");
        Time = time;
    }

    public String getRank() {
        return Rank;
    }

    public void setRank(String rank) {
        Rank = rank;
    }
}
