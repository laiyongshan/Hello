package suncere.androidapp.live_chart30;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class DataLoaderConfig extends DataLoaderConfigBase {

	@Override
	public String APIURL() {

//
		return "AQIRPA/GetLast30DayAQIRPAChartDatas";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return DataLoaderConfig.GET_ARRAY;
	}
}
