package suncere.androidapp.focus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import suncere.androidapp.attributes.AQIResConvertAttribute;
import suncere.androidapp.attributes.CheckerAttribute;
import suncere.androidapp.attributes.DateTimeConvertAttribute;
import suncere.androidapp.attributes.IClassAttribute;
import suncere.androidapp.autobasemodule.AlwaysUpdateChecker;
import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.basemodule.BaseModel;
import suncere.fuzhou.androidapp.R;

/**
 * Created by Hjo on 2017/2/12.
 */
public class FocusModel extends AutoBaseModel {
    private static FocusModel _default=new FocusModel();
    @Override
    protected void FillingFieldColumnMapping(HashMap<String, String> fieldColumnMapping) {
    }

    @Override
    protected void FillingFieldAtrributes(HashMap<String, List<Object>> fieldAtrributes) {
        this.BatchAddFieldAttribute("Code",//区分不同城市
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);

        this.BatchAddFieldAttribute("Time",
                this.TIMEPOINT_FIELD,
                new DateTimeConvertAttribute("putTime","今天dd:00发布" ));

        List<Object> bgLst=new ArrayList<Object>();
        bgLst.add(R.drawable.round_rect_aqi_1);
        bgLst.add(R.drawable.round_rect_aqi_2);
        bgLst.add(R.drawable.round_rect_aqi_3);
        bgLst.add(R.drawable.round_rect_aqi_4);
        bgLst.add(R.drawable.round_rect_aqi_5);
        bgLst.add(R.drawable.round_rect_aqi_6);
        bgLst.add(R.drawable.round_rect_aqi_na);

        this.BatchAddFieldAttribute("DayAQI", new AQIResConvertAttribute("DayAQIBg",AQIResConvertAttribute.AQI,bgLst));
        this.BatchAddFieldAttribute("HourAQI", new AQIResConvertAttribute("HourAQIBg",AQIResConvertAttribute.AQI,bgLst));
    }
    @Override
    public BaseModel GetDefaultInstance() {
        return _default;
    }
    @Override
    protected void FillingClassAttributes(List<IClassAttribute>collection)
    {
        collection.add(new CheckerAttribute(  new AlwaysUpdateChecker()));
    }
    @Override
    public String MappingTableName()
    {
        return "Focus";
    }

//    <AQIRPAAttensionCityData>
//    <Code>110000</Code>
//    <DayAQI>54</DayAQI>
//    <HourAQI>82</HourAQI>
//    <Name>北京市</Name>
//    <Time>2017-03-15T17:00:00</Time>
//    </AQIRPAAttensionCityData>

    private String Code;
    private String DayAQI;
    private String HourAQI;
    private String Name;
    private String Time;

    @Override
    public String toString() {
        return "FocusModel{" +
                "Code='" + Code + '\'' +
                ", DayAQI='" + DayAQI + '\'' +
                ", HourAQI='" + HourAQI + '\'' +
                ", Name='" + Name + '\'' +
                ", Time='" + Time + '\'' +
                '}';
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    public String getDayAQI() {
        return DayAQI;
    }

    public void setDayAQI(String dayAQI) {
        DayAQI = dayAQI;
    }

    public String getHourAQI() {
        return HourAQI;
    }

    public void setHourAQI(String hourAQI) {
        HourAQI = hourAQI;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        if (time!=null)time=time.replace("T"," ");
        Time = time;
    }
}
