package suncere.androidapp.live_chart24;

import java.util.Date;
import java.util.HashMap;

import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.autobasemodule.INetDataHandler;
import suncere.androidapp.autobasemodule.NetDataHandlerContext;
import suncere.androidappcf.tools.DateTimeTool;

public class NetDataHandler implements INetDataHandler {
	NetDataHandlerContext dataHandlerContext;
	@Override
	public void SetContext(NetDataHandlerContext context) {
		this.dataHandlerContext=context;
	}

	@Override
	public void HandleNetData(AutoBaseModel model) {
		HashMap<String, Object> Parameters=dataHandlerContext.getOtherParameters();
		LiveChart24Model liveChart24Model=(LiveChart24Model)model;
		Date forTime= DateTimeTool.Prase(liveChart24Model.getTime());
		int temp=forTime.getHours();
		liveChart24Model.setTimeId(""+temp);
		liveChart24Model.setQuality(liveChart24Model.getIAQI());
		liveChart24Model.setYValue(liveChart24Model.getValue());
	}

}
