package suncere.androidapp.list;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class AQIDayDataLoaderConfig extends DataLoaderConfigBase {

	@Override
	public String APIURL() {

//		http://218.5.4.125:18086/AQMFPWebAPI/api/Rank/GetAQRRPAAQIDatas?districtType=1
//      http://218.5.4.125:18086/AQMFPWebAPI/api/Rank/GetAQRRPAAQIDatasByTime?time=2018-02&districtType=3&ConfigName=AQIMonthOrYear&Codes=350100&PackageName=suncere.androidapp.list
		return "Rank/GetAQRRPAAQIDatasByTime";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return AQIDayDataLoaderConfig.GET_ARRAY;
	}
}
