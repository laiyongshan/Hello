package suncere.androidapp.live;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import suncere.androidapp.attributes.AQIResConvertAttribute;
import suncere.androidapp.attributes.CheckerAttribute;
import suncere.androidapp.attributes.DateTimeConvertAttribute;
import suncere.androidapp.attributes.IClassAttribute;
import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.autobasemodule.LastTimePointChecker;
import suncere.androidapp.basemodule.BaseModel;
import suncere.fuzhou.androidapp.R;

/**
 * Created by Hjo on 2017/2/12.
 */
public class LiveStationModel extends AutoBaseModel {
    private static LiveStationModel _default=new LiveStationModel();
    @Override
    protected void FillingFieldColumnMapping(HashMap<String, String> fieldColumnMapping) {
    }

    @Override
    protected void FillingFieldAtrributes(HashMap<String, List<Object>> fieldAtrributes) {
        this.BatchAddFieldAttribute("Code",//区分不同站点
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);

        this.BatchAddFieldAttribute("Time",
                this.TIMEPOINT_FIELD,
                new DateTimeConvertAttribute("putTime","今天HH时发布" ));


        List<Object> bgLst=new ArrayList<Object>();
        bgLst.add(R.drawable.round_rect_aqi_1);
        bgLst.add(R.drawable.round_rect_aqi_2);
        bgLst.add(R.drawable.round_rect_aqi_3);
        bgLst.add(R.drawable.round_rect_aqi_4);
        bgLst.add(R.drawable.round_rect_aqi_5);
        bgLst.add(R.drawable.round_rect_aqi_6);
        bgLst.add(R.drawable.round_rect_aqi_na);

        this.BatchAddFieldAttribute("AQI", new AQIResConvertAttribute("aqiBg",AQIResConvertAttribute.AQI,bgLst));
        this.BatchAddFieldAttribute("ISO2", new AQIResConvertAttribute("so2Bg",AQIResConvertAttribute.AQI,bgLst));
        this.BatchAddFieldAttribute("ICO", new AQIResConvertAttribute("coBg",AQIResConvertAttribute.AQI,bgLst));
        this.BatchAddFieldAttribute("INO2", new AQIResConvertAttribute("no2Bg",AQIResConvertAttribute.AQI,bgLst));
        this.BatchAddFieldAttribute("IO3", new AQIResConvertAttribute("o3Bg",AQIResConvertAttribute.AQI,bgLst));
        this.BatchAddFieldAttribute("IPM25", new AQIResConvertAttribute("pm2_5Bg",AQIResConvertAttribute.AQI,bgLst));
        this.BatchAddFieldAttribute("IPM10", new AQIResConvertAttribute("pm10Bg",AQIResConvertAttribute.AQI,bgLst));
    }
    @Override
    public BaseModel GetDefaultInstance() {
        return _default;
    }
    @Override
    protected void FillingClassAttributes(List<IClassAttribute>collection)
    {
        collection.add(new CheckerAttribute( new LastTimePointChecker(-1,30,60) ));
    }
    @Override
    public String MappingTableName()
    {
        return "LiveStation";
    }

//    <AQIRPADetailData>
//    <AQI>41</AQI>
//    <CO>0.4</CO>
//    <Code>350100</Code>
//    <Effect>空气质量令人满意，基本无空气污染</Effect>
//    <ICO>4</ICO>
//    <INO2>9</INO2>
//    <IO3>36</IO3>
//    <IPM10>41</IPM10>
//    <IPM25>29</IPM25>
//    <ISO2>9</ISO2>
//    <Measure>各类人群可正常活动</Measure>
//    <NO2>18</NO2>
//    <Name>福州市</Name>
//    <O3>113</O3>
//    <PM10>41</PM10>
//    <PM25>20</PM25>
//    <PrimaryPollutant>—</PrimaryPollutant>
//    <SO2>25</SO2>
//    <Time>2017-03-15T13:00:00</Time>
//    <Type>优</Type>
//    </AQIRPADetailData>
        private String Code;
        private String Name;
        private String Time;
        private String SO2;
        private String NO2;

        private String PM10;
        private String CO;
        private String  O3;
        private String PM25;
        private String ISO2;

        private String INO2;
        private String IPM10;
        private String ICO;
        private String IO3;
        private String IPM25;

        private String AQI;
        private String PrimaryPollutant;
        private String Type;
        private String Effect;
        private String Measure;

    @Override
    public String toString() {
        return "LiveStationModel{" +
                "Code='" + Code + '\'' +
                ", Name='" + Name + '\'' +
                ", Time='" + Time + '\'' +
                ", SO2='" + SO2 + '\'' +
                ", NO2='" + NO2 + '\'' +
                ", PM10='" + PM10 + '\'' +
                ", CO='" + CO + '\'' +
                ", O3='" + O3 + '\'' +
                ", PM25='" + PM25 + '\'' +
                ", ISO2='" + ISO2 + '\'' +
                ", INO2='" + INO2 + '\'' +
                ", IPM10='" + IPM10 + '\'' +
                ", ICO='" + ICO + '\'' +
                ", IO3='" + IO3 + '\'' +
                ", IPM25='" + IPM25 + '\'' +
                ", AQI='" + AQI + '\'' +
                ", PrimaryPollutant='" + PrimaryPollutant + '\'' +
                ", Type='" + Type + '\'' +
                ", Effect='" + Effect + '\'' +
                ", Measure='" + Measure + '\'' +
                '}';
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        Code = code;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getSO2() {
        return SO2;
    }

    public void setSO2(String SO2) {
        this.SO2 = SO2;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }

    public String getNO2() {
        return NO2;
    }

    public void setNO2(String NO2) {
        this.NO2 = NO2;
    }

    public String getPM10() {
        return PM10;
    }

    public void setPM10(String PM10) {
        this.PM10 = PM10;
    }

    public String getCO() {
        return CO;
    }

    public void setCO(String CO) {
        this.CO = CO;
    }

    public String getO3() {
        return O3;
    }

    public void setO3(String o3) {
        O3 = o3;
    }

    public String getPM25() {
        return PM25;
    }

    public void setPM25(String PM25) {
        this.PM25 = PM25;
    }

    public String getISO2() {
        return ISO2;
    }

    public void setISO2(String ISO2) {
        this.ISO2 = ISO2;
    }

    public String getINO2() {
        return INO2;
    }

    public void setINO2(String INO2) {
        this.INO2 = INO2;
    }

    public String getIPM10() {
        return IPM10;
    }

    public void setIPM10(String IPM10) {
        this.IPM10 = IPM10;
    }

    public String getIO3() {
        return IO3;
    }

    public void setIO3(String IO3) {
        this.IO3 = IO3;
    }

    public String getICO() {
        return ICO;
    }

    public void setICO(String ICO) {
        this.ICO = ICO;
    }

    public String getAQI() {
        return AQI;
    }

    public void setAQI(String AQI) {
        this.AQI = AQI;
    }

    public String getIPM25() {
        return IPM25;
    }

    public void setIPM25(String IPM25) {
        this.IPM25 = IPM25;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getEffect() {
        return Effect;
    }

    public void setEffect(String effect) {
        Effect = effect;
    }

    public String getPrimaryPollutant() {
        return PrimaryPollutant;
    }

    public void setPrimaryPollutant(String primaryPollutant) {
        PrimaryPollutant = primaryPollutant;
    }

    public String getMeasure() {
        return Measure;
    }

    public void setMeasure(String measure) {
        Measure = measure;
    }
}
