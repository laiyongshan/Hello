package suncere.androidapp.forecast;

import java.util.HashMap;
import java.util.List;

import suncere.androidapp.attributes.CheckerAttribute;
import suncere.androidapp.attributes.IClassAttribute;
import suncere.androidapp.autobasemodule.AlwaysUpdateChecker;
import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.basemodule.BaseModel;

/**
 * Created by Hjo on 2017/2/12.
 */
public class ForecastContentModel extends AutoBaseModel {
    private static ForecastContentModel _default=new ForecastContentModel();
    @Override
    protected void FillingFieldColumnMapping(HashMap<String, String> fieldColumnMapping) {
    }

    @Override
    protected void FillingFieldAtrributes(HashMap<String, List<Object>> fieldAtrributes) {
        this.BatchAddFieldAttribute("Id",//区分不同城市
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);
    }
    @Override
    public BaseModel GetDefaultInstance() {
        return _default;
    }
    @Override
    protected void FillingClassAttributes(List<IClassAttribute>collection)
    {
        collection.add(new CheckerAttribute(  new AlwaysUpdateChecker()));
    }
    @Override
    public String MappingTableName()
    {
        return "ForecastContent";
    }

//    <PubTime>2017-03-13T15:00:58.387</PubTime>
//    <Survey>
//    <p> &nbsp; 3月14日，空气质量为优~良，空气质量指数为45~75，首要污染物为细颗粒物(PM<sub>2.5</sub>)。 </p> <p> &nbsp; 3月15日，空气质量为优~良，空气质量指数为44~74，首要污染物为细颗粒物(PM<sub>2.5</sub>)。 </p>
//    </Survey>
//    <TimePoint>2017-03-13T00:00:00</TimePoint>

    private String PubTime;
    private String Survey;
    private String TimePoint;

    private String Id;

    @Override
    public String toString() {
        return "LiveChart30Model{" +
                "PubTime='" + PubTime + '\'' +
                ", Survey='" + Survey + '\'' +
                ", TimePoint='" + TimePoint + '\'' +
                ", Id='" + Id + '\'' +
                '}';
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }




    public String getPubTime() {
        return PubTime;
    }

    public void setPubTime(String pubTime) {
        if (pubTime!=null)pubTime=pubTime.replace("T"," ");
        PubTime = pubTime;
    }

    public String getSurvey() {
        return Survey;
    }

    public void setSurvey(String survey) {
        Survey = survey;
    }

    public String getTimePoint() {
        return TimePoint;
    }

    public void setTimePoint(String timePoint) {
        if (timePoint!=null)timePoint=timePoint.replace("T"," ");
        TimePoint = timePoint;
    }
}
