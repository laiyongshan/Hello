package suncere.androidapp.list;

import java.util.HashMap;

import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.autobasemodule.INetDataHandler;
import suncere.androidapp.autobasemodule.NetDataHandlerContext;

public class NetDataHandler implements INetDataHandler {
	NetDataHandlerContext dataHandlerContext;
	@Override
	public void SetContext(NetDataHandlerContext context) {
		// TODO Auto-generated method stub
		this.dataHandlerContext=context;
	}

	@Override
	public void HandleNetData(AutoBaseModel model) {
		// TODO Auto-generated method stub
		
		HashMap<String, Object> Parameters=dataHandlerContext.getOtherParameters();
		ListDataModel listDataModel= (ListDataModel) model;
		listDataModel.setType(Parameters.get("type").toString());
		listDataModel.setDistrictType(Parameters.get("districtType").toString());
		if (listDataModel.getAQI()==null){
			listDataModel.setAQI(listDataModel.getAQCI());
		}


	}

}
