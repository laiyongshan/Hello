package suncere.androidapp.live_chart30;

import java.util.HashMap;
import java.util.List;

import suncere.androidapp.attributes.CheckerAttribute;
import suncere.androidapp.attributes.DateTimeConvertAttribute;
import suncere.androidapp.attributes.IClassAttribute;
import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.autobasemodule.LastTimePointChecker;
import suncere.androidapp.basemodule.BaseModel;

/**
 * Created by Hjo on 2017/3/15.
 */
public class LiveChart30Model extends AutoBaseModel {
    private static LiveChart30Model _default=new LiveChart30Model();
    @Override
    protected void FillingFieldColumnMapping(HashMap<String, String> fieldColumnMapping) {
    }

    @Override
    protected void FillingFieldAtrributes(HashMap<String, List<Object>> fieldAtrributes) {

        this.BatchAddFieldAttribute("Code",//区分不同城市
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);

        this.BatchAddFieldAttribute("Type",//区分不同污染物
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION,
                this.LASTTIME_CONDITION);

        this.BatchAddFieldAttribute("Time",
                this.TIMEPOINT_FIELD,
                new DateTimeConvertAttribute("LabelXValue","dd日" ));

        this.BatchAddFieldAttribute("timeId",//区分不同时间
                this.UPDATE_CONDISTION,
                this.DELETE_CONDITION,
                this.EXIST_CONDISTION);

    }
    @Override
    public BaseModel GetDefaultInstance() {
        return _default;
    }

    @Override
    protected void FillingClassAttributes(List<IClassAttribute>collection)
    {
        collection.add(new CheckerAttribute( new LastTimePointChecker(-1,30,60) ));
//        collection.add(new CheckerAttribute(  new AlwaysUpdateChecker()));
    }


    @Override
    public String MappingTableName()
    {
        return "LiveChart30";
    }

    private String Code;

    private String Time;


    private String YValue;
    private String Quality;


    private String Type;

    private String timeId;

    private String Value;
    private String IAQI;

    @Override
    public String toString() {
        return "LiveChart30Model{" +
                "Code='" + Code + '\'' +
                ", Time='" + Time + '\'' +
                ", YValue='" + YValue + '\'' +
                ", Quality='" + Quality + '\'' +
                ", Type='" + Type + '\'' +
                ", timeId='" + timeId + '\'' +
                ", Value='" + Value + '\'' +
                ", IAQI='" + IAQI + '\'' +
                '}';
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }

    public String getIAQI() {
        return IAQI;
    }

    public void setIAQI(String IAQI) {
        this.IAQI = IAQI;
    }

    public String getTimeId() {
        return timeId;
    }

    public void setTimeId(String timeId) {
        this.timeId = timeId;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String code) {
        this.Code = code;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        if (time!=null)time=time.replace("T"," ");
        this.Time = time;
    }

    public String getYValue() {
        return YValue;
    }

    public void setYValue(String YValue) {
        this.YValue = YValue;
    }

    public String getQuality() {
        return Quality;
    }

    public void setQuality(String quality) {
        Quality = quality;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        this.Type = type;
    }

    }



