package suncere.androidapp.list;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class AQIMonthOrYearDataLoaderConfig extends DataLoaderConfigBase {

	@Override
	public String APIURL() {

//		http://218.5.4.125:18086/AQMFPWebAPI/api/Rank/GetAQRRPAAQCIDatas?districtType=1&type=1
//		http://218.5.4.125:18086/AQMFPWebAPI/api/Rank/GetAQRRPAAQIDatasByTime?time=2018-02&districtType=3&ConfigName=AQIMonthOrYear&Codes=350100&PackageName=suncere.androidapp.list
		return "Rank/GetAQRRPAAQCIDatasByTime";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return AQIMonthOrYearDataLoaderConfig.GET_ARRAY;
	}
}
