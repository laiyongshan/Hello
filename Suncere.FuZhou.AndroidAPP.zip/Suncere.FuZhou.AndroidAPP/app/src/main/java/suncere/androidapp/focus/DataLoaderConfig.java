package suncere.androidapp.focus;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class DataLoaderConfig extends DataLoaderConfigBase {

	@Override
	public String APIURL() {

//		http://218.5.4.125:18086/AQMFPWebAPI/api/AQIRPA/GetAQIRPAAttensionCityDatas?codes=360100,110000,150900,654000
		return "AQIRPA/GetAQIRPAAttensionCityDatas";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return DataLoaderConfig.GET_ARRAY;
	}

}
