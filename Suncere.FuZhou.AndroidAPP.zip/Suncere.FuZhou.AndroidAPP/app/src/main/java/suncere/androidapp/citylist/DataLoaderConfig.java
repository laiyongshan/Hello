package suncere.androidapp.citylist;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class DataLoaderConfig  extends DataLoaderConfigBase {

	@Override
	public String APIURL() {
//		http://115.149.145.50:8089/AQMFPWebAPI/api/System/GetCityCoordinates
		return "System/GetCityCoordinates";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return DataLoaderConfig.GET_ARRAY;
	}
}
