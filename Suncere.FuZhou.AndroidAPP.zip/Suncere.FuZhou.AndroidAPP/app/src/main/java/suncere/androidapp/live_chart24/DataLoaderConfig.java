package suncere.androidapp.live_chart24;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class DataLoaderConfig extends DataLoaderConfigBase {

	@Override
	public String APIURL() {

//		http://218.5.4.125:18086/AQMFPWebAPI/api/AQIRPA/GetLast24HourAQIRPAChartDatas?code=350100&type=AQI
//		http://218.5.4.125:18086/AQMFPWebAPI/api/AQIRPA/GetLast24HourAQIRPA5MinChartDatas?code=350100061&type=SO2  当前使用
		return "AQIRPA/GetLast24HourAQIRPA5MinChartDatas";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return DataLoaderConfig.GET_ARRAY;
	}
}
