package suncere.androidapp.forecast;

import suncere.androidapp.autobasemodule.DataLoaderConfigBase;

public class DataLoaderConfig extends DataLoaderConfigBase {

	@Override
	public String APIURL() {

//		http://218.5.4.125:18086/AQMFPWebAPI/api/Forecast/GetForecastSurvey
		return "Forecast/GetForecastSurvey";
	}

	@Override
	public int LoadDataType() {
		// TODO Auto-generated method stub
		return DataLoaderConfig.GET_SINGLE;
	}
}
