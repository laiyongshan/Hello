package suncere.androidapp.citylist;

import java.util.HashMap;
import java.util.List;

import suncere.androidapp.attributes.CheckerAttribute;
import suncere.androidapp.attributes.IClassAttribute;
import suncere.androidapp.autobasemodule.AlwaysUpdateChecker;
import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.basemodule.BaseModel;

public class CityListModel extends AutoBaseModel {

	private static CityListModel _default=new CityListModel();
	
	
	@Override
	protected void FillingFieldColumnMapping(
			HashMap<String, String> fieldColumnMapping) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void FillingFieldAtrributes(
			HashMap<String, List<Object>> fieldAtrributes) {
		// TODO Auto-generated method stub
		this.BatchAddFieldAttribute("Code", 
				this.UPDATE_CONDISTION,
				this.DELETE_CONDITION,
				this.EXIST_CONDISTION,
				this.LASTTIME_CONDITION);	
	}

	@Override
	public BaseModel GetDefaultInstance() {
		
		return _default;
	}
	
	@Override
	protected void FillingClassAttributes(List<IClassAttribute>collection)
	{
		collection.add(new CheckerAttribute(  new AlwaysUpdateChecker() ));
//		collection.add( new IsReturnData(true) );//�����Ƿ񷵻ػ�������
	}
	
	public String MappingTableName()
	{
		return "CityList";
	}
	
//	<CityCoordinate>
//	<Code>130400</Code>
//	<Id>6</Id>
//	<Latitude>36.609</Latitude>
//	<Longitude>114.483</Longitude>
//	<Name>������</Name>
//	</CityCoordinate>
	
	private String Code;
	private String Id;
	private String Latitude;
	private String Longitude;
	private String Name;

	
	

	@Override
	public String toString() {
		return "CityListModel [Code=" + Code + ", Id=" + Id + ", Latitude="
				+ Latitude + ", Longitude=" + Longitude + ", Name=" + Name
				+ "]";
	}

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		Code = code;
	}

	public String getId() {
		return Id;
	}

	public void setId(String id) {
		Id = id;
	}

	public String getLatitude() {
		return Latitude;
	}

	public void setLatitude(String latitude) {
		Latitude = latitude;
	}

	public String getLongitude() {
		return Longitude;
	}

	public void setLongitude(String longitude) {
		Longitude = longitude;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	
	



}
