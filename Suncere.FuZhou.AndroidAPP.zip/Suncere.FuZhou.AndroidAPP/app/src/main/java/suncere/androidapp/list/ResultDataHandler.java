package suncere.androidapp.list;

import android.graphics.Color;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;

import suncere.androidapp.autobasemodule.IResultDataHandler;
import suncere.androidapp.autobasemodule.ResultDataHandlerContext;
import suncere.fuzhou.androidapp.AppParameters;


public class ResultDataHandler implements IResultDataHandler {

	ResultDataHandlerContext context;
	@Override
	public void SetContext(ResultDataHandlerContext context) {
		this.context=context;
	}

	@Override
	public void HandleResultData(List<HashMap<String, Object>> data) {

			CitySortComparator comparator=new CitySortComparator(true);
			Collections.sort(data,comparator);

		for(int i=0;i<data.size();i++)
		{
//			if (data.get(i).get("AQI")==null){
//				data.get(i).remove("AQI");
//				data.get(i).put("AQI",data.get(i).get("AQCI"));
//			}
			if(data.get(i).get("Name").equals(AppParameters.MainCityName))
			{
				data.get(i).put("bgColor", Color.argb(100, 100, 100, 100));
			}
			else
			{
				data.get(i).put("bgColor", Color.TRANSPARENT);
			}
		}
	}

	class CitySortComparator implements Comparator<HashMap<String,Object>> {

		boolean isASC;
		public CitySortComparator(boolean isASC)
		{
			this.isASC=isASC;
		}
		
		@Override
		public int compare(HashMap<String, Object> lhs, HashMap<String, Object> rhs) {
			// TODO Auto-generated method stub
			
			HashMap<String, Object> before=this.isASC?lhs:rhs;
			HashMap<String, Object> after=this.isASC?rhs:lhs;
			
			int flag=(Integer.valueOf(before.get("Rank").toString()) ).compareTo(  Integer.valueOf( after.get("Rank").toString()) );
			if(flag==0)
				return before.get("Name").toString().compareTo(after.get("Name").toString());
			
			return flag;
		}
	}
}
