package suncere.androidapp.live_chart30;

import java.util.Date;
import java.util.HashMap;

import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.autobasemodule.INetDataHandler;
import suncere.androidapp.autobasemodule.NetDataHandlerContext;
import suncere.androidappcf.tools.DateTimeTool;

public class NetDataHandler implements INetDataHandler {
	NetDataHandlerContext dataHandlerContext;
	@Override
	public void SetContext(NetDataHandlerContext context) {
		// TODO Auto-generated method stub
		this.dataHandlerContext=context;
	}

	@Override
	public void HandleNetData(AutoBaseModel model) {
		// TODO Auto-generated method stub
		
		HashMap<String, Object> Parameters=dataHandlerContext.getOtherParameters();
		LiveChart30Model liveChart30Model=(LiveChart30Model)model;
		Date forTime= DateTimeTool.Prase(liveChart30Model.getTime());
		int temp=forTime.getDay();
		liveChart30Model.setTimeId(""+temp);
		liveChart30Model.setQuality(liveChart30Model.getIAQI());
		liveChart30Model.setYValue(liveChart30Model.getValue());
	}

}
