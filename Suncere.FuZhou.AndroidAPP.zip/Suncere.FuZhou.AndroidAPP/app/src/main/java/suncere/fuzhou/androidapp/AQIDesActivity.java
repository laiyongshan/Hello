package suncere.fuzhou.androidapp;

import android.view.View;

import java.util.HashMap;
import java.util.List;

import suncere.androidappcf.app.SuncereAutoActivity;

public class AQIDesActivity extends SuncereAutoActivity {

	@Override
	public int OnGetContentView() {
		// TODO Auto-generated method stub
		return R.layout.aqi_des_act;
	}

	@Override
	public void InitViews() {
		// TODO Auto-generated method stub
	}

	@Override
	public void RegistQueryModels() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void SetQueryParameter(
			HashMap<String, Object[]> queryModelCollection) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void BindData(
			HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {
		// TODO Auto-generated method stub
		
	}

	public void On_btnBack_Click(View sender)
	{
		this.finish();
	}
}
