package suncere.fuzhou.androidapp;

import suncere.androidappcf.app.SuncereAppParameters;

public class AppParameters extends SuncereAppParameters {

	protected static Class<?> Class()
	{
		return AppParameters.class;
	}

	@Override
	protected void IniParameters() {
		//测试：
		//正式  http://218.5.4.125:18086/AQMFPWebAPI
		if(ServerIpPort==null|| ServerIpPort=="") ServerIpPort="218.5.4.125:18086/AQMFPWebAPI";
		if(DbVersion==0)DbVersion=1;
		if(DbName==null||DbName.length()>0)DbName="FuZhou";
		if(AssetsDbFileName==null||AssetsDbFileName.length()>0)AssetsDbFileName="fuzhou.db";
		if(MainCityName==null||MainCityName.length()>0)MainCityName="福州市";
	}
	
}
