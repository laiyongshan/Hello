package suncere.fuzhou.androidapp;

import suncere.androidappcf.controls.SuncereLanuchActivity;
import suncere.fuzhou.others.Tools;

public class LanuchActivity extends SuncereLanuchActivity {

	@Override
	protected int ContentImageView() {

		return R.mipmap.luanch;
	}

	@Override
	protected Class<?> LanuchFinishView() {
		

		if (Tools.getInstance().getIsFristTime(this)) {
			return WelcomeActivity.class;
		}else {
			return MainActivity.class;
		}
		
	}

	@Override
	protected String ApkFileName() {
		return "Suncere.FuZhou.AndroidApp.apk";
	}

	protected boolean EnableUpdate()
	{
		return false;
	}
}
