package suncere.fuzhou.androidapp;

import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.autobasemodule.AutoBaseBLL;
import suncere.androidapp.autobasemodule.PluginLoader;
import suncere.androidapp.citylist.CityListModel;
import suncere.androidapp.focus.FocusModel;
import suncere.androidappcf.app.SuncereAppParameters;
import suncere.androidappcf.app.SuncereAutoActivity;
import suncere.androidappcf.controls.MyPinYinIndexListView;
import suncere.fuzhou.others.FocusDAL;

/**
 * Created by Hjo on 2017/3/16.
 */
public class FocusAddCityAcitvity extends SuncereAutoActivity {

    List<HashMap<String,Object>> mforecastdatasources;//添加或删除数据之 前 已经关注的城市列表
    List<HashMap<String,Object>>addOrdelectFocusData;//添加或删除数据之 后 已经关注的城市列表
    List<HashMap<String,Object>>  datasources;
    StringBuffer mfocusCodes;
    FocusDAL mFocusDAL;

    boolean isIntothisView=true;

    @BindView(R.id.focus_add_CityLst)
    MyPinYinIndexListView myPinYinIndexListView;

    @Override
    public int OnGetContentView() {
        return R.layout.focus_addcity_act;
    }

    @Override
    public void InitViews() {
        ButterKnife.bind(this);
        getForecastSQLData();
        myPinYinIndexListView.SetDataSource(getSQLCityData());
        addOrdelectFocusData=new ArrayList<>();
        mFocusDAL=new FocusDAL(this);
        mfocusCodes=new StringBuffer();
    }

    @Override
    public void RegistQueryModels() {
        RegistQueryModel("focus",FocusModel.class);
    }


    @Override
    public void SetQueryParameter(HashMap<String, Object[]> queryModelCollection) {
    HashMap<String,Object>addcity= (HashMap<String, Object>) queryModelCollection.get("focus")[1];
        if (mfocusCodes!=null)
        addcity.put("&Codes",mfocusCodes.toString());
    }

    @Override
    public void BindData(HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {
        Log.e("FocusAddCityAcitvity","添加的城市:"+datasourceCollection.get("focus").toString());
    }

    @OnClick({R.id.focus_add_titleBtnCancle,R.id.focus_add_titleBtnSure})
    public void On_Click_Cancle_Or_Sure(View view ){
        switch (view.getId()){
            case R.id.focus_add_titleBtnCancle:
                finish();;
                break;
            case R.id.focus_add_titleBtnSure:
                for (HashMap<String ,Object>item :datasources ){//获取添加或删除城市之后的关注城市列表
                    if (!item.containsKey(MyPinYinIndexListView.ShowKey))continue;
                    else{
                        if ((boolean) item.get(MyPinYinIndexListView.ShowKey)) {
                            addOrdelectFocusData.add(item);
                        }
                    }
                }
                /****先将关注表里的所有数据删除  再添加***/
                mFocusDAL.delectFocusCity(mforecastdatasources); //删除城市
                for (int i=0;i<addOrdelectFocusData.size();i++){
                    if(i==0){
                        mfocusCodes.append("350100,");
                    }
                    if (i<addOrdelectFocusData.size()-1){
                            mfocusCodes.append(addOrdelectFocusData.get(i).get("Code")+",");
                    }else
                            mfocusCodes.append(addOrdelectFocusData.get(i).get("Code"));
                    }
                    isIntothisView=false;
                    RefreshViewData();
                break;


//                int oldSize=mforecastdatasources.size();
//                int newSize=addOrdelectFocusData.size();
//                if (oldSize>newSize){//删除关注城市
//                    for (int i=0;i<addOrdelectFocusData.size();i++){ // 查找删除的城市
//                        for(int j=0;j<mforecastdatasources.size();j++){
//                            if("350100".equals(mforecastdatasources.get(j).get("Code")))continue;//不删除福州市
//                            if (mforecastdatasources.get(j).get("Code").equals(addOrdelectFocusData.get(i).get("Code"))){
//                                mforecastdatasources.remove(j);
//                                break;
//                            }
//                        }
//                    }
//                    mFocusDAL.delectFocusCity(mforecastdatasources); //删除城市
//                    finish();
//                }else if (oldSize<newSize){//添加关注城市
//                    for (int i=0;i<mforecastdatasources.size();i++){
//                        for(int j=0;j<addOrdelectFocusData.size();j++){//查找添加的城市
//                            if (addOrdelectFocusData.get(j).get("Code").equals(mforecastdatasources.get(i).get("Code"))){
//                                addOrdelectFocusData.remove(j);
//                                break;
//                            }
//                        }
//                    }
//
//                    for (int i=0;i<addOrdelectFocusData.size();i++){
//                        if (i<addOrdelectFocusData.size()-1){
//                            mfocusCodes.append(addOrdelectFocusData.get(i).get("Code")+",");
//                        }else
//                            mfocusCodes.append(addOrdelectFocusData.get(i).get("Code"));
//                    }
//                    isIntothisView=false;
//                    RefreshViewData();
//                }else{
//                finish();
//            }
//                break;
        }
    }


    //获取全国城市列表
    public List<HashMap<String,Object>>  getSQLCityData(){
          datasources=new ArrayList<>();
        CityListModel model=new CityListModel();
        AutoBaseBLL autoBaseBLL= PluginLoader.Current().InitPlugin(model) ;
        List<HashMap<String,Object>> datas= autoBaseBLL.GetCacheData(null);
        if (datas!=null && datas.size()>0){
            HashMap<String,Object> hashMap;
            for (HashMap<String,Object> itme : datas){
                hashMap=new HashMap<String,Object>();
                if (itme.get("Name").equals(SuncereAppParameters.MainCityName)) continue;//关注的城市列表中  不包含福州市
                hashMap.put(MyPinYinIndexListView.CityNameKey,itme.get("Name"));
                hashMap.put(MyPinYinIndexListView.CheckKey,isHasForecastCity(itme.get("Name").toString()));
                hashMap.put("Code",itme.get("Code"));
                datasources.add(hashMap);
            }
        }
        return datasources;
    }

    //获取已经关注城市的列表
    public  List<HashMap<String,Object>> getForecastSQLData(){
      mforecastdatasources=new ArrayList<>();
        FocusModel model=new FocusModel();
        StringBuffer sb=new StringBuffer();
        AutoBaseBLL autoBaseBLL= PluginLoader.Current().InitPlugin(model) ;
        List<HashMap<String,Object>> datas= autoBaseBLL.GetCacheData(null);
        if ( datas!=null && datas.size()>0 ){
            mforecastdatasources.clear();
            mforecastdatasources.addAll(datas);
        }
        return  mforecastdatasources;
    }

    /**
     * 查找已经关注的城市列表
     * @param cityName
     * @return
     */
    public boolean isHasForecastCity(String  cityName){
        for (HashMap<String,Object>itme : mforecastdatasources){
            if (itme.get("Name").equals(cityName))
                return true;
        }
        return false;
    }

    @Override
    public void RefreshViewData() {
        super.RefreshViewData();
    }

    @Override
    public void OnAsyncLoadPostExecute() {
        if (!isIntothisView)
       finish();
    }
}
