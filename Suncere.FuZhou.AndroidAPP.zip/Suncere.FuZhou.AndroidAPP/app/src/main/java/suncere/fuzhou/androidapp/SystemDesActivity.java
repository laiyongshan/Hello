package suncere.fuzhou.androidapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class SystemDesActivity  extends Activity
{

	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.system_des_act);
	}
	
	public void  On_btnBack_Click(View sender)
	{
		this.finish();
	}
	
}
