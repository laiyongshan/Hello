package suncere.fuzhou.androidapp;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

import suncere.androidappcf.app.SuncereAutoFragment;
import suncere.androidappcf.components.UpdateManager;
import suncere.androidappcf.controls.TipView;

/**
 * Created by Hjo on 2017/3/14.
 */
public class SetFragment extends SuncereAutoFragment {


    View palOption;//操作说明
    View palUpdate;//更新
    View palAbout;//关于
    View palAirDes;//空气污染级别说明
    View palSysDes;//系统说明
    AlertDialog dialog;
    TipView tip;

    UpdateManager updateManager;
    ProgressDialog proDialog;//载入对话框

    @Override
    public int OnGetContentView() {
        return R.layout.set_fragment;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @SuppressLint("NewApi")
    @Override
    public void InitViews() {

        palOption=this.findViewById(R.id.sfMenuItemOption);
        palUpdate=this.findViewById(R.id.sfMenuItemUpdate);
        palAbout=this.findViewById(R.id.sfMenuItmeAbout);
        palAirDes=this.findViewById(R.id.sfMenuItemAirDes);
        palSysDes=this.findViewById(R.id.sfMenuItemSysDes);


        palOption.setOnClickListener(On_Option_Click);
        palUpdate.setOnClickListener(On_Update_Click);
        palAbout.setOnClickListener(On_About_Click);
        palAirDes.setOnClickListener(On_AirDes_Click);
        palSysDes.setOnClickListener(On_SysDes_Click);

        tip=new TipView(this.getActivity(),R.layout.tip_view);
        if(updateManager==null)
        {
            updateManager=  new UpdateManager(this.getActivity(),"Suncere.NanChang.AndroidApp.apk","suncere.nanchang.androidapp");

        }
    }

    @Override
    public void RegistQueryModels() {
        // TODO Auto-generated method stub
    }

    @Override
    public void SetQueryParameter(
            HashMap<String, Object[]> queryModelCollection) {
        // TODO Auto-generated method stub

    }

    @Override
    public void BindData(
            HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {
        // TODO Auto-generated method stub

    }
    OnClickListener On_Option_Click=new  OnClickListener()
    {

        @Override
        public void onClick(View arg0)
        {
            startActivity(new Intent(getActivity(),AppDesActivity.class));
        }
    };


    OnClickListener On_Update_Click=new OnClickListener()
    {


        public void onClick(View arg0)
        {
            ///更新
//			((MainActivity) SettingView.this.getContext()).CheckUpdate();
            proDialog=ProgressDialog.show(getActivity()  , "检查更新", "请稍候",true);
            proDialog.setCancelable(true);
            new UpdateTask().execute();
        }

    };


    OnClickListener On_About_Click=new OnClickListener()
    {

        @Override
        public void onClick(View arg0)
        {
            ((TextView)tip.findViewById(R.id.version_name_tv)).setText("Version   "+updateManager.getVersionName(getActivity()));
            tip.show();
        }

    };


    OnClickListener On_AirDes_Click=new OnClickListener(){


        @Override
        public void onClick(View arg0) {
            Intent intent=new Intent(getActivity(),AQIDesActivity.class);
            startActivity(intent);
        }};


    OnClickListener On_SysDes_Click=new OnClickListener(){

        @SuppressLint("NewApi")
        @Override
        public void onClick(View arg0) {
            Intent intent=new Intent(getActivity(),SystemDesActivity.class);
            startActivity(intent);
        }};

    class UpdateTask extends AsyncTask<Void,Void,Boolean>
    {

        @Override
        public Boolean doInBackground(Void... arg0) {
            // TODO Auto-generated method stub
//		   119.146.144.57:9000/AQMPA/api/Update/GetAndroidAPKUpdate?version=1.0.0
//            http://218.5.4.125:18086/AQMFPWebAPI/api/Update/GetAndroidAPKUpdate?version=1.0.0
            return updateManager.isUpdate( "http://"+ AppParameters.ServerIpPort+"/api/Update/GetAndroidAPKUpdate?version="+updateManager.getVersionCode()  );
        }

        @SuppressLint("NewApi")
        public void onPostExecute(Boolean hasUpdate)
        {
            proDialog.dismiss();
            if(hasUpdate)
                updateManager.showNoticeDialog();
            else
            {
                new AlertDialog.Builder(getActivity()).setMessage("暂未发现新版本").setNegativeButton("确定", new AlertDialog.OnClickListener(){

                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                        arg0.dismiss();
                    }}).create().show();

            }

        }
    }

}

