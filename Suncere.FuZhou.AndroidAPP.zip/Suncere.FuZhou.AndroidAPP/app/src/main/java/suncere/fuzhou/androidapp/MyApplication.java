package suncere.fuzhou.androidapp;

import suncere.androidappcf.controls.SuncereApplication;

public class MyApplication  extends SuncereApplication {

	@Override
	protected void IniAppParameter() {
		AppParameters.Init( AppParameters.class );
	}
	
	
	public Integer ThreadPoolSize()
	{
		return 20;
	}

}
