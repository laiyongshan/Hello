package suncere.fuzhou.androidapp;

import suncere.androidappcf.controls.SuncereAppDesActivity;

public class AppDesActivity extends SuncereAppDesActivity {

	int[] appDesImgArr;
	@Override
	protected int[] ImageResIdArrary() {
		if(appDesImgArr==null)
		{
			appDesImgArr=new int[]
			{ 
					R.mipmap.app_1,
					R.mipmap.app_2,
					R.mipmap.app_3,
					R.mipmap.app_4,
			};
		}
		return appDesImgArr;
	}
}
