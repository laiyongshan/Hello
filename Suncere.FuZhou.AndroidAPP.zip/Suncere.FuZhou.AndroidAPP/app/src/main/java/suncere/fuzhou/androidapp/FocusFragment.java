package suncere.fuzhou.androidapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.autobasemodule.AutoBaseBLL;
import suncere.androidapp.autobasemodule.PluginLoader;
import suncere.androidapp.focus.FocusModel;
import suncere.androidappcf.app.SuncereAutoFragment;
import suncere.fuzhou.others.Tools;

/**
 * Created by Hjo on 2017/3/14.
 */
public class FocusFragment extends SuncereAutoFragment {

    @BindView(R.id.focus_title_refresh_image)
    ImageView focus_title_refresh_image;

    @BindView(R.id.focus_title_add)
    TextView focus_title_add;

    List<HashMap<String ,Object>> mListDatas;
    String Codes;


    @Override
    public int OnGetContentView() {
        return R.layout.focus_fragment;
    }

    @Override
    public void OnMapCreatView(Bundle savedInstanceState, View view) {
        ButterKnife.bind(this,view);
        super.OnMapCreatView(savedInstanceState, view);
    }

    @Override
    public void InitViews() {
        mListDatas=new ArrayList<>();
        getCodelist();
    }

    @Override
    public void onStart() {
        super.onStart();
        getCodelist();

    }

    @Override
    public void RegistQueryModels() {
        RegistQueryModel("fcous", FocusModel.class);
    }

    @Override
    public void SetQueryParameter(HashMap<String, Object[]> queryModelCollection) {
        HashMap<String ,Object>focus= (HashMap<String, Object>) queryModelCollection.get("fcous")[1];
        focus.put("&Codes",Codes);
    }

    @Override
    public void BindData(HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {
        Log.e("FocusFragment",datasourceCollection.get("fcous").toString());
    }
    public void  getCodelist(){
        StringBuffer sb=new StringBuffer();
        FocusModel model=new FocusModel();
        AutoBaseBLL autoBaseBLL= PluginLoader.Current().InitPlugin(model) ;
        List<HashMap<String,Object>> datas= autoBaseBLL.GetCacheData(null);
        if (datas!=null && datas.size()>0){
            mListDatas.clear();
            mListDatas.addAll(datas);
            for (int i=0;i<datas.size();i++)
                if (i<datas.size()-1){
                    sb.append((String) datas.get(i).get("Code")).append(",");
                }else{
                    sb.append((String) datas.get(i).get("Code"));
                }
        }else{
            sb.append("350100");
        }
        Codes=sb.toString();
        Log.e("FocusFragment","Codes"+Codes);
    }

    @OnClick({R.id.focus_title_refresh_rela,R.id.focus_title_add})
    public void On_Click_refresh(View view){
        switch (view.getId()){
            case R.id.focus_title_refresh_rela:
                RefreshViewData();
                break;
            case R.id.focus_title_add:
                Intent intent=new Intent(getActivity(),FocusAddCityAcitvity.class);
                startActivity(intent);
                break;
        }
    }

    @Override
    public void RefreshViewData() {
//        focus_title_refresh_image.startAnimation(operatingAnim);
        focus_title_refresh_image.startAnimation(Tools.getInstance().getRefreshAnimation(getActivity()));
        super.RefreshViewData();

    }

    @Override
    public void OnAsyncLoadPostExecute() {
        focus_title_refresh_image.clearAnimation();
//        super.OnAsyncLoadPostExecute();
    }
}
