package suncere.fuzhou.androidapp;

import java.util.HashMap;
import java.util.List;

import suncere.androidappcf.app.SuncereAutoActivity;

public class MainActivity extends SuncereAutoActivity {


    @Override
    public int OnGetContentView() {
        return R.layout.activity_main;
    }

    @Override
    public void InitViews() {

    }

    public boolean IsMainActivity()
    {
        return true;
    }
    public boolean UseDialogExistApp()
    {
        return true;
    }

    @Override
    public void RegistQueryModels() {

    }

    @Override
    public void SetQueryParameter(HashMap<String, Object[]> queryModelCollection) {

    }

    @Override
    public void BindData(HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {

    }
}
