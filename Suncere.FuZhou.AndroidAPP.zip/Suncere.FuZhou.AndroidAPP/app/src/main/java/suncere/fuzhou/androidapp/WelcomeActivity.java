package suncere.fuzhou.androidapp;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import suncere.androidappcf.controls.MyUIPagerControlView;
import suncere.androidappcf.controls.SuncereFragmentActivity;
import suncere.fuzhou.others.Tools;

public class WelcomeActivity extends SuncereFragmentActivity {

	ViewPager viewPager;
	List<ImageView> list;
	MyUIPagerControlView hfPagerControl;
	Button click;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.set_instructions_act);
	}

	public List<Integer> getImages() {
		List<Integer> list = new ArrayList<Integer>();
		
		list.add(R.mipmap.app_1 );
		list.add(R.mipmap.app_2);

		list.add(R.mipmap.app_3);

		list.add(R.mipmap.app_4);

		return list;
	}

	public void On_Click(View sender) {
		//getWindow().clearFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
		
		Intent intent = new Intent(WelcomeActivity.this,MainActivity.class);
		startActivity(intent);

		Tools.getInstance().setIsFristTime(false,this);

	}

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
         hfPagerControl = (MyUIPagerControlView)findViewById(R.id.hfPagerControl);
         
         click = (Button)findViewById(R.id.click);
        
		viewPager = (ViewPager) findViewById(R.id.viewpage);
		viewPager.setOnPageChangeListener(On_vp_Change);

		list = new ArrayList<ImageView>();
		for (int i = 0; i < 4; i++) {
			ImageView imageView = new ImageView(getApplicationContext());
			imageView.setBackgroundDrawable(getResources().getDrawable(
					getImages().get(i)));
			list.add(imageView);
		}
		
        hfPagerControl.setCount(list.size());

		MyAdapter adapter = new MyAdapter(getApplicationContext(), list);
		viewPager.setAdapter(adapter);

	}

	OnPageChangeListener On_vp_Change=new OnPageChangeListener()
	{

		@Override
		public void onPageScrollStateChanged(int arg0) {
		}

		@Override
		public void onPageScrolled(int arg0, float arg1, int arg2) {
		}

		@Override
		public void onPageSelected(int arg0) {
			
			hfPagerControl.setSelectedIndex(arg0);
			if (arg0 == list.size()-1) {
				click.setVisibility(View.VISIBLE);
			}else {
				click.setVisibility(View.GONE);
			}
		}
	};
	
	public class MyAdapter extends PagerAdapter {
		Context context;
		List<ImageView> list;

		public MyAdapter(Context context, List<ImageView> list) {
			this.context = context;
			this.list = list;
		}

		@Override
		public int getCount() {
			return list.size();
		}

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			container.addView(list.get(position));
			return list.get(position);
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			container.removeView(list.get(position));
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			return arg0 == arg1;
		}
	}
	@Override
	public void RefreshViewData() {
		// TODO Auto-generated method stub
		
	}

}
