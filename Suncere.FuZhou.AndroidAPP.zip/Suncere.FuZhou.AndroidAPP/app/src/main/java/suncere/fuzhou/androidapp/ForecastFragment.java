package suncere.fuzhou.androidapp;

import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.forecast.ForecastContentModel;
import suncere.androidapp.viewautobinder.DatasourceTypeEnum;
import suncere.androidappcf.app.SuncereAutoFragment;
import suncere.androidappcf.tools.DateTimeTool;
import suncere.fuzhou.others.Tools;

/**
 * Created by Hjo on 2017/3/14.
 */
public class ForecastFragment  extends SuncereAutoFragment {

    @BindView(R.id.forecast_content)
    TextView forecast_content;

    @BindView(R.id.forecast_time)
    TextView forecast_time;

    @BindView(R.id.forecast_title_refresh_image)
    ImageView forecast_title_refresh_image;



    @Override
    public int OnGetContentView() {
        return R.layout.forecast_fragment;
    }

    @Override
    public void OnMapCreatView(Bundle savedInstanceState, View view) {
        super.OnMapCreatView(savedInstanceState, view);
        ButterKnife.bind(this,view);

    }

    @Override
    public void InitViews() {

    }


    @Override
    public void RegistQueryModels() {
        RegistQueryModel("forecastContent", ForecastContentModel.class, DatasourceTypeEnum.Single);

    }

    @Override
    public void SetQueryParameter(HashMap<String, Object[]> queryModelCollection) {

    }

    @Override
    public void BindData(HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {

        List<HashMap<String, Object>> forecastLst=datasourceCollection.get("forecastContent");
        if(forecastLst==null||forecastLst.size()<1)return;
        HashMap<String,Object> datas= forecastLst.get(0);
        if(datas!=null)
        {
            forecast_content.setText(Html.fromHtml("<div style=' color:#ffffff'>"+datas.get("Survey")+"</div>") );
            if(!datas.containsKey("PubTime")||datas.get("PubTime")==null||datas.get("PubTime").toString().length()==0)
               forecast_time.setText( "----年--月--日--时发布");
            else
                forecast_time.setText(DateTimeTool.ToString(DateTimeTool.Prase( datas.get("PubTime")), "yyyy年MM月dd日HH时发布"));
        }
    }

    @OnClick(R.id.forecast_title_rela)
    public void On_Click_refresh(){
        RefreshViewData();
    }

    @Override
    public void RefreshViewData() {
        forecast_title_refresh_image.startAnimation(Tools.getInstance().getRefreshAnimation(getActivity()));
        super.RefreshViewData();
    }

    @Override
    public void OnAsyncLoadPostExecute() {
        forecast_title_refresh_image.clearAnimation();
        super.OnAsyncLoadPostExecute();
    }
}
