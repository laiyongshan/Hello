package suncere.fuzhou.others;

import android.content.Context;

import java.util.HashMap;
import java.util.List;

import suncere.androidapp.basemodule.BaseDAL;
import suncere.androidapp.focus.FocusModel;

/**
 * Created by Hjo on 2017/3/16.
 */

public class FocusDAL extends BaseDAL {
    public FocusDAL(Context context) {
        super(context);
    }

    public long delectFocusCity (List<HashMap<String,Object>> delectCondition){
//        String [] condition=new String [delectCondition.size()];
//        for (int i=0;i<delectCondition.size();i++){
//            condition[i]=delectCondition.get(i).get("Code").toString();
//        }
        int result =-1;
        this.Open();
        FocusModel model=new FocusModel();
        String tableName=model.MappingTableName();

        for (int i=0;i<delectCondition.size();i++){
            String []content=new String[1];
            content[0]=delectCondition.get(i).get("Code").toString();
            result=this.db.delete(tableName,"Code =? ",content);
        }
        this.Close();
        return result;
    }
}
