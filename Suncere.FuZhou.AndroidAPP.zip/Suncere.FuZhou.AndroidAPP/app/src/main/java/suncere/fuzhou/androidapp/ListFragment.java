package suncere.fuzhou.androidapp;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.bigkoo.pickerview.TimePickerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.autobasemodule.AutoBaseBLL;
import suncere.androidapp.autobasemodule.PluginLoader;
import suncere.androidapp.focus.DataLoaderConfig;
import suncere.androidapp.focus.FocusModel;
import suncere.androidapp.list.ListDataModel;
import suncere.androidappcf.app.SuncereAutoFragment;
import suncere.androidappcf.controls.SegmentControl;
import suncere.fuzhou.others.TimerPikerTools;
import suncere.fuzhou.others.Tools;

/**
 * Created by Hjo on 2017/3/14.
 *
 * 以下districtType 和  type  缺项补0
 * 日均：
 *         关注：
 *         全省：districtType=1
 *         全国：districtType=2
 *         74城市：districtType=3
 *
 * 月排：  关注：                 type=1
 *         全省：districtType=1   type=1
 *         全国：districtType=2   type=1
 *         74城市：districtType=3   type=1
 *
 * 年排：  关注：                 type=2
 *         全省：districtType=1   type=2
 *         全国：districtType=2   type=2
 *         74城市：districtType=3   type=2
 *
 * 自定义：关注：
 *         全省：districtType=1     type=3
 *         全国：districtType=2     type=3
 *         74城市：districtType=3   type=3
 */

public class ListFragment extends SuncereAutoFragment {
    @BindView(R.id.list_city_refresh_image)
    ImageView list_city_refresh_image;

    @BindView(R.id.list_segTimeType)
    SegmentControl list_segTimeType;//时间 日 月 年 自定义时间

    @BindView(R.id.list_segGeoType)
    SegmentControl list_segGeoType;//关注 省 全国 74城市

    @BindView(R.id.list_sort_lbTimePoint)
    TextView list_sort_lbTimePoint;//福州市：3      2月23日发布

    @BindView(R.id.list_listview0)
    ListView list_listview0;

    @BindView(R.id.list_listview1)
    ListView list_listview1;

    @BindView(R.id.list_title_tab_PollutantNameTv)
    TextView list_title_tab_PollutantNameTv;

    @BindView(R.id.list_title_tab_AQI)
    TextView list_title_tab_AQI;

    @BindView(R.id.compare_StartTime_tv)
    TextView compare_StartTime_tv;//自定义起始日期

    @BindView(R.id.compare_EndTime_tv)
    TextView compare_EndTime_tv;//自定义结束日期

    @BindView(R.id.compare_Seach_tv)
    TextView compare_Seach_tv;//自定义查询按钮

    @BindView(R.id.compare_StartAndEndTime_lin)
    LinearLayout compare_StartAndEndTime_lin;//自定义时间查询布局

    @BindView(R.id.selected_time_tv)
    TextView selected_time_tv;//选择的时间，时间默认日均是昨天的日期，月——上一个月，年——上一年

    TimePickerView mTimePikerView;//时间选择器


    int  districtType=0;//城市范围 0：关注 1：全省 2：全国  3:74城市
    int  type=0;//时间范围  0：日  1：月  2：年  3：自定义
    String Codes;

    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
    String format="";
    String beginTime="";
    String endTime="";

    @Override
    public int OnGetContentView() {
        return R.layout.list_fragment;
    }

    @Override
    public void OnMapCreatView(Bundle savedInstanceState, View view) {
        ButterKnife.bind(this,view);
        super.OnMapCreatView(savedInstanceState, view);
    }

    @Override
    public void InitViews() {
        getCodelist();

        format=TimerPikerTools.getLastDate(-1);
        beginTime=TimerPikerTools.getLastDate(-2);
        endTime=TimerPikerTools.getTodayDate();
        selected_time_tv.setText(format);
        compare_StartTime_tv.setText(beginTime);
        compare_EndTime_tv.setText(endTime);


        // 日均 月排 年排 自定义时间
        list_segTimeType.setOnSegmentControlClickListener(new SegmentControl.OnSegmentControlClickListener() {
            @Override
            public void onSegmentControlClick(int index) {
                type=index;

                if(type==0){//日均
                    format=TimerPikerTools.getLastDate(-1);
                    selected_time_tv.setText(format + "");
                }else if(type==1){//月
                    format=TimerPikerTools.getLastMonthDate();
                    selected_time_tv.setText(format.substring(0,7)+"");
                }else if(type==2){//年
                    format=TimerPikerTools.getLastYearDate();
                    selected_time_tv.setText(format.substring(0,4)+"年");
                }else if(type==3){//自定义时间
                    compare_StartAndEndTime_lin.setVisibility(View.VISIBLE);
                    selected_time_tv.setVisibility(View.GONE);
                }

                if (type==0){ //日均时  使用listView0
                    list_listview0.setVisibility(View.VISIBLE);
                    list_listview1.setVisibility(View.GONE);
                    list_title_tab_PollutantNameTv.setVisibility(View.VISIBLE);
                    list_title_tab_AQI.setText("AQI指数");
                }else{
                    list_listview0.setVisibility(View.GONE);
                    list_listview1.setVisibility(View.VISIBLE);
                    list_title_tab_PollutantNameTv.setVisibility(View.GONE);
                    list_title_tab_AQI.setText("综合指数");
                }
                if(type!=3){
                    compare_StartAndEndTime_lin.setVisibility(View.GONE);
                    selected_time_tv.setVisibility(View.VISIBLE);
                }

                RefreshViewData();//使用默认日期刷新数据
            }
        });

        //关注 全省 全国  74城市
        list_segGeoType.setOnSegmentControlClickListener(new SegmentControl.OnSegmentControlClickListener() {
            @Override
            public void onSegmentControlClick(int index) {
                districtType=index;
                RefreshViewData();
            }
        });
    }

    @OnClick({ R.id.selected_time_tv,R.id.compare_StartTime_tv, R.id.compare_EndTime_tv , R.id.compare_Seach_tv})
    public void OnClick_listener(View view) {
        switch (view.getId()) {
            case R.id.compare_StartTime_tv://自定义起始时间
                mTimePikerView= TimerPikerTools.creatTimePickerView(getActivity(), "选择日期", true, true, true, new TimePickerView.OnTimeSelectListener() {
                    @Override
                    public void onTimeSelect(Date date, View v) {
                        beginTime = simpleDateFormat.format(date);
                        compare_StartTime_tv.setText(beginTime+"");
                    }
                });
                mTimePikerView.show();

                break;
            case R.id.compare_EndTime_tv://自定义结束时间
                mTimePikerView= TimerPikerTools.creatTimePickerView(getActivity(), "选择日期", true, true, true, new TimePickerView.OnTimeSelectListener() {
                    @Override
                    public void onTimeSelect(Date date, View v) {
                        endTime= simpleDateFormat.format(date);
                        compare_EndTime_tv.setText(endTime+"");
                    }
                });
                mTimePikerView.show();
                break;
            case R.id.compare_Seach_tv://自定义时间搜索
                RefreshViewData();
                break;

            case R.id.selected_time_tv://时间范围选择

                if(type==0){//日均
                    mTimePikerView= TimerPikerTools.creatTimePickerView(getActivity(),"选择日期",true,true,true,mOnTimeSelectListener);
                }else if(type==1){//月份
                    mTimePikerView= TimerPikerTools.creatTimePickerView(getActivity(),"选择月份",true,true,false,mOnTimeSelectListener);
                }else if(type==2){//年
                    mTimePikerView= TimerPikerTools.creatTimePickerView(getActivity(),"选择年份",true,false,false,mOnTimeSelectListener);
                }
                mTimePikerView.show();
                break;
        }
    }

    @Override
    public void RegistQueryModels() {
        RegistQueryModel("listData", ListDataModel.class);
    }

    @Override
    public void SetQueryParameter(HashMap<String, Object[]> queryModelCollection) {
        HashMap<String ,Object> listDataQuery= (HashMap<String, Object>) queryModelCollection.get("listData")[1];
        listDataQuery.put("districtType",districtType);
        listDataQuery.put("type",type);
//        districtType=0 时所获取到的都是关注城市数据
        if (districtType==0 && type==0){ //日均--》关注
            listDataQuery.put(DataLoaderConfig.CONFIG_NAME,"FocusDay");
            listDataQuery.put("Codes",Codes);
        }else if (districtType==0 && type!=0){ // 月排--》关注  年排--》关注  自定义时间-——》关注
            listDataQuery.put(DataLoaderConfig.CONFIG_NAME,"FocusMonthOrYear");
            listDataQuery.put("Codes",Codes);
        }
        else if(districtType!=0  && type==0  ){ //日均--》全省、全国、74城市
            listDataQuery.put(DataLoaderConfig.CONFIG_NAME,"AQIDay");
        }else{
            if(listDataQuery.containsKey("Codes")){
                listDataQuery.remove("Codes");
            }
            listDataQuery.put(DataLoaderConfig.CONFIG_NAME,"AQIMonthOrYear");
        }
        if(type!=3) {
            if(listDataQuery.containsKey("beginTime"))
                listDataQuery.remove("beginTime");
            if(listDataQuery.containsKey("endTime"))
                listDataQuery.remove("endTime");
            listDataQuery.put("time", format);//加入查询时间参数
        }else{
            listDataQuery.remove("time");
            listDataQuery.put("beginTime",beginTime);//自定义起始时间
            listDataQuery.put("endTime",endTime);//自定义结束时间
        }
    }

    @Override
    public void BindData(HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {

        for (HashMap<String, Object>itme : datasourceCollection.get("listData") ){
            if (itme.get("Name").equals("福州市")){
                if(type==2) list_sort_lbTimePoint.setText( String.format("福州市：%s   %s发布", itme.get("Rank"),itme.get("YearTime")) );
                else list_sort_lbTimePoint.setText( String.format("福州市：%s   %s发布", itme.get("Rank"),itme.get("putTime")) );
                break;
            }
        }
    }
    public void  getCodelist(){
        StringBuffer sb=new StringBuffer();
        FocusModel model=new FocusModel();
        AutoBaseBLL autoBaseBLL= PluginLoader.Current().InitPlugin(model) ;
        List<HashMap<String,Object>> datas= autoBaseBLL.GetCacheData(null);
        if (datas!=null && datas.size()>0){
            for (int i=0;i<datas.size();i++)
                if (i<datas.size()-1){
                    sb.append((String) datas.get(i).get("Code")).append(",");
                }else{
                    sb.append((String) datas.get(i).get("Code"));
                }
        }else{
            sb.append("360100");
        }
        Codes=sb.toString();
        Log.e("FocusFragment","Codes"+Codes);
    }


    @OnClick(R.id.list_city_refresh_rela)
    public void On_Click_refresh(){
        RefreshViewData();
    }
    @Override
    public void RefreshViewData() {
        list_city_refresh_image.startAnimation(Tools.getInstance().getRefreshAnimation(getActivity()));
        super.RefreshViewData();
    }
    @Override
    public void OnAsyncLoadPostExecute() {
        list_city_refresh_image.clearAnimation();
    }



    TimePickerView.OnTimeSelectListener mOnTimeSelectListener=new TimePickerView.OnTimeSelectListener() {
        @Override
        public void onTimeSelect(Date date, View v) {
            format = simpleDateFormat.format(date);
            if(type==1){
                selected_time_tv.setText(format.substring(0,7)+"");
            }else if(type==2){
                selected_time_tv.setText(format.substring(0,4)+"年");
            }else {
                selected_time_tv.setText(format + "");
            }
            RefreshViewData();//选择日期后刷新数据
        }
    };
}
