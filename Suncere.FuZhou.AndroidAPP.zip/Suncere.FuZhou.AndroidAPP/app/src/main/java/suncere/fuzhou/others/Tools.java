package suncere.fuzhou.others;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import suncere.fuzhou.androidapp.R;

/**
 * Created by Hjo on 2017/3/16.
 */

public class Tools {

    private static Tools instance;
    public static Tools getInstance() {
        if (instance == null) {
            synchronized (Tools.class) {
                if (instance == null) {
                    instance = new Tools();
                }
            }
        }
        return instance;
    }



    public Animation getRefreshAnimation(Context context){
        Animation operatingAnim;//动画
        operatingAnim = AnimationUtils.loadAnimation(context.getApplicationContext(), R.anim.tip);//使用弱引用  避免内存泄露
        operatingAnim.setDuration(800);
        LinearInterpolator lin = new LinearInterpolator();
        operatingAnim.setInterpolator(lin);

        return operatingAnim;
    }

    public  void setIsFristTime(boolean isfristtime,Context context){
        SharedPreferences sharedPreferences = context.getApplicationContext().getSharedPreferences("isFistTimeXML", Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isfristtime",isfristtime);
        editor.apply();
    }


    public  boolean getIsFristTime(Context context){
        SharedPreferences sharedPreferences= context.getApplicationContext().getSharedPreferences("isFistTimeXML", Activity.MODE_PRIVATE);
        // 使用getString方法获得value，注意第2个参数是value的默认值
        boolean isFristTime =sharedPreferences.getBoolean("isfristtime", true);
        return	isFristTime;
    }

    /**
     * 将字符串转为时间  再将时间转为固定格式   返回特定字符串
     * @param str            需要转化的字符串
     * @param dateFormatStr  当前字符串的时间格式  如：yyyy-MM-dd HH:mm:ss
     * @param formatStr      需要转化成的时间格式  如：MM_dd
     * @return
     */
    public  String stringToData(String str,String dateFormatStr,String formatStr){
        String time="更新于---- -- -- --时";
        if (str!=null) {
            str=str.replace("T"," ");
            int index=str.indexOf(".");
            if (index!=-1)
                str=str.substring(0,index);
            DateFormat sdf=new SimpleDateFormat(dateFormatStr);
            Date date = null;
            try {
                date=sdf.parse(str);
            } catch (Exception e) {
                // TODO: handle exception
            }
            SimpleDateFormat s = new SimpleDateFormat(formatStr);
            time=s.format(date).toString();
        }

        return time;
    }


}
