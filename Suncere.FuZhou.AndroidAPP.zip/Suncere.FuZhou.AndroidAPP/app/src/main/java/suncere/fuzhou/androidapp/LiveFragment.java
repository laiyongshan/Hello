package suncere.fuzhou.androidapp;

import android.graphics.Color;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import butterknife.BindView;
import butterknife.BindViews;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.OnPageChange;
import suncere.androidapp.live.LiveStationModel;
import suncere.androidapp.live_chart24.LiveChart24Model;
import suncere.androidapp.live_chart30.LiveChart30Model;
import suncere.androidapp.viewautobinder.DatasourceTypeEnum;
import suncere.androidappcf.app.SuncereAutoFragment;
import suncere.androidappcf.aqi.AQITool;
import suncere.androidappcf.controls.MyUIPagerControlView;
import suncere.androidappcf.controls.TipView;
import suncere.androidappcf.controls.VerticalViewPager;
import suncere.androidappcf.tools.Convert;
import suncere.androidappcf.tools.SegmentLabelTool;
import suncere.fuzhou.others.Tools;
import suncere.fuzhou.views.ChartSet;
import suncere.fuzhou.views.LineChartView;

/**
 * Created by Hjo on 2017/3/14.
 */
public class LiveFragment extends SuncereAutoFragment {

    @BindView(R.id.live_title_refresh_image)
    ImageView live_title_refresh_image;

    @BindView(R.id.live_lfScrollView)
    VerticalViewPager live_lfScrollView;

    @BindView(R.id.live_view_viewpager)
    ViewPager live_view_viewpager;

    @BindView(R.id.live_view_pager)
    MyUIPagerControlView live_view_pager;

    @BindView(R.id.live_title_tv)
    TextView live_title_tv;

//    @BindView(R.id.live_chart24)
//    MyCubeChartView live_chart24;

    @BindView(R.id.live_LineChartView24)
    LineChartView mLineChartView24;
    ChartSet mChartSet24;
    List<String > m24Yvalue;
    List<String > m24Xvalue;
    List<Integer> m24Colors;

    @BindView(R.id.live_LineChartView30)
    LineChartView mLineChartView30;
    ChartSet mChartSet30;
    List<String > m30Yvalue;
    List<String > m30Xvalue;
    List<Integer> m30Colors;

//    @BindView(R.id.live_chart30)
//    MyCubeChartView live_chart30;

    @BindView(R.id.live_chart24_title)
    TextView live_chart24_title;

    @BindView(R.id.live_chart30_title)
    TextView live_chart30_title;

    @BindViews({ R.id.live_SO2, R.id.live_NO2, R.id.live_PM10, R.id.live_CO, R.id.live_O3, R.id.live_PM2_5,R.id.live_title_tv} )
    List<TextView> mPollutantNameviews;
    String []mPollutantNamelist={"SO2","NO2","PM10","CO","O3","PM25","Name"};
    String []mPollutantNameBg ={"so2Bg","no2Bg","pm10Bg","coBg","o3Bg","pm2_5Bg"};

    String Code="350100";
    String Type="AQI";
    int[]  viewPagerIndex={0};
    SegmentLabelTool segmentLabelTool;
    List<HashMap<String ,Object>>mliveData;
    List<HashMap<String ,Object>>mChart24Data;
    List<HashMap<String ,Object>>mChart30Data;

    TipView mTipView;
    TextView mlive_fiveMin_chart_title;
    LineChartView mlive_fiveMin_chart_data;
    LinearLayout mlive_fiveMin_chart_emptyText;
    ChartSet mChartSet5;
    List<String > m5Yvalue;
    List<String > m5Xvalue;

    @Override
    public int OnGetContentView() {
        return R.layout.live_fragment;
    }

    @Override
    public void OnMapCreatView(Bundle savedInstanceState, View view) {
        ButterKnife.bind(this,view);
        super.OnMapCreatView(savedInstanceState, view);
    }

    @Override
    public void InitViews() {

        mliveData=new ArrayList<>();
        mTipView=new TipView(getActivity(),R.layout.live_chart_five_min_data);
        mlive_fiveMin_chart_title= (TextView) mTipView.findViewById(R.id.live_fiveMin_chart_title);
        mlive_fiveMin_chart_data= (LineChartView) mTipView.findViewById(R.id.live_fiveMin_chart_data);
        mlive_fiveMin_chart_emptyText= (LinearLayout) mTipView.findViewById(R.id.live_fiveMin_chart_emptyText);
        mChartSet5=initChartSet();
        mChartSet5.setPointColor(Color.WHITE);
//        mlive_fiveMin_chart_data.setChartSet(mChartSet5);
        m5Yvalue=new ArrayList<>();
        m5Xvalue=new ArrayList<>();

        mChart24Data=new ArrayList<>();
        m24Yvalue=new ArrayList<>();
        m24Xvalue=new ArrayList<>();
        m24Colors=new ArrayList<>();
        mChartSet24=initChartSet();
        mChartSet24.setPointsColor(true);
        mChartSet24.setPointClickListener(new ChartSet.PointClickListener() {
            @Override
            public void pointClick(int index) {
                Log.e("LiveFragment","mChartSet24 click index="+index);
                if (!"350100".equals(Code)  && !"AQI".equals(Type)) {  // 福州市和AQI没有颜色值
                    m5Yvalue.clear();
                    m5Xvalue.clear();
                    if (mChart24Data.get(index).get("MinValues")!=null &&  mChart24Data.get(index).get("MinTimes")!=null ){
                        String minValues=mChart24Data.get(index).get("MinValues").toString();
                        String minTimes=mChart24Data.get(index).get("MinTimes").toString();
                        if ( !"null".equals(minValues) && !"".equals(minValues) && !"null".equals(minTimes) &&  !"".equals(minTimes)){
                            mlive_fiveMin_chart_emptyText.setVisibility(View.GONE);
                            String []MinValues= minValues.split(",");
                            String []MinTimes=minTimes.split(",");
                            m5Yvalue.addAll(Arrays.asList(MinValues));
                            for (int i=0;i<MinTimes.length;i++){
                                m5Xvalue.add(Tools.getInstance().stringToData(MinTimes[i],"yyyy/MM/dd hh:mm:ss","mm"));
                            }
//                            m5Xvalue.addAll(Arrays.asList(MinTimes));
                        }
                    }else{
                        mlive_fiveMin_chart_emptyText.setVisibility(View.VISIBLE);
                    }
//                    int max=160;
//                    int min=0;
//                    m5Yvalue.clear();
//                    m5Xvalue.clear();
//                    Random random = new Random();
//                    for (int i=0;i<3;i++){
//                        int s = random.nextInt(max)%(max-min+1) + min;
//                        m5Yvalue.add(s +"");
//                        m5Xvalue.add(""+i);
//                    }
                    mlive_fiveMin_chart_title.setText(m24Xvalue.get(index)+"五分钟值趋势图");
                    mChartSet5.setmStringYVaule(m5Yvalue);
                    mChartSet5.setmXVaule(m5Xvalue);
                    mlive_fiveMin_chart_data.setChartSet (mChartSet5);
                    mTipView.show();
                }
            }
        });

        mChart30Data=new ArrayList<>();
        mChartSet30=initChartSet();
        mChartSet30.setPointsColor(true);
        m30Yvalue=new ArrayList<>();
        m30Xvalue=new ArrayList<>();
        m30Colors=new ArrayList<>();

        segmentLabelTool=new SegmentLabelTool(this.contentView)
                .setNormalBackground(Color.TRANSPARENT)
                .setNormalTextColor(Color.WHITE)
                .setSelectedTextColor(Color.BLACK)
                .setSelectedBackground(R.drawable.pollutant_btn)
                .setViewList(R.id.btnAQI,R.id.btnSO2,R.id.btnNO2,R.id.btnCO,R.id.btnO3,R.id.btnPM10,R.id.btnPM2_5)
                .SetSegmentClick(new SegmentLabelTool.SegmentClick(){
                    @Override
                    public void OnClick(View sender, int index) {
                        Type= ((TextView)sender).getText().toString().replace(".","");
                        if ("AQI".equals(Type)){
                            live_chart24_title.setText("过去24小时"+Type+"指数变化");
                            live_chart30_title.setText("近30天"+Type+"指数平均值");
                        }else{
                            if ("PM25".equals(Type)) Type="PM25";
                            live_chart24_title.setText("过去24小时"+Type+"浓度变化");
                             if ("O3".equals(Type))live_chart30_title.setText("近30天O3_8h浓度平均值");
                            else live_chart30_title.setText("近30天"+Type+"浓度平均值");
                        }
                        UnRefreshViews( live_view_viewpager  );
                        RefreshViewData();
                    }});
        live_lfScrollView.setmOnPageChangeListener(new VerticalViewPager.OnPageChangeListener() {
            @Override
            public void onPageChange(int pageIndex) {
                if (pageIndex==1){
                    UnRefreshViews( live_view_viewpager  );
                    RefreshViewData();
                }
            }
        });
    }

    private ChartSet initChartSet(){
        ChartSet set=new ChartSet();
        set.setColorDotted(Color.WHITE);
        set.setColorLine(Color.WHITE);
        set.setColorTextValue(Color.WHITE);
        set.setColorXY(Color.WHITE);
        set.setColorTextXY(Color.WHITE);
        set.setColorBg(Color.parseColor("#33aaaaaa"));
        return set;
    }

    @Override
    public void RegistQueryModels() {
        RegistQueryModel("live", LiveStationModel.class);
        RegistQueryModel("vpIndex", this.viewPagerIndex, DatasourceTypeEnum.Single);
        RegistQueryModel("livechart24", LiveChart24Model.class);
        RegistQueryModel("livechart30", LiveChart30Model.class);
    }

    @Override
    public void SetQueryParameter(HashMap<String, Object[]> queryModelCollection) {
            HashMap<String, Object> live24 = (HashMap<String, Object>) queryModelCollection.get("livechart24")[1];
            live24.put("Code", Code);
            live24.put("Type", Type);

            HashMap<String, Object> live30 = (HashMap<String, Object>) queryModelCollection.get("livechart30")[1];
            live30.put("Code", Code);
            live30.put("Type", Type);
    }

    @Override
    public void BindData(HashMap<String, List<HashMap<String, Object>>> datasourceCollection) {
        live_view_pager.setCount(live_view_viewpager.getAdapter().getCount());
       Log.e("LiveFragmentLive",datasourceCollection.get("live").toString());
        mliveData.clear();
        mliveData.addAll(datasourceCollection.get("live"));
        mChart24Data.clear();
        mChart24Data.addAll(datasourceCollection.get("livechart24"));
        bindchartData24();
        mChart30Data.clear();
        mChart30Data.addAll(datasourceCollection.get("livechart30"));
        bindchartData30();
    }

    private void bindchartData24(){
        m24Yvalue.clear();
        m24Xvalue.clear();
        m24Colors.clear();
        for ( int i=0;i<mChart24Data.size();i++ ){
            if (mChart24Data.get(i).get("YValue")!=null) m24Yvalue.add(mChart24Data.get(i).get("YValue").toString());
            else  m24Yvalue.add("0");
            m24Xvalue.add(mChart24Data.get(i).get("LabelXValue").toString());
            m24Colors.add(Convert.toInt( AQITool.GetAQIResourceByAQI(  mChart24Data.get(i).get("IAQI").toString() , AQITool.AQIPresentEnum.Color) ));
        }
        mChartSet24.setmColors(m24Colors);
        mChartSet24.setmXVaule(m24Xvalue);
        mChartSet24.setmStringYVaule(m24Yvalue);
        mLineChartView24.setChartSet(mChartSet24);
    }

    private void bindchartData30(){
        m30Yvalue.clear();
        m30Xvalue.clear();
        m30Colors.clear();
        for (int i=0;i<mChart30Data.size();i++){
            m30Yvalue.add(mChart30Data.get(i).get("YValue").toString());
            m30Xvalue.add(mChart30Data.get(i).get("LabelXValue").toString());
            m30Colors.add(Convert.toInt( AQITool.GetAQIResourceByAQI(  mChart30Data.get(i).get("IAQI").toString() , AQITool.AQIPresentEnum.Color) ));
        }
        mChartSet30.setmColors(m30Colors);
        mChartSet30.setmXVaule(m30Xvalue);
        mChartSet30.setmStringYVaule(m30Yvalue);
        mLineChartView30.setChartSet(mChartSet30);
    }

    @OnPageChange(R.id.live_view_viewpager)
        public void On_ViewPagee_PageChang(int position){
        live_view_pager.setSelectedIndex(position);
        viewPagerIndex[0]=position;
        Code=mliveData.get(position).get("Code").toString();

        for (int i=0;i<mPollutantNameviews.size();i++){
            if (mPollutantNamelist[i].equals("Name")){
                mPollutantNameviews.get(i).setText(mliveData.get(position).get(mPollutantNamelist[i]).toString()+"空气质量实况");
            }else {
                mPollutantNameviews.get(i).setText(mliveData.get(position).get(mPollutantNamelist[i]).toString());
                mPollutantNameviews.get(i).setBackgroundResource((Integer)mliveData.get(position).get(mPollutantNameBg[i]));
            }
        }
    }

    @OnClick(R.id.live_title_refresh_rela)
    public void On_Click_refresh(){
        RefreshViewData();
    }


    @Override
    public void RefreshViewData() {
        live_title_refresh_image.startAnimation(Tools.getInstance().getRefreshAnimation(getActivity()));
        super.RefreshViewData();
    }

    @Override
    public void OnAsyncLoadPostExecute() {
        live_title_refresh_image.clearAnimation();
        super.OnAsyncLoadPostExecute();
    }

}
