package suncere.androidapp.viewautobinder;

import java.util.HashMap;

public interface IMacroDefine {
	void DefineMacroField(HashMap<String, String> fieleCollection);
}
