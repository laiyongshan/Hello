package suncere.androidapp.attributtes_hjo;

public enum AttributeRelustData {
	
	
	$RelustData;
	
//	private String value;
//	private AttributeRelustData(String value) {
//		// TODO Auto-generated constructor stub
//		this.value=value;
//	}
//	
//	private String getRelustData(){
//		
//		return    value;  
//	}
	
	
}
