package suncere.androidapp.autobasemodule;

import java.util.HashMap;

public class DeleteSqlStatementService extends SqlStatementService {

	public DeleteSqlStatementService(AutoBaseModel model) {
		super(model);
	}

	public String GetWhereStr(HashMap<String, Object> otherParams)
	{
		return super.GetWhereStr(otherParams, model.DELETE_CONDITION);
	}

	public String[] GetWhereParameter(HashMap<String, Object> otherParams) 
	{
		return super.GetWhereParameter(otherParams, model.DELETE_CONDITION);
	}

	
}
