package suncere.androidapp.viewautobinder;

public interface IAutoAdapter {
	ViewAutoBinder GetViewAutoBinder();
}
