package suncere.androidapp.attributes;

public interface IClassAttribute extends IAttribute
{
	
}