package suncere.androidapp.tableupgradeter;

public interface IBaseUpgradeInterface {

	String GetTableName();
	
	int GetTableVersion();

}
