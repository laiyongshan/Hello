package suncere.androidapp.attributes;

public interface IAttribute {

}
