package suncere.androidapp.viewautobinder;

public enum DatasourceTypeEnum {

	Single,
	Multi
}
