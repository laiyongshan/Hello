package suncere.androidapp.autobasemodule;

import java.util.HashMap;

public class SelectSqlStatementService extends SqlStatementService {

	public SelectSqlStatementService(AutoBaseModel model) {
		super(model);
	}

	public String GetWhereStr(HashMap<String, Object> otherParams)
	{
		return super.GetWhereStr(otherParams, -1);
	}

	public String[] GetWhereParameter(HashMap<String, Object> otherParams) 
	{
		return super.GetWhereParameter(otherParams, -1);
	}
}
