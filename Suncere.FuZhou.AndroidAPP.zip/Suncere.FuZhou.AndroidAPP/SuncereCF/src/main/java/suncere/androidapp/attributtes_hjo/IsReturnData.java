package suncere.androidapp.attributtes_hjo;

import suncere.androidapp.attributes.IClassAttribute;

public class IsReturnData implements IClassAttribute {

	private boolean rutuenData;
	

	public IsReturnData(boolean value) {
		// TODO Auto-generated constructor stub
		this.rutuenData=value;
	}
	
	public boolean getIsrutuenData() {
		return rutuenData;
	}

}
