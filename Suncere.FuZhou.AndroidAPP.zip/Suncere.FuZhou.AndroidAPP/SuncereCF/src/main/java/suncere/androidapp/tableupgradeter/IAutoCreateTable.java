package suncere.androidapp.tableupgradeter;

public interface IAutoCreateTable extends IBaseUpgradeInterface {
	String CreateTableSQL();
}
