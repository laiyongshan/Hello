package suncere.androidapp.viewautobinder;

public interface IChildViewAutoBinder {
	void PassParentViewAutoBinder(ViewAutoBinder viewAutoBinder);
}
