package suncere.androidapp.autobasemodule;

import java.util.HashMap;

public class ExistSqlStatementService extends SqlStatementService {

	public ExistSqlStatementService(AutoBaseModel model) {
		super(model);
	}

	public String[] GetWhereParameter(HashMap<String, Object> otherParams) 
	{
		return super.GetWhereParameter(otherParams, model.EXIST_CONDISTION);
	}
	
	public String GetWhereStr(HashMap<String, Object> otherParams)
	{
		return super.GetWhereStr(otherParams, model.EXIST_CONDISTION);
	}
}
