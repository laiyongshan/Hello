package suncere.androidappcf.app;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import suncere.androidapp.viewautobinder.DatasourceTypeEnum;
import suncere.androidapp.viewautobinder.ViewAutoBinder;
import suncere.androidappcf.controls.SuncereFragment;

public abstract class SuncereAutoFragment  extends SuncereFragment implements IAutoWrapper {

	boolean hasRegist=false;

	private AutoWrapperContext _wrapperContext;
	private AutoWrapperAdapter _adapter;

	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		_wrapperContext=new AutoWrapperContext(this);
		_adapter=new AutoWrapperAdapter(_wrapperContext);

		this.setContentView(this.OnGetContentView());
	}

	public View onCreateView(LayoutInflater inflater,ViewGroup container,Bundle savedInstanceState)
	{
		View view=super.onCreateView(inflater, container, savedInstanceState);
		OnMapCreatView(savedInstanceState,view);
		_wrapperContext.setViewAutoBinder( new ViewAutoBinder(view));
		_wrapperContext.getViewAutoBinder().AnalyzeViewBindingInfo(this.getContentView());

		return view;
	}

	public void onStart()
	{
		super.onStart();
		this.InitViews();
		if(!hasRegist)
		{
			this.RegistQueryModels();
			hasRegist=true;
		}
		RefreshViewData();
	}


	public void RefreshViewData()
	{
		this._adapter.RefreshViewData();
	}

	public void UnRefreshViews(View...views )
	{
		_adapter.UnRefreshViews( views);
	}

	public Object[] RegistQueryModel(String name,Class<?> autoModelBaseType)
	{
		return _adapter.RegistQueryModel(name, autoModelBaseType, DatasourceTypeEnum.Multi);
	}

	public Object[] RegistQueryModel(String name,Class<?> autoModelBaseType,DatasourceTypeEnum dsType)
	{
		return _adapter.RegistQueryModel(name, autoModelBaseType, dsType);
	}

	public void RegistQueryModel(String name,Object datasource)
	{
		_adapter.RegistQueryModel(name, datasource, DatasourceTypeEnum.Multi);
	}

	public void RegistQueryModel(String name,Object datasource, DatasourceTypeEnum dsType)
	{
		_adapter.RegistQueryModel(name, datasource, dsType);
	}

	public void CombineDatasource(DatasourceTypeEnum dsType, String newDatasourceName, String ds1, String ds2, String... keys)
	{
		_adapter.CombineDatasource(dsType, newDatasourceName, ds1, ds2, keys);
	}

	public void CombineDatasource(String newDatasourceName,String ds1,String ds2,String... keys)
	{
		_adapter.CombineDatasource(DatasourceTypeEnum.Multi, newDatasourceName, ds1, ds2, keys);
	}

	///在异步查询的时候执行
	public void OnAsyncLoadBackgroundDo()
	{

	}

	///在异步查询完成时执行
	public void OnAsyncLoadPostExecute()
	{

	}

	public  boolean ShowNetworkState() {
		return false;
	}

	public void OnMapCreatView(Bundle savedInstanceState,View view){

	}


}
