package suncere.androidappcf.app;

import android.content.Context;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;

import suncere.androidapp.viewautobinder.DatasourceTypeEnum;
import suncere.androidapp.viewautobinder.ViewAutoBinder;
import suncere.androidappcf.controls.SuncereFragmentActivity;

public abstract class SuncereAutoActivity extends SuncereFragmentActivity implements IAutoWrapper {

	private AutoWrapperContext _wrapperContext;
	private AutoWrapperAdapter _adapter;

	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);

		_wrapperContext=new AutoWrapperContext(this);
		_wrapperContext.setViewAutoBinder(new ViewAutoBinder(this));
		_adapter=new AutoWrapperAdapter(_wrapperContext);

		this.setContentView(this.OnGetContentView());
		this.InitViews();
		this.RegistQueryModels();
	}

//	public abstract int OnGetContentView();
//
//	public abstract void InitViews();
//
//	public abstract void RegistQueryModels();

	///设置查询参数
//	public abstract void SetQueryParameter(HashMap<String,Object[]> queryModelCollection );

	///绑定数据
//	public abstract void BindData(HashMap<String,List<HashMap<String,Object>>> datasourceCollection);

	public void RefreshViewData()
	{
		this._adapter.RefreshViewData();
	}

	public void UnRefreshViews(View...views )
	{
		_adapter.UnRefreshViews(views);
	}

	public Object[] RegistQueryModel(String name,Class<?> autoModelBaseType)
	{
		return _adapter.RegistQueryModel(name, autoModelBaseType, DatasourceTypeEnum.Multi);
	}

	public Object[] RegistQueryModel(String name,Class<?> autoModelBaseType,DatasourceTypeEnum dsType)
	{
		return _adapter.RegistQueryModel(name, autoModelBaseType, dsType);
	}

	public void RegistQueryModel(String name,Object datasource)
	{
		_adapter.RegistQueryModel(name, datasource, DatasourceTypeEnum.Multi);
	}

	public void RegistQueryModel(String name,Object datasource, DatasourceTypeEnum dsType)
	{
		_adapter.RegistQueryModel(name, datasource, dsType);
	}

	public void CombineDatasource(DatasourceTypeEnum dsType, String newDatasourceName, String ds1, String ds2, String... keys)
	{
		_adapter.CombineDatasource(dsType, newDatasourceName, ds1, ds2, keys);
	}

	public void CombineDatasource(String newDatasourceName,String ds1,String ds2,String... keys)
	{
		_adapter.CombineDatasource(DatasourceTypeEnum.Multi, newDatasourceName, ds1, ds2, keys);
	}

	public View onCreateView(String name, Context context, AttributeSet attrs)
	{
		this._wrapperContext.getViewAutoBinder().AnalyzeViewBindingInfo(attrs);
		return super.onCreateView(name, context, attrs);
	}



	///在异步查询的时候执行
	public void OnAsyncLoadBackgroundDo()
	{

	}

	///在异步查询完成时执行
	public void OnAsyncLoadPostExecute()
	{

	}

	public  boolean ShowNetworkState() {
		return this._adapter.ShowNetworkState();
	}
}
