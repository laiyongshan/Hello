package suncere.androidappcf.app;

import android.app.Activity;
import android.os.Bundle;

import suncere.androidappcf.R;


/**
 * Created by Suncere on 2016/11/18.
 */

public class MainActivty extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
