package suncere.androidappcf.hjo_refresh;

/**
 * Created by AItsuki on 2016/6/13.
 *
 */
public enum  State {
    RESET, PULL, LOADING, COMPLETE
}
