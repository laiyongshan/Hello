package suncere.androidappcf.controls;

//自动刷新视图
public interface IAutoRefreshableView 
{
	//刷新视图数据
	void RefreshViewData();
}
