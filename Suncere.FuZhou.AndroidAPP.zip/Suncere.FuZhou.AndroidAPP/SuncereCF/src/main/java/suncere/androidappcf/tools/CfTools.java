package suncere.androidappcf.tools;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;

import java.text.SimpleDateFormat;

/**
 * Created by Hjo on 2017/3/9.
 */

public class CfTools {
    Context mContext;
    public CfTools(Context context) {
        mContext=context;
    }

    public String  getRefreshTime(String XMLName){
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(XMLName, Activity.MODE_PRIVATE);
        SimpleDateFormat sDateFormat =new SimpleDateFormat("yyyy-MM-dd hh:mm");
        String date = sDateFormat.format(new java.util.Date());
        String  time=sharedPreferences.getString("lastRefreshTime", date);
        return time;
    }

    public void setRefreshTime(String XMLName,String  time){
        SharedPreferences sharedPreferences = mContext.getSharedPreferences(XMLName, Activity.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString ("lastRefreshTime", time);
        editor.apply();
    }
}
