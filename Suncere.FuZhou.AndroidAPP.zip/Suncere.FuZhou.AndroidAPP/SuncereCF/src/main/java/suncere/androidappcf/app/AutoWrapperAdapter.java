package suncere.androidappcf.app;

import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import suncere.androidapp.attributes.IClassAttribute;
import suncere.androidapp.attributtes_hjo.AttributeRelustData;
import suncere.androidapp.attributtes_hjo.IsReturnData;
import suncere.androidapp.autobasemodule.AutoBaseBLL;
import suncere.androidapp.autobasemodule.AutoBaseModel;
import suncere.androidapp.autobasemodule.DatasourceCombiner;
import suncere.androidapp.autobasemodule.PluginLoader;
import suncere.androidapp.viewautobinder.DatasourceTypeEnum;
import suncere.androidapp.viewautobinder.IMacroDefine;
import suncere.androidappcf.R;
import suncere.androidappcf.controls.SuncereApplication;
import suncere.androidappcf.tools.NetworkUitl;
import suncere.androidappcf.tools.TypeHelper;

public class AutoWrapperAdapter {



	private static Executor _executor;

	private AutoWrapperContext _context;
	private DatasourceCombiner _datasourceCombiner;
	private AsyncLoad _currentAsyncTask;


	/******
	 * Hjo 修改  
	 * 作用：网络和缓存都不存在数据时返回null 
	 * *****/
	private boolean isNetDatafinish=false;
	HashMap<String , Boolean>CacheDataMap;
	HashMap<String , Boolean>NetDataMap;

	public AutoWrapperAdapter(AutoWrapperContext context  )
	{
		this._context=context;
		this._datasourceCombiner=new DatasourceCombiner();

//		Log.e("hjo", "AutoWrapperAdapter");
		CacheDataMap=new HashMap<String, Boolean>();
		NetDataMap=new HashMap<String, Boolean>();
	}

	private static Executor Executor()
	{
		if(_executor==null)
		{
			Integer threadPoolSize= SuncereApplication.CurrentApplication().ThreadPoolSize();
			if(threadPoolSize==null)
			{
				_executor= AsyncLoad.SERIAL_EXECUTOR;
			}
			else
			{
				_executor=Executors.newFixedThreadPool(SuncereApplication.CurrentApplication().ThreadPoolSize());
			}
		}
		return _executor;
	}

	public void RefreshViewData()
	{
		this.GetData(true);
		BindData();
		if(_currentAsyncTask!=null)
		{
			_currentAsyncTask.cancel();
		}
		_currentAsyncTask=new AsyncLoad();
		_currentAsyncTask.executeOnExecutor(Executor());
	}

	protected void BindData()
	{

		long startTime=System.currentTimeMillis();
		/**********************
		 * Hjo
		 */
		//当进行到联网获取数据这轮时  说明一轮的数据查询结束（一轮：缓存+联网）

		if (isNetDatafinish) {
			CacheDataMap.clear();
			NetDataMap.clear();
			isNetDatafinish=false;
		}
		/*******************/
		HashMap<String,List<HashMap<String,Object>>> tmpDs=new HashMap<String,List<HashMap<String,Object>>>();
		tmpDs.putAll(_context.getDatasourceCollection());

		if(TypeHelper.IsSubClassOf(this, IMacroDefine.class) )
		{
			HashMap<String,String> macoFieldCollection=new HashMap<String,String>();
			((IMacroDefine)this).DefineMacroField(macoFieldCollection);
			if(macoFieldCollection.size()>0)
				_context.getViewAutoBinder().setDefineCollection(macoFieldCollection);
		}
		try
		{
			_context.getViewAutoBinder().AutoBindData();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		_context.getAutoWrapper().BindData(tmpDs);

		long endTime=System.currentTimeMillis();
		Log.d("AutoBaseDataLoader","  \n 该数据绑定视图耗时为："+(endTime-startTime));
	}

	protected void GetData(boolean isCache)
	{
		if (CacheDataMap==null  ) {
			CacheDataMap=new HashMap<String, Boolean>();
		}
		if(NetDataMap==null){
			NetDataMap=new HashMap<String, Boolean>();
		}
		//复制
		HashMap<String,Object[]> tmpQueryModelCollecton=new HashMap<String,Object[]>();
		tmpQueryModelCollecton.putAll( _context.getQueryModelCollection() );
		//在这里获取设置的属性
		_context.getAutoWrapper().SetQueryParameter( tmpQueryModelCollecton  );

		List<HashMap<String,Object>> datas;
		for(Entry<String,AutoBaseBLL> kvp :_context.getBllCollection().entrySet() )
		{
			Log.d("tmpQueryModelCollecton","打印输出获取数据的条件：" + tmpQueryModelCollecton.get( kvp.getKey())[1] ) ;
			if(isCache){
				datas=kvp.getValue().GetCacheData(  (HashMap<String,Object>) tmpQueryModelCollecton.get(  kvp.getKey())[1] );
				if (datas!=null) {
					CacheDataMap.put(kvp.getKey(), true);//有缓存数据时为true;
				}else {
					CacheDataMap.put(kvp.getKey(), false);
				}
			}
			else{
				datas=kvp.getValue().GetNewData(  (HashMap<String,Object>) tmpQueryModelCollecton.get(  kvp.getKey())[1] );
				isNetDatafinish=true;
				if (datas!=null) {
					NetDataMap.put(kvp.getKey(), true);//有缓存数据时为true;
				}else {
					NetDataMap.put(kvp.getKey(), false);
				}
			}
			if(datas!=null)
			{
				//默认返回缓存
				_context.getDatasourceCollection().get(  kvp.getKey() ).clear();
				_context.getDatasourceCollection().get(  kvp.getKey() ).addAll(datas);
				if (isCache) {
					//获取各个model的查询条件   这里的1获取的是各个查询条件  0是获取各个 AutoBaseBLL  
					HashMap< String , Object> modelqueries=(HashMap<String, Object>) tmpQueryModelCollecton.get( kvp.getKey())[1];
					AutoBaseBLL bll =kvp.getValue();
					if (modelqueries.containsKey(""+ AttributeRelustData.$RelustData)) {//在view层设置了是否返回缓存
						if (!(Boolean) modelqueries.get(""+ AttributeRelustData.$RelustData)) {//设置为不返回缓存
							_context.getDatasourceCollection().get(  kvp.getKey() ).clear();
						}
					}else { //在model层设置是否返回缓存
						if(bll.context.getModel().ClassAttributes().size()>0)
						{
							for(IClassAttribute attr :  bll.context.getModel().ClassAttributes())
							{
								if(TypeHelper.IsSubClassOf(attr, IsReturnData.class))
								{
									if( !((IsReturnData)attr).getIsrutuenData()){//设置为不返回数据
										_context.getDatasourceCollection().get(  kvp.getKey() ).clear();
									}
								}
							}
						}
					}
				}
			}

			/******************
			 * Hjo
			 * 网络结束后检查是否有数据
			 */
			if (isNetDatafinish) {
				if (CacheDataMap.containsKey(  kvp.getKey()  ) &&  NetDataMap.containsKey(  kvp.getKey()  ) ) {
					if (!CacheDataMap.get(  kvp.getKey()  ) && !NetDataMap.get(  kvp.getKey()  )) {
						_context.getDatasourceCollection().get(  kvp.getKey() ).clear();//缓存和网络都获取不到数据时   那添加的是上一个获取到的数据  所以需要clear掉
					}
				}
			}
			/****************/
		}
		_datasourceCombiner.CombineData(_context.getDatasourceCollection());
	}

	//设置数据源绑定
	public void CombineDatasource(DatasourceTypeEnum dsType, String newDatasourceName, String ds1, String ds2, String... keys)
	{
		_datasourceCombiner.AddCombineDatasource(newDatasourceName, ds1, ds2, keys);
		List<HashMap<String,Object>> newDatasource=new ArrayList<HashMap<String,Object>>();

		if(this._context.getDatasourceCollection().containsKey(newDatasourceName))
			this._context.getDatasourceCollection().remove(newDatasourceName);
		this._context.getDatasourceCollection().put(newDatasourceName, newDatasource);
		this.RegistQueryModel(newDatasourceName, newDatasource, dsType);
	}

	public Object[] RegistQueryModel(String name,Class<?> autoModelBaseType,DatasourceTypeEnum dsType)
	{
		if(_context.getBllCollection().containsKey(name))
		{
			///输出日志 重复
			Log.d("", String.format( "CFLog: AndroidAppCF.SuncereAutoFragment_%s_重复插件名%",this.getClass().getSimpleName(),name));
			return null;
		}
		if(autoModelBaseType==null)
		{
			Log.d("", String.format( "CFLog: AndroidAppCF.SuncereAutoFragment_%s_缺少模型类型 autoModelBaseType",this.getClass().getSimpleName()));
			return null;
		}
		AutoBaseModel model=(AutoBaseModel) TypeHelper.NewIntance(autoModelBaseType);
		if(model==null)
		{
			Log.d("", String.format( "CFLog: AndroidAppCF.SuncereAutoFragment_%s_类型 %s 实例化失败，请定义无参构造函数",this.getClass().getSimpleName(),autoModelBaseType.getName()));
			return null;
		}
		AutoBaseBLL bll= PluginLoader.Current().InitPlugin(model);

		HashMap<String,Object> queryParameters=new HashMap<String,Object>();
		List<HashMap<String,Object>> datasource=new ArrayList<HashMap<String,Object>>();

		this._context.getBllCollection().put(name, bll);

		this._context.getDatasourceCollection().put(name, datasource);
		this._context.getQueryModelCollection().put(name, new Object[]{ model, queryParameters});

//		viewAutoBinder.RegistDataSource(name, datasource,dsType);
		this.RegistQueryModel(name, datasource, dsType);

		return this._context.getQueryModelCollection().get(name);
	}

	public void RegistQueryModel(String name,Object datasource, DatasourceTypeEnum dsType)
	{
		this._context.getViewAutoBinder().RegistDataSource(name, datasource,dsType);
	}

	public boolean ShowNetworkState() {
		return false;
	}

	private class AsyncLoad extends AsyncTask<Void,Void,Void>
	{
		private Long threadId;
		private boolean hasCallCancel=false;
		private boolean hasFinish=false;
		public void cancel()
		{
			super.cancel(true);
			hasCallCancel=true;
			this.onPostExecute(null);
		}

		@Override
		protected Void doInBackground(Void... arg0) {
			_context.getAutoWrapper().OnAsyncLoadBackgroundDo();
			GetData(false);
			this.threadId=Thread.currentThread().getId();
			return null;
		}

		protected void onPostExecute(Void res)
		{
			if(hasFinish)
			{
				return ;
			}
			this.hasFinish=true;
			if(hasCallCancel)
			{
				_currentAsyncTask=null;
				return;
			}
			if(_context.getAutoWrapper().ShowNetworkState()&&  NetworkUitl.ErrorConnectionList.contains(threadId))
			{
				NetworkUitl.ErrorConnectionList.remove(threadId);
				Toast.makeText(  SuncereApplication.CurrentApplication().CurrentActivity()  , R.string.uselessnetwork, Toast.LENGTH_SHORT).show();
			}

			BindData();
			_context.getAutoWrapper().OnAsyncLoadPostExecute();
			_currentAsyncTask=null;
		}
	}

	public void UnRefreshViews(View...views )
	{
		_context.getViewAutoBinder().setUnRefreshViews( Arrays.asList( views ));
	}

	public boolean isHadNetData(boolean isHadNetData){

		return isHadNetData;
	}

}
