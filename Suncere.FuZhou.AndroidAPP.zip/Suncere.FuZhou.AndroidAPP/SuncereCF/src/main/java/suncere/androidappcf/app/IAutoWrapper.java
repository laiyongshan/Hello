package suncere.androidappcf.app;

import java.util.HashMap;
import java.util.List;

import suncere.androidapp.viewautobinder.DatasourceTypeEnum;

public interface IAutoWrapper {

	///抽象方法
	int OnGetContentView();

	void InitViews();

	void RegistQueryModels();

	void SetQueryParameter(HashMap<String, Object[]> queryModelCollection);

	void BindData(HashMap<String, List<HashMap<String, Object>>> datasourceCollection);


	///虚方法

	///在异步查询的时候执行
	void OnAsyncLoadBackgroundDo();

	///在异步查询完成时执行
	void OnAsyncLoadPostExecute();

	boolean ShowNetworkState();


	///必须实现的方法
	Object[] RegistQueryModel(String name, Class<?> autoModelBaseType);
	Object[] RegistQueryModel(String name, Class<?> autoModelBaseType, DatasourceTypeEnum dsType);
	void RegistQueryModel(String name, Object datasource);
	void RegistQueryModel(String name, Object datasource, DatasourceTypeEnum dsType);

	void CombineDatasource(DatasourceTypeEnum dsType, String newDatasourceName, String ds1, String ds2, String... keys);
	void CombineDatasource(String newDatasourceName, String ds1, String ds2, String... keys);

}
