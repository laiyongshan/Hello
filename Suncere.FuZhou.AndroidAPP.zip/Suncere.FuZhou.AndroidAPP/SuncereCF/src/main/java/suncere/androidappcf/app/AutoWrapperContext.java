package suncere.androidappcf.app;

import java.util.HashMap;
import java.util.List;

import suncere.androidapp.autobasemodule.AutoBaseBLL;
import suncere.androidapp.viewautobinder.ViewAutoBinder;

class AutoWrapperContext {
  private HashMap<String,AutoBaseBLL> _bllCollection;
  private HashMap<String,List<HashMap<String,Object>>> _datasourceCollection;
  private HashMap<String,Object[]> _queryModelCollection;
  private ViewAutoBinder _viewAutoBinder;

  //	private DatasourceCombiner _datasourceCombiner;
  private IAutoWrapper _autoWrapper;
  public AutoWrapperContext(IAutoWrapper autoWrapper)
  {
      this._autoWrapper=autoWrapper;

      this._bllCollection=new HashMap<>();
      this._datasourceCollection=new HashMap<String,List<HashMap<String,Object>>>();
      this._queryModelCollection=new HashMap<String,Object[]>();
//		this._viewAutoBinder=new ViewAutoBinder()
//		this._datasourceCombiner=new DatasourceCombiner();
  }

  public HashMap<String, AutoBaseBLL> getBllCollection() {
      return _bllCollection;
  }

  public HashMap<String, List<HashMap<String, Object>>> getDatasourceCollection() {
      return _datasourceCollection;
  }

  public HashMap<String, Object[]> getQueryModelCollection() {
      return _queryModelCollection;
  }

  public ViewAutoBinder getViewAutoBinder() {
      return _viewAutoBinder;
  }

  public IAutoWrapper getAutoWrapper() {
      return _autoWrapper;
  }

  public void setViewAutoBinder(ViewAutoBinder viewAutoBinder) {
      this._viewAutoBinder = viewAutoBinder;
  }
}
