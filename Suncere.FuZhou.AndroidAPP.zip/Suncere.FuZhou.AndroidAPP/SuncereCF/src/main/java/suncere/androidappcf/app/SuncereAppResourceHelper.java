package suncere.androidappcf.app;

public class SuncereAppResourceHelper {

//	public static  String GetString(String packageName,int name)
//	{
//		
//	}
//	
//	public static String GetString(int name)
//	{
//		
//	}
//	
//	public static String GetStrnig(String packageName,String name)
//	{
//		
//	}
//	
//	public static String GetString(String name)
//	{
//		
//	}
//	Drawable
//	Color
//	Anim

}
