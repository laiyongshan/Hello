package com.sean.lib;


public class SeanMain {

    private static final String TAG = "SeanMain";
}
