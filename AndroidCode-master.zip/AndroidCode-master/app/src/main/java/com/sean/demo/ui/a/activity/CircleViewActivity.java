package com.sean.demo.ui.a.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.sean.demo.R;

public class CircleViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_circle_view);
    }
}
