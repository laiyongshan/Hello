package com.sean.demo.ui.a.activity;

/**
 * Created by Sean on 2017/5/10 15:41.
 */

public class TestMsg {
    private String name;

    public TestMsg(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
