package com.sean.demo.ui.a.activity;

/**
 * Created by Sean on 2017/5/10 15:41.
 */

public class TestMsg1 {
    private String name;

    public TestMsg1(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
