package suncere.androidapp.lib.mvp.ui.baseui;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import suncere.androidapp.lib.mvp.ui.MyApplication;

/**
 * Created by Hjo on 2017/5/12.
 */
public class BaseActivity extends AppCompatActivity {

        private  ExitAPPBroadcast mExitAPPBroadcast;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            IntentFilter filter = new IntentFilter();
            filter.addAction("suncere.androidAPP.exitApp");
            mExitAPPBroadcast=new ExitAPPBroadcast();
            registerReceiver(mExitAPPBroadcast, filter);
        }

        public class ExitAPPBroadcast extends BroadcastReceiver{
            @Override
            public void onReceive(Context context, Intent intent) {
                if ("suncere.androidAPP.exitApp".equals(intent.getAction())) {
                    finish();
                }
            }
        }

        public  void exitAPP(){
            Intent intent = new Intent("suncere.androidAPP.exitApp");
            MyApplication.getMyApplicationContext().sendBroadcast(intent);
        }

        public void ShowExitAPP() {
            new AlertDialog.Builder(this)
                    .setTitle("提示")
                    .setMessage("确定要退出？")
                    .setNeutralButton ("确定", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int arg1) {
                            dialog.dismiss();
                            exitAPP();
                        }
                    }).setNegativeButton("取消", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int arg1) {
                    dialog.dismiss();
                }
            }).show();
        }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mExitAPPBroadcast!=null){
            unregisterReceiver(mExitAPPBroadcast);
        }
    }

}
