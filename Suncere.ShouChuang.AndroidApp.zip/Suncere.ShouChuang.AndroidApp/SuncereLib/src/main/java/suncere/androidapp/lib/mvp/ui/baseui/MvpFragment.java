package suncere.androidapp.lib.mvp.ui.baseui;

import android.os.Bundle;
import android.view.View;

import com.squareup.leakcanary.RefWatcher;

import suncere.androidapp.lib.mvp.presenter.BasePresenter;
import suncere.androidapp.lib.mvp.ui.MyApplication;


/**
 * Created by Hjo on 2017/5/11.
 */

public abstract class MvpFragment<P extends BasePresenter> extends BaseFragment {
    protected P mPresenter;

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        mPresenter = createPresenter();
        super.onViewCreated(view, savedInstanceState);
    }

    protected abstract P createPresenter();


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (mPresenter != null) {
            mPresenter.detachView();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        RefWatcher refWatcher = MyApplication.getRefWatcher(getActivity());
        refWatcher.watch(this);
    }
}
