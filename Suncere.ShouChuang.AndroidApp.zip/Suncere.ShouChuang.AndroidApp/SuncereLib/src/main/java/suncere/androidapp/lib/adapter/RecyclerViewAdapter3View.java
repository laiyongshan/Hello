package suncere.androidapp.lib.adapter;

//import android.support.v7.widget.RecyclerView;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * Created by HJO on 2017/5/14.
 * 使用dataBinding  传入两个布局
 */
public class RecyclerViewAdapter3View<T ,E> extends RecyclerView.Adapter<BindingViewHodle>{

    private final LayoutInflater mLayoutInflater;

    private int mlayout_id1,mlayout_id0;
    private int mBR0,mBR1;

//    Header和Footer
    private static final int PAGE0=0;
    private static final int PAGE1=1;


//    private List<R>mlist;//数据源
    private T mpage0Model;
    private E mpage0Mode2;
    RecyclerDataBindView mRecyclerDataBindView;

    public RecyclerViewAdapter3View(Context context, int layout_id0 , int layout_id1, int br0, int br1){
        mLayoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
//        mlist=new ArrayList<>();
        mlayout_id0=layout_id0;
        mlayout_id1=layout_id1;
        mBR0=br0;
        mBR1=br1;
//        mBR2=br2;
    }

    public void setOnRecyclerDataBindView(RecyclerDataBindView recyclerDataBindView){
        this.mRecyclerDataBindView=recyclerDataBindView;
    }

    @Override
    public int getItemViewType(int position) {
        if (position==0){
            return PAGE0;
        }else{
            return PAGE1;
        }

    }

    @Override
    public BindingViewHodle onCreateViewHolder(ViewGroup parent, int viewType) {
        ViewDataBinding binding;
        if (viewType==PAGE0){
            binding=DataBindingUtil.inflate(mLayoutInflater, mlayout_id0,parent,false);
        }else{
            binding=DataBindingUtil.inflate(mLayoutInflater, mlayout_id1,parent,false);
        }
        return new BindingViewHodle(binding);
    }

    @Override
    public void onBindViewHolder(BindingViewHodle holder, final int position) {

        if (position==0){
            holder.getBinding().setVariable(mBR0,mpage0Model);
            holder.getBinding().setVariable(mBR1,mpage0Mode2);
        }else {
//            final R model=mlist.get(position-1);
//            holder.getBinding().setVariable(mBR1,model);
//            holder.getBinding().executePendingBindings();
        }
        if (mRecyclerDataBindView!=null){
            mRecyclerDataBindView.OnBindView(  holder.getBinding(), holder.getBinding().getRoot(),position);
        }
    }
    public void setData( T model1 , E model2){//List<R> list,
//        mlist.clear();
//        mlist.addAll(list);
        mpage0Model=model1;
        mpage0Mode2=model2;
        notifyDataSetChanged();
    }

    public interface RecyclerDataBindView{
        void OnBindView(  ViewDataBinding binding, View view,int position);
    }

    @Override
    public int getItemCount() {
        return 2;
    }
}
