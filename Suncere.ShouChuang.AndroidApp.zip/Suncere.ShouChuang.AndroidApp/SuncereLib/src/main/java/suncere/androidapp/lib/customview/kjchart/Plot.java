package suncere.androidapp.lib.customview.kjchart;

import java.util.List;

public class Plot {

	public List<String> mLines;
	public int mLineColor;//折线的颜色
	public int mPointColor;//点颜色

}
