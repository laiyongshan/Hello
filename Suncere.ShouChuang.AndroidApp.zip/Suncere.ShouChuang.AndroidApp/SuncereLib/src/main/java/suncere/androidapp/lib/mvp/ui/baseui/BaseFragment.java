package suncere.androidapp.lib.mvp.ui.baseui;

import android.support.v4.app.Fragment;

/**
 * Created by Hjo on 2017/5/12.
 */

public class BaseFragment extends Fragment {
}
