package suncere.androidapp.lib.mvp.entity;

import java.io.Serializable;

/**
 * Created by Hjo on 2017/5/11.
 */

public class BaseBean implements Serializable {
}
