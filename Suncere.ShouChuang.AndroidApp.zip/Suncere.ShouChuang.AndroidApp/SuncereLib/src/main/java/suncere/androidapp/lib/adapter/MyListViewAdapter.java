package suncere.androidapp.lib.adapter;

import android.content.Context;
import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Hjo on 2017/12/7 17:45.
 */

public class MyListViewAdapter <T> extends BaseAdapter {

    private final LayoutInflater mLayoutInflater;
    private int mlayout_id;
    private int mBR;
    private List<T> mlist;//数据源
    private int tag=0;


    ListViewOnItmeClickListener mListViewOnItmeClickListener;
    ListViewOnBindItmeView mListViewOnBindItmeView;

    int mselectPosistion=0;
    boolean isUserBg=false;


    public MyListViewAdapter(Context context, int layout_id , int br){
        mLayoutInflater=(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        mlist=new ArrayList<>();
        mlayout_id=layout_id;
        mBR=br;
    }

    public int getTag() {
        return tag;
    }

    public void setTag(int mtag) {
        this.tag = mtag;
    }
    public void setOnItmeClickListener(ListViewOnItmeClickListener listViewOnItmeClickListener){
        this.mListViewOnItmeClickListener=listViewOnItmeClickListener;
    }

    public void setOnBindItmeView(ListViewOnBindItmeView listViewOnBindItmeView){
        this.mListViewOnBindItmeView=listViewOnBindItmeView;
    }



    @Override
    public int getCount() {
        return mlist.size();
    }

    @Override
    public Object getItem(int position) {
        return mlist.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void setData(List<T> list){
        mlist.clear();
       if (null!=list)mlist.addAll(list);
        notifyDataSetChanged();

    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final T model=mlist.get(position);
//        BindingViewHodle holder;
        ViewDataBinding binding=null ;
        if (convertView==null){
            convertView = mLayoutInflater.inflate(mlayout_id, parent,false);
//            binding= DataBindingUtil.inflate(mLayoutInflater, mlayout_id,parent,false);
            binding= DataBindingUtil.bind(convertView);
//            holder=new BindingViewHodle(binding);
        }else{
            binding = DataBindingUtil.getBinding(convertView);
//            holder= (BindingViewHodle) binding.g;
        }
        if (mListViewOnItmeClickListener!=null) {
            mListViewOnItmeClickListener.OnItemClick(model,position,tag);
        }
        binding.setVariable(mBR,model);
//        binding.executePendingBindings();

        if (mListViewOnBindItmeView!=null){
            mListViewOnBindItmeView.OnBindItmeView( binding.getRoot(),model,position,mselectPosistion,tag);
        }
        return binding.getRoot();
    }


    public interface ListViewOnItmeClickListener{
        void OnItemClick(Object obejct, int position, int tag);
    }

    public interface ListViewOnBindItmeView{ //对itme中的布局进行操作
        void OnBindItmeView(View view, Object obejct, int position, int selectPosition, int tag);
    }
}
