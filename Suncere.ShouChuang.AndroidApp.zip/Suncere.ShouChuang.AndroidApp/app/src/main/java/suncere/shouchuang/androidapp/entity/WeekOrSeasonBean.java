package suncere.shouchuang.androidapp.entity;

import com.bigkoo.pickerview.model.IPickerViewData;

/**
 * Created by Hjo on 2017/11/30 11:33.
 */

public class WeekOrSeasonBean implements IPickerViewData {

    String year;

    public WeekOrSeasonBean(String year) {
        this.year = year;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    @Override
    public String getPickerViewText() {
        return year;
    }
}
