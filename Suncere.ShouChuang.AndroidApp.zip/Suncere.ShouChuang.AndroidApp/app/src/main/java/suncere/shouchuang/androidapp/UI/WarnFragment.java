package suncere.shouchuang.androidapp.UI;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.adapter.RecyclerViewAdapter;
import suncere.androidapp.lib.mvp.ui.baseui.MvpFragment;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.ColorUtils;
import suncere.shouchuang.androidapp.BR;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.entity.WarnDataBean;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;

/**
 * Created by Hjo on 2018/1/18 15:15.
 */

public class WarnFragment extends  MvpFragment<BasePresenterChild> implements IBaseView,SwipeRefreshLayout.OnRefreshListener {

    @BindView(R.id.warn_SwipeRefreshLayout)
    SwipeRefreshLayout mwarn_SwipeRefreshLayout;
    @BindView(R.id.warn_recyclerView)
    RecyclerView mwarn_recyclerView;
    @BindView(R.id.warn_level_select_tv)
    TextView warn_level_select_tv;

    @BindView(R.id.null_data)
    LinearLayout null_data;

    RecyclerViewAdapter <WarnDataBean> madapter;
    BasePresenterChild mBasePresenterChild;
    CustomPopWindow mSelectLevelWindow;
    View mSelectView;
    List<WarnDataBean>  mlistData;
    List<WarnDataBean>  mSelectData;
    String mSelectLevel="中等";


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.warn_fragment,container,false);
        ButterKnife.bind(this,view);
        initView();
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        getData();
    }

    private void initView(){
        mwarn_SwipeRefreshLayout.setColorSchemeColors(ColorUtils.Colors);
        mwarn_SwipeRefreshLayout.setOnRefreshListener(this);

        madapter=new RecyclerViewAdapter<>(getActivity(),R.layout.warn_recyclerview_itme, BR.warnDataBean);
        mwarn_recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mwarn_recyclerView.setAdapter(madapter);

        mSelectView = LayoutInflater.from(getActivity()).inflate(R.layout.warn_level_layout,null);
        bindSelectPollutantListener(mSelectView);
        mSelectLevelWindow= new CustomPopWindow.PopupWindowBuilder(getActivity()).setView(mSelectView).create();
        mlistData=new ArrayList<>();
        mSelectData=new ArrayList<>();
    }

    private void getData(){
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().warnData("0"));
    }

    @Override
    public void getDataSuccess(Object response) {
        mlistData.clear();
        if (response!=null){
            mlistData.addAll((List<WarnDataBean>) response);
        }
        findSelectData();
    }

    @Override
    public void getDataFail(String msg) {}


    @OnClick(R.id.warn_level_select_lin)
    public void on_clcik(View view){
        showSelectPollutant();
    }


    private void showSelectPollutant(){
        mSelectLevelWindow .showAsDropDown(warn_level_select_tv,6,-(warn_level_select_tv.getHeight()+mSelectLevelWindow.getHeight()));
    }

    private void bindSelectPollutantListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mSelectLevelWindow!=null){
                    mSelectLevelWindow.dissmiss();
                }
                mSelectLevel=((TextView)v).getText().toString();
                warn_level_select_tv.setText(mSelectLevel);
                findSelectData();
            }
        };
        contentView.findViewById(R.id.warn_level_0).setOnClickListener(listener);
        contentView.findViewById(R.id.warn_level_1).setOnClickListener(listener);
        contentView.findViewById(R.id.warn_level_2).setOnClickListener(listener);
    }

    private void findSelectData(){
        mSelectData.clear();
        for (WarnDataBean bean :mlistData){
            if (mSelectLevel.equals(bean.getAlarmLevel())){
                mSelectData.add(bean);
            }
        }
        if (mSelectData.size()==0){
            null_data.setVisibility(View.VISIBLE);
        }else{
            null_data.setVisibility(View.GONE);
        }
        madapter.setData(mSelectData);
    }

    @Override
    public void showRefresh() {
        mwarn_SwipeRefreshLayout.setRefreshing(true);
    }
    @Override
    public void finishRefresh() {
        mwarn_SwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    protected BasePresenterChild createPresenter() {
        mBasePresenterChild=new BasePresenterChild(this);
        return mBasePresenterChild;
    }

    @Override
    public void onRefresh() {
        getData();
    }
}
