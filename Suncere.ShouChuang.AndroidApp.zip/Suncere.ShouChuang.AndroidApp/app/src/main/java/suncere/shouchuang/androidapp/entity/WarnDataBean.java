package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2018/1/18 16:19.
 */

public class WarnDataBean extends BaseBean{
//         "Name": "鲁南制药厂",
//                 "TimePoint": "2017/11/29 17:37:54",
//                 "AlarmType": "污染物浓度超标报警",
//                 "AlarmStatus": "报警中",
//                 "AlarmLevel": "一般",
//                 "Description": "浓度超标"

    private String Name;
    private String TimePoint;
    private String AlarmType;
    private String AlarmStatus;
    private String AlarmLevel;
    private String Description;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getTimePoint() {
        return TimePoint;
    }

    public void setTimePoint(String timePoint) {
        TimePoint = timePoint;
    }

    public String getAlarmType() {
        return AlarmType;
    }

    public void setAlarmType(String alarmType) {
        AlarmType = alarmType;
    }

    public String getAlarmStatus() {
        return AlarmStatus;
    }

    public void setAlarmStatus(String alarmStatus) {
        AlarmStatus = alarmStatus;
    }

    public String getAlarmLevel() {
        return AlarmLevel;
    }

    public void setAlarmLevel(String alarmLevel) {
        AlarmLevel = alarmLevel;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }
}
