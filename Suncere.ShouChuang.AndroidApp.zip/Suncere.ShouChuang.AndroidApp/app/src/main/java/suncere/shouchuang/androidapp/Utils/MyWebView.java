package suncere.shouchuang.androidapp.Utils;

import android.annotation.SuppressLint;
import android.util.Log;

import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;


/**
 * Created by Hjo on 2017/12/26 17:11.
 */

public class MyWebView   {

    WebView mWebView;
    String murl;

    public MyWebView(WebView mWebView,String url) {
        this.mWebView = mWebView;
        this.murl=url;
        initView();
    }

    @SuppressLint("JavascriptInterface")
    private void initView(){

        // 腾讯设置
//        WebSettings webSetting = mWebView.getSettings();
//        webSetting.setJavaScriptCanOpenWindowsAutomatically(true);
//        webSetting.setAllowFileAccess(true);
//        webSetting.setSupportZoom(true);
//        webSetting.setBuiltInZoomControls(true);
//        webSetting.setUseWideViewPort(true);
//        webSetting.setSupportMultipleWindows(true);
//        webSetting.setAppCacheEnabled(true);
//        webSetting.setDomStorageEnabled(true);
//        webSetting.setGeolocationEnabled(true);
//        webSetting.setAppCacheMaxSize(Long.MAX_VALUE);
//        webSetting.setPluginState(WebSettings.PluginState.ON_DEMAND);
//        webSetting.setCacheMode(WebSettings.LOAD_NO_CACHE);

        // 我的设置
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setUseWideViewPort(true);//设置webview推荐使用的窗口
        webSettings.setLoadWithOverviewMode(true);//设置webview加载的页面的模式
        webSettings.setDisplayZoomControls(false);//隐藏webview缩放按钮
        webSettings.setJavaScriptEnabled(true); // 设置支持javascript脚本
        webSettings.setAllowFileAccess(true); // 允许访问文件
        webSettings.setBuiltInZoomControls(true); // 设置显示缩放按钮
        webSettings.setSupportZoom(true); // 支持缩放
        webSettings.setLoadWithOverviewMode(true);

        // 地图设置
//        WebSettings webSettings = mWebView.getSettings();
//        String ua = webSettings.getUserAgentString();
//        webSettings.setUserAgentString(ua.replace("Android", "AndroidApp"));
//        webSettings.setJavaScriptEnabled(true);
//        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
//        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        mWebView.loadUrl(murl);
        Log.e("map","mapurl:"+mWebView.getUrl());
        mWebView.setWebViewClient(new MyWebViewClient());
        mWebView.addJavascriptInterface(this, "android");
    }

    private static class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
        }
    }

}
