package suncere.shouchuang.androidapp.UI;

import android.content.DialogInterface;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.adapter.MyListViewAdapter;
import suncere.androidapp.lib.adapter.ViewHolder;
import suncere.androidapp.lib.customview.PollutantNameTextView;
import suncere.androidapp.lib.mvp.entity.BaseBean;
import suncere.androidapp.lib.mvp.ui.baseui.MvpFragment;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.ColorUtils;
import suncere.shouchuang.androidapp.BR;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.HomeSort;
import suncere.shouchuang.androidapp.Utils.TimeType;
import suncere.shouchuang.androidapp.Utils.ToolUtils;
import suncere.shouchuang.androidapp.customview.ChartSet;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.customview.LineChartView;
import suncere.shouchuang.androidapp.customview.MyListView;
import suncere.shouchuang.androidapp.customview.PollutantsView;
import suncere.shouchuang.androidapp.databinding.HomeFragmentBinding;
import suncere.shouchuang.androidapp.entity.AllCityBean;
import suncere.shouchuang.androidapp.entity.HomeAQIListBean;
import suncere.shouchuang.androidapp.entity.HomeChartBean;
import suncere.shouchuang.androidapp.entity.HomeCityBean;
import suncere.shouchuang.androidapp.entity.HomeListCityBean;
import suncere.shouchuang.androidapp.presenter.HomePresenter;


/**
 * Created by Hjo on 2017/11/10 11:55.
 */
public class HomeFragment extends MvpFragment<HomePresenter> implements IBaseView ,
        SwipeRefreshLayout.OnRefreshListener,MyListViewAdapter.ListViewOnBindItmeView{

//    @BindView(R.id.home_page_2_recyclerView)
//    RecyclerView mrecyclerView;

    @BindView(R.id.home_page_2_MyListView)
    MyListView myListView;

//    @BindView(R.id.home_page_1_chart_ChartView)
//    ChartView mChartView;

//    @BindView(R.id.home_refresh_image)
//    ImageView refresh_image;

    @BindView(R.id.home_page_1_chart_PollutantsView)
    PollutantsView mChart_PollutantsView;

    @BindView(R.id.home_UpOrDown_data_image)
    ImageView home_UpOrDown_data_image;

    @BindView(R.id.home_page_2_chart_PollutantsView)
    PollutantsView mPollutantsView_AQI;
    @BindView(R.id.home_title)
    TextView mhome_title;

    @BindView(R.id.home_page_1_time)
    TextView home_page_1_time;
    @BindView(R.id.home_page_1_cityList_time)
    TextView home_page_1_cityList_time;
    @BindView(R.id.home_page_2_list_time)
    TextView home_page_2_list_time;
    @BindView(R.id.home_page_2_compare_tag)
    TextView home_page_2_compare_tag;

    @BindView(R.id.hoem_page_2_allStation_lin)
    LinearLayout hoem_page_2_allStation_lin;

    @BindView(R.id.home_refresh_SwipeRefreshLayout)
    SwipeRefreshLayout mswipeRefreshLayout;

    @BindView(R.id.home_page_1_chart_LineChartView)
    LineChartView mLineChartView;

    @BindView(R.id.home_page_2_list_pollutants)
    TextView mPollutantTextView;

    @BindView(R.id.home_page_2_level_tag)
    TextView home_page_2_level_tag;

    @BindView(R.id.hoem_page_2_station_Compare_otherCity)
    TextView mOtherCity;

    @BindView(R.id.home_page_2_AQI_tag)
    TextView home_page_2_AQI_tag;

    @BindView(R.id.home_page_1_city_con)
    LinearLayout mhome_page_1_city_con28CityLin;
    @BindView(R.id.null_data)
    LinearLayout null_data;

    HomePresenter mBasePresenterChild;
    String mCityCode="42c5e010-05a6-4bee-b35a-ac6a4b6a4caf";
    String mDefaultStationCode="5158dc6a-7f52-4425-89eb-df4d774b2c16";// 默认显示的站点code
    String mPollutantName="AQI";
    String mTimeType="3";
    HomeFragmentBinding mBinding;
    String mCityName="北京市";
    String mStationName="朝阳区";

//    RecyclerViewAdapter<HomeAQIListBean>mAdapter;
    MyListViewAdapter<HomeAQIListBean> mListViewAdapter;
    List<String > mYvalue;
    List<String > mXvalue;
    List<Integer> mColors;
    CharSequence[] mTitleCityNames;
    List<AllCityBean> mAllCityDataList;
    List<HomeAQIListBean> mHomeAQIListBeanData;
    boolean isUpOrDown=true;// true 为正序

    ChartSet mChartSet;
    CustomPopWindow mCustomPopWindowPollutant;
    String mPollutantCode="AQI";
    boolean isCity28=true;
    boolean  isgetHomeAQIListBeanData=false;

String []Cities28={
        "北京市","天津市","石家庄市","唐山市","保定市",
        "廊坊市","沧州市","衡水市","邯郸市","邢台市",
        "太原市", "阳泉市","长治市","晋城市","济南市",
        "淄博市","聊城市","德州市","滨州市","济宁市",
        "菏泽市","郑州市","新乡市","鹤壁市","安阳市",
        "焦作市","濮阳市","开封市"};

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mBinding= DataBindingUtil.inflate(inflater,R.layout.home_fragment,container,false);
        ButterKnife.bind(this,mBinding.getRoot());
        initView ();
        return mBinding.getRoot();
    }

    @Override
    protected HomePresenter createPresenter() {
        mBasePresenterChild=new HomePresenter(this);
        return mBasePresenterChild;
    }

    @Override
    public void onStart() {
        super.onStart();
        getData();
    }

   private void  initView (){
       mListViewAdapter=new MyListViewAdapter<>(getActivity(),R.layout.home_recyclerview_itme, BR.homeAQIListBean);
       mListViewAdapter.setOnBindItmeView(this);
       myListView.setAdapter(mListViewAdapter);

       mswipeRefreshLayout.setColorSchemeColors(ColorUtils.Colors);
       mswipeRefreshLayout.setOnRefreshListener(this);

//       mAdapter=new RecyclerViewAdapter<>(getActivity(),R.layout.home_recyclerview_itme, BR.homeAQIListBean);
//       mrecyclerView.setHasFixedSize(true);
//       mrecyclerView.setNestedScrollingEnabled(false);
//       FullyLinearLayoutManager linearLayoutManager=new FullyLinearLayoutManager(getActivity());
//       mrecyclerView.setLayoutManager(linearLayoutManager );//new LinearLayoutManager(getActivity())
//       mrecyclerView.setAdapter(mAdapter);
       mChartSet=new ChartSet();
       mYvalue=new ArrayList<>();
       mXvalue=new ArrayList<>();
       mColors=new ArrayList<>();
//       mChartView.mIs_AccordingTo_List_SetMin = true;
//       mChartView.isNeedMinValueMoreSmall = true;
//       mChartView.mYLineColor = Color.WHITE;
//       mChartView.mXLineColor = Color.WHITE;
//       mChartView. mIsShowPointColor=true;
//       mChartView.mLineColor=Color.WHITE;
//       mChartView.mdefaulYValueTextColor=Color.WHITE;
//       mChartView.mXAxisEveryFewParagraphs=1;

//       mChartView.mIsShowPiontToBottomBg=true;
//       mChartView.mXScaleWidth= mChartView.dp2px(40);
//       mChartView.mXAxisTextColor = Color.WHITE;
//       mChartView.mYAxisTextColor = Color.WHITE;
//       mChartView.PiontToBottomBgColor=Color.parseColor("#33aaaaaa");

       mHomeAQIListBeanData=new ArrayList<>();

       mChartSet.setColorDotted(Color.WHITE);
       mChartSet.setColorLine(Color.WHITE);
       mChartSet.setColorTextValue(Color.WHITE);
       mChartSet.setColorXY(Color.WHITE);
       mChartSet.setColorTextXY(Color.WHITE);
       mChartSet.setColorBg(Color.parseColor("#33aaaaaa"));

       mAllCityDataList=new ArrayList<>();
       mChart_PollutantsView.setmSelceTextListener(new PollutantsView.SelceTextListener() {
           @Override
           public boolean onSelect(View view,String pollutantName, String pollutantCode) {
               mPollutantName=pollutantName;
               if ("PM2.5".equals(mPollutantName))mPollutantName="PM2_5";
               getHomeChartData();
               return true;
           }
       });
       mPollutantsView_AQI.setmSelceTextListener(new PollutantsView.SelceTextListener() {
           @Override
           public boolean onSelect(View view,String pollutantName, String pollutantCode) {
               mTimeType=pollutantCode;
               if (mTimeType.equals(TimeType.LiveTime.getIndex()+"")  ||  mTimeType.equals(TimeType.DayTime.getIndex()+"")){
                   home_page_2_compare_tag.setVisibility(View.GONE);
                   home_page_2_level_tag.setVisibility(View.VISIBLE);
                  if (mPollutantTextView.getText().equals("综合指数"))mPollutantTextView.setText("AQI");
               } else{
                   home_page_2_compare_tag.setVisibility(View.VISIBLE);
                   home_page_2_level_tag.setVisibility(View.GONE);
                   if (mPollutantTextView.getText().equals("AQI"))mPollutantTextView.setText("综合指数");
               }
               if (mPollutantTextView.getText().equals("综合指数")){
                   home_page_2_AQI_tag.setText("综合指数");
               }else{
                   home_page_2_AQI_tag.setText("浓度值");
               }
               mPollutantCode=mPollutantTextView.getText().toString();
               if (mPollutantCode.equals("综合指数"))mPollutantCode="ComplexIndex";
                   getHomeAQIListData();
               return true;
           }
       });
    }

    private void  getData(){
        if (mAllCityDataList==null || mAllCityDataList.size()==0)  getAllCityData();// 获取城市列表
        getAllData();
    }

    private void getAllData() {
//        Observable observable1=mBasePresenterChild.getRetrofitSrevice().homecity(mCityCode);
//        Observable observable2=mBasePresenterChild.getRetrofitSrevice().homelistcity(mCityCode);
//        Observable observable3=mBasePresenterChild.getRetrofitSrevice().homeChart(mCityCode,mPollutantName);
//        Observable observable4=mBasePresenterChild.getRetrofitSrevice().homeAQIListBean(mCityCode,TimeType);
//        Observable observable=Observable.merge(observable1,observable2,observable3,observable4);
//        mBasePresenterChild.getCatchOrNetData(observable, "homeData");
        getHomeCityAndData();
        if (isCity28) getHomeListCityData();
        getHomeChartData();
        getHomeAQIListData();
    }

    private void getHomeCityAndData(){
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().homecity(mCityCode),"homecity"+mCityCode);
    }

    private void getHomeListCityData(){
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().homelistcity(mCityCode),"HomeListCity"+mCityCode);
    }

    private void getHomeChartData(){
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().homeChart(mCityCode,mPollutantName),"HomeChart"+mCityCode+mPollutantName);
    }

    private void getHomeAQIListData(){
        if ("PM2.5".equals(mPollutantCode))mPollutantCode="PM2_5";
        mHomeAQIListBeanData.clear();
        isgetHomeAQIListBeanData=true;
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().homeAQIListBean(mCityCode,mTimeType,mPollutantCode),"HomeAQIList"+mCityCode+mTimeType);
    }

    private void getAllCityData(){
        mBasePresenterChild.getAllcity(mBasePresenterChild.getRetrofitSrevice().allcity(),"AllCity");
    }

    @Override
    public void getDataSuccess(Object response) {

        if(response!=null){
            if (response instanceof HomeListCityBean){ //  城市空气质量排名
                home_page_1_cityList_time.setText(ToolUtils.getLastTimeHour()+"更新");
                mBinding.setVariable(BR.homeListCityBean,(HomeListCityBean)response);
            }else{
                List<BaseBean> list= (List<BaseBean>) response;
                if (list.size()>0){
                    if (list.get(0) instanceof HomeChartBean){  // 图表
                        bindHomeChartData((List<HomeChartBean>) response);
                    }else if (list.get(0) instanceof HomeAQIListBean){ // 市内国控点空气质量排名
                        home_page_2_list_time.setText(ToolUtils.getLastTimeHour()+"更新");
                        mHomeAQIListBeanData.addAll((List<HomeAQIListBean>) response);
                        isgetHomeAQIListBeanData=false;
                        null_data.setVisibility(View.GONE);
                        findCity2Frist();
                    }else if(list.get(0) instanceof HomeCityBean){  // 城市数据
                        home_page_1_time.setText(ToolUtils.getLastTimeHour()+"更新");
                        mBinding.setVariable(BR.homecityData,(HomeCityBean)list.get(0));
                    }else if ( list.get(0) instanceof AllCityBean ){  // 头部城市列表
                        mAllCityDataList.clear();
                        mAllCityDataList.addAll((List<AllCityBean>) response);
                        mTitleCityNames=new CharSequence[mAllCityDataList.size()];
                        for (int i=0;i<mAllCityDataList.size();i++ ){
                            AllCityBean bean=mAllCityDataList.get(i);
                            mTitleCityNames[i]=bean.getName();
                        }
                    }
                }
            }
        }else{
           if (mHomeAQIListBeanData.size()==0  && isgetHomeAQIListBeanData){
               isgetHomeAQIListBeanData=false;
               null_data.setVisibility(View.VISIBLE);
               mListViewAdapter.setData(mHomeAQIListBeanData);
           }
        }
    }


    @OnClick({R.id.home_title,
            R.id.home_page_1_cityList_live,R.id.home_page_1_cityList_data,R.id.home_page_1_cityList_yeat,R.id.home_page_1_cityList_month,
            R.id.home_page_1_cityList_yesterDaya,
            R.id.hoem_page_2_station_live,R.id.hoem_page_2_station_day,
            R.id.hoem_page_2_station_Compare_chaoyang, R.id.hoem_page_2_station_Compare_shunyi, R.id.hoem_page_2_station_Compare_shijingshan,
            R.id.home_UpOrDown_data_lin,R.id.home_page_2_list_pollutants,
            R.id.hoem_page_2_station_Compare_otherCity})
    public void on_click(View view){
        switch (view.getId()){
           /* case R.id.home_refresh:
                getData();
                break;*/
            case R.id.home_title:
                showCitySelectAlertDialog();
                break;
            case R.id.hoem_page_2_station_live:
                startIntoActivity(HomeCityStationActivity.class,view.getTag().toString());
                break;
            case R.id.hoem_page_2_station_Compare_otherCity:
                startIntoActivity(HomeCityStationActivity.class,view.getTag().toString());
                break;
            case R.id.hoem_page_2_station_day:
                startIntoActivity(HomeCityStationActivity.class,view.getTag().toString());
                   break;
            case R.id.hoem_page_2_station_Compare_chaoyang:
                startIntoActivity(HomeCompareStationActivity.class,view.getTag().toString());
                break;
            case R.id.hoem_page_2_station_Compare_shunyi:
                startIntoActivity(HomeCompareStationActivity.class,view.getTag().toString());
                break;
            case R.id.hoem_page_2_station_Compare_shijingshan:
                startIntoActivity(HomeCompareStationActivity.class,view.getTag().toString());
                break;
            case R.id.home_UpOrDown_data_lin:
                isUpOrDown=!isUpOrDown;
                if (isUpOrDown){
                    home_UpOrDown_data_image.setImageResource(R.mipmap.home_up);
                }else{
                    home_UpOrDown_data_image.setImageResource(R.mipmap.home_down);
                }
                findCity2Frist();
                break;
            case R.id.home_page_2_list_pollutants:
                showPollutantMenu();
                break;
                default:
                    startIntoActivity(HomeListCityActivity.class,view.getTag().toString());
                break;
        }
    }

    private void findCity2Frist(){
        if (mHomeAQIListBeanData!=null  && mHomeAQIListBeanData.size()>0)
            Collections.sort(mHomeAQIListBeanData,new HomeSort(isUpOrDown));
        mListViewAdapter.setData(mHomeAQIListBeanData);
//        mAdapter.setData(mHomeAQIListBeanData);
    }

    private void startIntoActivity(Class cla,String tag){
        Intent intent=new Intent(getActivity(),cla);
        intent.putExtra("CityName",mCityName);
        intent.putExtra("CityCode",mCityCode);
        intent.putExtra("DefaultStationCode",mDefaultStationCode);
        intent.putExtra("ReportTimeType",tag);
        intent.putExtra("StationName",mStationName);
        startActivity(intent);
    }

    private void bindHomeChartData(List<HomeChartBean> listData){
            mYvalue.clear();
            mXvalue.clear();
            mColors.clear();
            if (listData!=null && listData.size()>0) {
                for (HomeChartBean bean : listData) {
                    mYvalue.add(bean.getYValue());
                    mColors.add(ColorUtils.getColorWithLevel(bean.getLevel()));
                    mXvalue.add(ToolUtils.stringToData(bean.getTimePoint(), "yyyy/MM/dd HH:mm:ss", "HH:mm"));
                }
            }
//            mChartView.mPointColors=mColors;
//            mChartView.bindSingleLineChart(mYvalue,mXvalue);
//            mChartView.refreshChartView();
//            mChartView.mIs_AccordingTo_PointLabelValue_JudgmentColor=false;

        mChartSet.setmXVaule(mXvalue);
        mChartSet.setmStringYVaule(mYvalue);
        mChartSet.setmColors(mColors);

        mLineChartView.setData(mChartSet);
//        mLineChartView.setData(mXvalue,mYvalue);
    }

    private void showCitySelectAlertDialog() {
        new AlertDialog.Builder(getActivity())
                .setTitle("请选择城市")
                .setItems(mTitleCityNames,
                        new AlertDialog.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface sender, int index) {
                                mCityCode = mAllCityDataList.get(index).getId();
                                mhome_title.setText(mTitleCityNames[index]);

                                for(int i =0;i<Cities28.length;i++){
                                    if (mTitleCityNames[index].equals(Cities28[i])){
                                        isCity28=true;
                                        break;
                                    }else{
                                        isCity28=false;
                                    }
                                }
                                mhome_page_1_city_con28CityLin.setVisibility(isCity28? View.VISIBLE:View.GONE);
                                mCityName=  mTitleCityNames[index].toString();
                                if ("北京市".equals(mTitleCityNames[index])){
                                    mStationName="朝阳区";
                                    mDefaultStationCode="5158dc6a-7f52-4425-89eb-df4d774b2c16"; // 朝阳区
                                    hoem_page_2_allStation_lin.setVisibility(View.VISIBLE);
                                    mOtherCity.setVisibility(View.GONE);
                                }else if ("唐山市".equals(mTitleCityNames[index])){
                                    mStationName="遵化市";
                                    mDefaultStationCode="0B563FAB-A9B4-41C5-93D3-515D0182302F"; // 遵化市
                                    hoem_page_2_allStation_lin.setVisibility(View.GONE);
                                    mOtherCity.setVisibility(View.VISIBLE);
                                    mOtherCity.setText("遵化市站点实时数据");
                                }else if ("郑州市".equals(mTitleCityNames[index])){
                                    mStationName="上街区";
                                    mDefaultStationCode="765E7B7F-F241-4FF9-86A2-1B8E0625B975"; // 上街区
                                    hoem_page_2_allStation_lin.setVisibility(View.GONE);
                                    mOtherCity.setVisibility(View.VISIBLE);
                                    mOtherCity.setText("上街区站点实时数据");
                                }else if ("淮南市".equals(mTitleCityNames[index])){
                                    mStationName="潘集区";
                                    mDefaultStationCode="40F453B9-5615-49D5-BE72-591DDAA5A815"; // 潘集区
                                    hoem_page_2_allStation_lin.setVisibility(View.GONE);
                                    mOtherCity.setVisibility(View.VISIBLE);
                                    mOtherCity.setText("潘集区站点实时数据");
                                } else{
                                    hoem_page_2_allStation_lin.setVisibility(View.GONE);
                                    mOtherCity.setVisibility(View.GONE);
                                }
                                getData();
                            }
                        }).show();
    }


    private void showPollutantMenu(){
        View contentView = LayoutInflater.from(getActivity()).inflate(R.layout.map_chart_pollutant_itme,null);
        PollutantMenuListener(contentView);
        if ("3".equals(mTimeType)){
            ((PollutantNameTextView)contentView.findViewById(R.id.O3)).setText("O3");
        }
        mCustomPopWindowPollutant= new CustomPopWindow.PopupWindowBuilder(getActivity()).setView(contentView).create();
        mCustomPopWindowPollutant.showAsDropDown(mPollutantTextView,0,10);
    }

    private void PollutantMenuListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCustomPopWindowPollutant!=null){
                    mCustomPopWindowPollutant.dissmiss();
                }
                mPollutantCode=((TextView)v).getText().toString();
                mPollutantTextView.setText(mPollutantCode);
                if (mPollutantCode.equals("综合指数"))mPollutantCode="ComplexIndex";
                if (mPollutantTextView.getText().equals("综合指数")){
                    home_page_2_AQI_tag.setText("综合指数");
                }else{
                    home_page_2_AQI_tag.setText("浓度值");
                }
              getHomeAQIListData();
            }
        };
        TextView AQITextView=contentView.findViewById(R.id.AQI);
        if (mTimeType.equals(TimeType.LiveTime.getIndex()+"")  ||  mTimeType.equals(TimeType.DayTime.getIndex()+"")){
            AQITextView.setText("AQI");
        }else{
            AQITextView.setText("综合指数");
        }
        AQITextView .setOnClickListener(listener);
        contentView.findViewById(R.id.SO2).setOnClickListener(listener);
        contentView.findViewById(R.id.NO2).setOnClickListener(listener);
        contentView.findViewById(R.id.CO).setOnClickListener(listener);
        contentView.findViewById(R.id.O3).setOnClickListener(listener);
        contentView.findViewById(R.id.PM2_5).setOnClickListener(listener);
        contentView.findViewById(R.id.PM10).setOnClickListener(listener);
    }

    @Override
    public void getDataFail(String msg) {
        mswipeRefreshLayout.setRefreshing(false);
//        refresh_image.clearAnimation();
    }

    @Override
    public void showRefresh() {
        mswipeRefreshLayout.setRefreshing(true);
//        refresh_image.setAnimation(ToolUtils.getRefreshAnimation());
    }

    @Override
    public void finishRefresh() {
        mswipeRefreshLayout.setRefreshing(false);
//        refresh_image.clearAnimation();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
//        if (mChartView!=null){
//            mChartView=null;
//        }
        if (mChart_PollutantsView!=null){
            mChart_PollutantsView=null;
        }
        if (mPollutantsView_AQI!=null){
            mPollutantsView_AQI=null;
        }
    }


    @Override
    public void onRefresh() {
        getData();
    }

    @Override
    public void OnBindItmeView(View view, Object obejct, int position, int selectPosition, int tag) {
        HomeAQIListBean bean= (HomeAQIListBean) obejct;
        TextView compareText= ViewHolder.getView(view,R.id.home_page_2_listItme_compare);
        TextView level= ViewHolder.getView(view,R.id.home_page_2_listItme_level);
        TextView value= ViewHolder.getView(view,R.id.home_page_2_listItme_value);
        value.setText(bean.getValue());
        if (mTimeType.equals(TimeType.LiveTime.getIndex()+"")  ||  mTimeType.equals(TimeType.DayTime.getIndex()+"")  ){
            compareText.setVisibility(View.GONE);
            level.setVisibility(View.VISIBLE);
            value.setBackground(ColorUtils.getDrawableBgFromLevel(bean.getValue_Level()));
        } else {
            compareText.setVisibility(View.VISIBLE);
            level.setVisibility(View.GONE);
            value.setBackground(getResources().getDrawable(R.drawable.round_rect_aqi_transparent));
        }
    }
}
