package suncere.shouchuang.androidapp.Utils;

import java.util.Comparator;

import suncere.shouchuang.androidapp.entity.ListBean;

/**
 * Created by Hjo on 2017/6/6.
 */

public class ListSort implements Comparator<ListBean> {

    private boolean misSequence;//正序为true 倒序为false
    public ListSort(boolean isSequence){
        this.misSequence=isSequence;
    }

    @Override
    public int compare(ListBean object1, ListBean object2) {
       ListBean  before=misSequence? object1:object2;
        ListBean  after=misSequence? object2:object1;

        Integer beforeRank=0;
        Integer afterRank=0;
        try{
            beforeRank=Integer.valueOf(before.getRank());
        }catch ( Exception  e  ){
            beforeRank=9999;
        }
        try{
            afterRank=Integer.valueOf(after.getRank());
        }catch ( Exception  e  ){
            afterRank=9999;
        }
        int flag=beforeRank.compareTo( afterRank);
//        int flag=(Integer.valueOf(before.getRank())).compareTo(Integer.valueOf(after.getRank()));
        if(flag==0)
            return before.getStatioinCode().toString().compareTo(after.getStatioinCode().toString());

        return flag;
    }
}
