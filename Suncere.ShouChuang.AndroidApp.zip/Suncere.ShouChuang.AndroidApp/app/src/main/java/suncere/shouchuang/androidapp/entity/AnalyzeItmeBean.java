package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/28 15:46.
 */

public class AnalyzeItmeBean extends BaseBean {

    String ItmeName;
    String ItmeId;
    String TimeType;
    String TimeTypeId;
    String Time;
//    public AnalyzeItmeBean(){
//    }
    public AnalyzeItmeBean(  String ItmeName, String ItmeId, String TimeType, String TimeTypeId, String Time){
        this.ItmeName=ItmeName;
        this.ItmeId=ItmeId;
        this.TimeType=TimeType;
        this.TimeTypeId=TimeTypeId;
        this.Time=Time;
    }

    public String getItmeName() {
        return ItmeName;
    }

    public void setItmeName(String itmeName) {
        ItmeName = itmeName;
    }

    public String getItmeId() {
        return ItmeId;
    }

    public void setItmeId(String itmeId) {
        ItmeId = itmeId;
    }

    public String getTimeType() {
        return TimeType;
    }

    public void setTimeType(String timeType) {
        TimeType = timeType;
    }

    public String getTimeTypeId() {
        return TimeTypeId;
    }

    public void setTimeTypeId(String timeTypeId) {
        TimeTypeId = timeTypeId;
    }

    public String getTime() {
        return Time;
    }

    public void setTime(String time) {
        Time = time;
    }
}
