package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/28 15:46.
 */

public class AnalyzeItmeBean2 extends BaseBean {

        /**
         * Id : a89b255c-3d80-4f6c-bc95-e0fce73eadeb
         * StationId : 5158dc6a-7f52-4425-89eb-df4d774b2c16
         * TimePoint : 2017年12月19日
         * ModifyTime : /Date(1513679786610)/
         * ModifyPerson : 4a786d06-0382-4c1a-85a0-165747283a66
         * StationName : 朝阳区
         * Type : 日报
         */

        private String Id;
        private String StationId;
        private String TimePoint;
        private String ModifyTime;
        private String ModifyPerson;
        private String StationName;
        private String Type;

        public String getId() {
            return Id;
        }

        public void setId(String Id) {
            this.Id = Id;
        }

        public String getStationId() {
            return StationId;
        }

        public void setStationId(String StationId) {
            this.StationId = StationId;
        }

        public String getTimePoint() {
            return TimePoint;
        }

        public void setTimePoint(String TimePoint) {
            this.TimePoint = TimePoint;
        }

        public String getModifyTime() {
            return ModifyTime;
        }

        public void setModifyTime(String ModifyTime) {
            this.ModifyTime = ModifyTime;
        }

        public String getModifyPerson() {
            return ModifyPerson;
        }

        public void setModifyPerson(String ModifyPerson) {
            this.ModifyPerson = ModifyPerson;
        }

        public String getStationName() {
            return StationName;
        }

        public void setStationName(String StationName) {
            this.StationName = StationName;
        }

        public String getType() {
            return Type;
        }

        public void setType(String Type) {
            this.Type = Type;
        }

}
