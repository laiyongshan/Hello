package suncere.shouchuang.androidapp.entity;

import java.util.List;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/14 10:27.
 */

public class ListCityBean extends BaseBean {

    private List<ListBean> DataList;

    public List<ListBean> getDataList() {
        return DataList;
    }

    public void setDataList(List<ListBean> dataList) {
        DataList = dataList;
    }



}
