package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/14 10:29.
 */

public class HomeListCityBean  extends BaseBean {

        /**
         * HourRank : 15
         * DayRank : 15
         * MonthRank : 15
         * YearRank : 15
         */

        private String HourRank;
        private String DayRank;
        private String MonthRank;
        private String YearRank;
        private String YesterdayRank;

    public String getYesterdayRank() {
        return YesterdayRank;
    }

    public void setYesterdayRank(String yesterdayRank) {
        YesterdayRank = yesterdayRank;
    }

    public String getHourRank() {
        return HourRank;
    }

    public void setHourRank(String hourRank) {
        HourRank = hourRank;
    }

    public String getDayRank() {
        return DayRank;
    }

    public void setDayRank(String dayRank) {
        DayRank = dayRank;
    }

    public String getMonthRank() {
        return MonthRank;
    }

    public void setMonthRank(String monthRank) {
        MonthRank = monthRank;
    }

    public String getYearRank() {
        return YearRank;
    }

    public void setYearRank(String yearRank) {
        YearRank = yearRank;
    }
}
