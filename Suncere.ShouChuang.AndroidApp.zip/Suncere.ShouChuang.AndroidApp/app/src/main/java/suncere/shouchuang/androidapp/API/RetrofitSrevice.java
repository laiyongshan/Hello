package suncere.shouchuang.androidapp.API;


import java.util.List;

import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;
import rx.Observable;
import suncere.shouchuang.androidapp.entity.AllCityBean;
import suncere.shouchuang.androidapp.entity.AnalyzeItmeBean2;
import suncere.shouchuang.androidapp.entity.BaseModelBean;
import suncere.shouchuang.androidapp.entity.CompareStationBean;
import suncere.shouchuang.androidapp.entity.HomeAQIListBean;
import suncere.shouchuang.androidapp.entity.HomeChartBean;
import suncere.shouchuang.androidapp.entity.HomeCityBean;
import suncere.shouchuang.androidapp.entity.HomeListCityBean;
import suncere.shouchuang.androidapp.entity.ListBean;
import suncere.shouchuang.androidapp.entity.ListCityBean;
import suncere.shouchuang.androidapp.entity.LoginBean;
import suncere.shouchuang.androidapp.entity.MapBean;
import suncere.shouchuang.androidapp.entity.MapChartBean;
import suncere.shouchuang.androidapp.entity.WarnDataBean;

/**
 * Created by Hjo on 2017/6/23.
 */
public interface RetrofitSrevice {

    // APP更新
    //    api/Update/GetAndroidAPKUpdate?version={version}
    @GET("VersionUpdate")
    Observable<String> updataAPP(@Query("VersionCode") String version);

    // http://10.10.10.221:82/AQiMonitor/AppLogOn?userName=liuhf&password=111
    //登录
    @FormUrlEncoded
    @POST("AppLogOn")
    Observable <BaseModelBean<LoginBean>>login(@Field("userName")String userName , @Field("password")String password);

    // 获取城市
    //    http://10.10.10.221:82/AQIMonitor/GetLevelStation
    @GET("GetAllCity")
    Observable<BaseModelBean<List<AllCityBean>>> allcity();

    // 获取北京市下的站点
    //   http://10.10.10.221:82/AQIMonitor/GetLevelStation?StationId=42c5e010-05a6-4bee-b35a-ac6a4b6a4caf&Level=3
//    http://117.121.97.122:8066/AQIMonitor/GetLevelStation?StationId=42c5e010-05a6-4bee-b35a-ac6a4b6a4caf&Level=3
    @GET("GetLevelStation")
    Observable<BaseModelBean<List<AllCityBean>>> allStation(@Query("StationId")String StationId,@Query("Level")String Level);

    //  首页上方城市
    //    http://10.10.10.221:82/AQIMonitor/GetCityPollutant?StationId=110000
    @GET("GetCityPollutant")
    Observable<BaseModelBean<List<HomeCityBean>>> homecity(@Query("StationId") String CityCode);

    //  首页城市排名
//    http://10.10.10.221:82/AQIMonitor/GetAQIRank?StationId=42c5e010-05a6-4bee-b35a-ac6a4b6a4caf
//
    @GET("GetAQIRank")
    Observable<BaseModelBean<HomeListCityBean>> homelistcity(@Query("StationId") String CityCode);

    //  首页图表
    //    http://10.10.10.221:82/AQIMonitor/GetAfter24ChartData?StationId=110000&PollutantCode=AQI
    @GET("GetAfter24ChartData")
    Observable<BaseModelBean<List<HomeChartBean>>> homeChart(@Query("StationId") String CityCode, @Query("PollutantCode") String PollutantCode);

    //  首页 AQI 综合指数
    //  http://10.10.10.221:82/AQIMonitor/GetGridStationAQI?StationId=110000&ReportTimeType=3
    @GET("GetGridStationAQI")
    Observable<BaseModelBean<List<HomeAQIListBean>>> homeAQIListBean(@Query("StationId") String CityCode, @Query("ReportTimeType") String ReportTimeType,@Query("PollutantCode")String PollutantCode);


    // 首页二级页面 城市排名
    //    http://10.10.10.221:82/AQIMonitor/GetAQIRank?StationId=42c5e010-05a6-4bee-b35a-ac6a4b6a4caf&ReportTimeType=3&PollutantCode=AQI
//    http://117.121.97.122:8066/AQIMonitor/GetAQIRank?ReportTimeType=9&PollutantCode=PM10&StationId=42c5e010-05a6-4bee-b35a-ac6a4b6a4caf
    @GET("GetAQIRank")
    Observable<BaseModelBean<ListCityBean>> listCity(@Query("StationId") String CityCode, @Query("ReportTimeType") String ReportTimeType,@Query("PollutantCode")String PollutantCode);

    //   首页二级页面城市区站点实时数据与当前累计空气质量
    //    http://localhost:82/AQIMonitor/GetAreaStationTotalAQI?StationId=42c5e010-05a6-4bee-b35a-ac6a4b6a4caf&ReportTimeType=4&PollutantCode=PM10
    @GET("GetAreaStationTotalAQI")
    Observable<BaseModelBean<List<ListBean>>> listStation(@Query("StationId") String CityCode, @Query("ReportTimeType") String ReportTimeType, @Query("PollutantCode")String PollutantCode);


    //首页二级页面  朝阳、顺义、石景山
    //    http://10.10.10.221:82/AQIMonitor/GetAreaCompare?StationId=5158dc6a-7f52-4425-89eb-df4d774b2c16&PollutantCode=PM10
    @GET("GetAreaCompare")
    Observable<BaseModelBean<List<CompareStationBean>>> compareData(@Query("StationId") String CityCode, @Query("PollutantCode") String PollutantCode,@Query("ReportTimeType") String ReportTimeType);


    // 地图页面
    //  http://10.10.10.221:82/AQIMonitor/GetMap?PollutantCode=PM10
    @GET("GetMap")
    Observable<BaseModelBean<List<MapBean>>> mapdata(@Query("PollutantCode") String PollutantCode);

    // 地图 图表
//    http://10.10.10.221:82/AQIMonitor/GetMapProbabilityDistribution?sdtDate=2017-11-08&edtDate=2017-11-09&StationId=7e30555b-b38e-4f29-a186-8205ff59d140&PollutantCode=PM10
    @GET("GetMapProbabilityDistribution")
    Observable<BaseModelBean<MapChartBean>> mapChartdata(@Query("StationId")String StationCode, @Query("PollutantCode")String pollutantName,
                                                         @Query("sdtDate")String startTime, @Query("edtDate")String endTime);

//    http://10.10.10.221:82/AQIMonitor/GetAnalyiseReportList?StationId=5158dc6a-7f52-4425-89eb-df4d774b2c16&edtDate=2017/12/19&sdtDate=2017/12/19&ReportTimeType=4
    @GET("GetAnalyiseReportList")
    Observable<BaseModelBean<List<AnalyzeItmeBean2>>> analyzeData(@Query("StationId")String StationCode, @Query("ReportTimeType")String ReportTimeType,
                                                                  @Query("sdtDate")String startTime, @Query("edtDate")String endTime);

    // 报警
    //  http://202.104.69.202:9048/AQIMonitor/GetAlarmInfo?AlarmStatus=0
    @GET("GetAlarmInfo")
    Observable<BaseModelBean<List<WarnDataBean>>> warnData(@Query("AlarmStatus") String AlarmStatus);
}



