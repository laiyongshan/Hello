package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/16 16:20.
 */

public class CompareStationBean extends BaseBean {

        /**
         * StationId : 3762c60a-b4e1-4930-8ecd-f9b84a17fa51
         * Rank : 1
         * Station : 奥体中心
         * Value : 131
         * Value_Level : 0
         * Compare : —
         */
        private String StationId;
        private String Rank;
        private String Station;
        private String Value;
        private String Value_Level;
        private String Compare;

    public String getRank() {
        return Rank;
    }

    public void setRank(String rank) {
        Rank = rank;
    }

    public String getValue_Level() {
        return Value_Level;
    }

    public void setValue_Level(String value_Level) {
        Value_Level = value_Level;
    }

    public String getStationId() {
            return StationId;
        }

        public void setStationId(String StationId) {
            this.StationId = StationId;
        }



        public String getStation() {
            return Station;
        }

        public void setStation(String Station) {
            this.Station = Station;
        }

        public String getValue() {
            return Value;
        }

        public void setValue(String Value) {
            this.Value = Value;
        }



        public String getCompare() {
            return Compare;
        }

        public void setCompare(String Compare) {
            this.Compare = Compare;

        }



}
