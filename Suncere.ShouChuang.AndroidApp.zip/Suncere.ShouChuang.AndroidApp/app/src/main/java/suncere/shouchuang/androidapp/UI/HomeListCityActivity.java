package suncere.shouchuang.androidapp.UI;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.adapter.RecyclerViewAdapter;
import suncere.androidapp.lib.adapter.ViewHolder;
import suncere.androidapp.lib.customview.PollutantNameTextView;
import suncere.androidapp.lib.mvp.ui.baseui.MvpActivity;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.ColorUtils;
import suncere.shouchuang.androidapp.BR;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.ListSort;
import suncere.shouchuang.androidapp.Utils.ToolUtils;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.entity.ListBean;
import suncere.shouchuang.androidapp.entity.ListCityBean;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;

/**
 * Created by Hjo on 2017/11/14 20:33.
 */

public class HomeListCityActivity extends MvpActivity<BasePresenterChild> implements IBaseView ,
        SwipeRefreshLayout.OnRefreshListener,RecyclerViewAdapter.RecyclerViewOnBindItmeView{

    @BindView(R.id.home_listCity_SwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    @BindView(R.id.home_listCity_recyclerview)
    RecyclerView mRecyclerView;

    @BindView(R.id.home_citylist_select_pollutant)
    PollutantNameTextView mpollutantItme;

    @BindView(R.id.home_listcity_UpOrDown_image)
    ImageView mUpOrDown_image;

    @BindView(R.id.home_citylist_title)
    TextView mcitylist_title;

    @BindView(R.id.home_listCity_time)
    TextView mlistCity_time;

    @BindView(R.id.null_data)
    LinearLayout null_data;

    @BindView(R.id.home_citylist_pollutant)
    PollutantNameTextView home_citylist_pollutant;

    RecyclerViewAdapter<ListBean>mAdapter;
    BasePresenterChild mBasePresenterChild;
    CustomPopWindow mCustomPopWindow;
    String mPollutantName="AQI";
    String mCityCode;
    String CityName;
    String mReportTimeType;

    List<ListBean>mlistCityData;
    boolean isUpOrDown=true;// true 为正序

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.home_citylist_activity);
        ButterKnife.bind(this);
        initView();
    }

    @Override
    protected void onStart() {
        super.onStart();
        getData();
    }

    @Override
    protected BasePresenterChild createPresenter() {
        mBasePresenterChild=new BasePresenterChild(this);
        return mBasePresenterChild;
    }

    private void initView(){
        mAdapter=new RecyclerViewAdapter<>(this,R.layout.home_citylist_recyclerview_itme, BR.listCityData);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter);
        mSwipeRefreshLayout.setColorSchemeColors(ColorUtils.Colors);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        Intent intent=getIntent();
        mCityCode=intent.getStringExtra("CityCode");
        mReportTimeType=intent.getStringExtra("ReportTimeType");
        CityName=intent.getStringExtra("CityName");
//        mcitylist_title.setText();
        mlistCityData=new ArrayList<>();
    }

    private void getData(){
        if ("PM2.5".equals(mPollutantName))mPollutantName="PM2_5";
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().listCity(mCityCode,mReportTimeType,mPollutantName), mCityCode+mReportTimeType+mPollutantName);
    }

    @Override
    public void getDataSuccess(Object response) {

        mlistCityData.clear();
        if (response!=null){
            mlistCityData.addAll( ((ListCityBean) response).getDataList());
            mlistCity_time.setText(ToolUtils.getLastTimeHour()+"更新");
        }
        findCity2Frist();
    }

    private void findCity2Frist(){
        Collections.sort(mlistCityData,new ListSort(isUpOrDown));
        for(ListBean bean:mlistCityData){
            if (bean.getStatioinCode().equals(CityName)){
                mlistCityData.remove(bean);
                mlistCityData.add(0,bean);
                break;
            }
        }
        if (mlistCityData.size()==0){
            null_data.setVisibility(View.VISIBLE);
        }else {
            null_data.setVisibility(View.GONE);
        }
        mAdapter.setData(mlistCityData);
    }

    @OnClick({R.id.home_citylist_select_pollutant,R.id.home_citylist_top_back,R.id.home_listcity_UpOrDown})
    public void  on_click(View view ){
        switch (view.getId()){
            case R.id.home_citylist_select_pollutant:
                showPopMenu();
                break;
            case R.id.home_citylist_top_back:
                finish();
                break;
            case R.id.home_listcity_UpOrDown:
                isUpOrDown=!isUpOrDown;
                if (isUpOrDown){
                    mUpOrDown_image.setImageResource(R.mipmap.list_up);
                }else{
                    mUpOrDown_image.setImageResource(R.mipmap.list_down);
                }
                findCity2Frist();
                break;
        }
    }

    private void showPopMenu(){
        View contentView = LayoutInflater.from(this).inflate(R.layout.map_chart_pollutant_itme,null);
        if ("3".equals(mReportTimeType)){
            ((PollutantNameTextView)  contentView.findViewById(R.id.O3)).setText("O3");
        }
        handleLogic(contentView);
        mCustomPopWindow= new CustomPopWindow.PopupWindowBuilder(this)
                .setView(contentView)
                .create();
        mCustomPopWindow .showAsDropDown(mpollutantItme,6,-(mpollutantItme.getHeight()+mCustomPopWindow.getHeight()));
    }

    /**
     * 处理弹出显示内容、点击事件等逻辑
     * @param contentView
     */
    private void handleLogic(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCustomPopWindow!=null){
                    mCustomPopWindow.dissmiss();
                }
                mPollutantName=((TextView)v).getText().toString();
                mpollutantItme.setText(mPollutantName);
                home_citylist_pollutant.setText(mPollutantName);
                getData();
            }
        };
        contentView.findViewById(R.id.AQI).setOnClickListener(listener);
        contentView.findViewById(R.id.SO2).setOnClickListener(listener);
        contentView.findViewById(R.id.NO2).setOnClickListener(listener);
        contentView.findViewById(R.id.CO).setOnClickListener(listener);
        contentView.findViewById(R.id.O3).setOnClickListener(listener);
        contentView.findViewById(R.id.PM2_5).setOnClickListener(listener);
        contentView.findViewById(R.id.PM10).setOnClickListener(listener);
    }

    @Override
    public void onRefresh() {
        getData();
    }
    @Override
    public void showRefresh() {
        mSwipeRefreshLayout.setRefreshing(true);
    }

    @Override
    public void finishRefresh() {
        mSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void getDataFail(String msg) {

    }

    @Override
    public void OnBindItmeView(final View view, Object obejct, int position, int selectPosition, int tag) {
        if (position==0){
            view.setBackgroundColor(Color.parseColor("#D0E8F4"));
        }
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ViewHolder.getView(view,R.id.home_citylist_Itme__pollutantName).setFocusable(true);
            }
        });

    }

}
