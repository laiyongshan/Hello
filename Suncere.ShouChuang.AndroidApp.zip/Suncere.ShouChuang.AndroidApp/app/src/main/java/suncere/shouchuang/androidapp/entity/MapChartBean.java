package suncere.shouchuang.androidapp.entity;

import java.util.List;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/17 14:20.
 */

public class MapChartBean extends BaseBean {

        private List<PrimaryPollutantBean> PrimaryPollutant;
        private List<LevelBean> Level;

        public List<PrimaryPollutantBean> getPrimaryPollutant() {
            return PrimaryPollutant;
        }

        public void setPrimaryPollutant(List<PrimaryPollutantBean> PrimaryPollutant) {
            this.PrimaryPollutant = PrimaryPollutant;
        }

        public List<LevelBean> getLevel() {
            return Level;
        }

        public void setLevel(List<LevelBean> Level) {
            this.Level = Level;
        }

        public static class PrimaryPollutantBean extends BaseBean{
            /**
             * Name : NO2
             * Value : 4
             */
            private String Name;
            private double Value;

            public String getName() {
                return Name;
            }

            public void setName(String Name) {
                this.Name = Name;
            }

            public double getValue() {
                return Value;
            }

            public void setValue(double Value) {
                this.Value = Value;
            }
        }

        public static class LevelBean extends BaseBean{
            /**
             * Name : 良
             * Value : 60
             */
            private String Name;
            private double Value;

            public String getName() {
                return Name;
            }

            public void setName(String Name) {
                this.Name = Name;
            }

            public double getValue() {
                return Value;
            }

            public void setValue(double Value) {
                this.Value = Value;
            }
        }

}
