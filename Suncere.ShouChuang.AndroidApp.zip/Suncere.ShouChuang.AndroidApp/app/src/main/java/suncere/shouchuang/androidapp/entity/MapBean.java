package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/17 14:17.
 */

public class MapBean extends BaseBean {
        /**
         * PositionName : 运城中学
         * Latitude : 35.0147
         * Longitude : 110.9956
         * Type : 4
         * Quantity : 重度污染
         * StationId : 4ab518d8-1793-476d-b3c1-0c0701f8d846
         * PrimaryPollutant : PM2_5
         * Level : 2
         * Value : 239
         */
        private String PositionName;
        private String Latitude;
        private String Longitude;
        private String Type;
        private String Quantity;
        private String StationId;
        private String PrimaryPollutant;
        private String Level;
        private String Value;

    public String getPositionName() {
        return PositionName;
    }

    public void setPositionName(String positionName) {
        PositionName = positionName;
    }

    public String getLatitude() {
        return Latitude;
    }

    public void setLatitude(String latitude) {
        Latitude = latitude;
    }

    public String getLongitude() {
        return Longitude;
    }

    public void setLongitude(String longitude) {
        Longitude = longitude;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        Quantity = quantity;
    }

    public String getStationId() {
        return StationId;
    }

    public void setStationId(String stationId) {
        StationId = stationId;
    }

    public String getPrimaryPollutant() {
        return PrimaryPollutant;
    }

    public void setPrimaryPollutant(String primaryPollutant) {
        PrimaryPollutant = primaryPollutant;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String level) {
        Level = level;
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }
}
