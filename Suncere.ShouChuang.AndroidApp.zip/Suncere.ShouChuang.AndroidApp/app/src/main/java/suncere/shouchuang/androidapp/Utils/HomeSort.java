package suncere.shouchuang.androidapp.Utils;

import java.util.Comparator;

import suncere.shouchuang.androidapp.entity.HomeAQIListBean;

/**
 * Created by Hjo on 2017/6/6.
 */

public class HomeSort implements Comparator<HomeAQIListBean> {

    private boolean misSequence;//正序为true 倒序为false
    public HomeSort(boolean isSequence){
        this.misSequence=isSequence;
    }

    @Override
    public int compare(HomeAQIListBean object1, HomeAQIListBean object2) {
        HomeAQIListBean  before=misSequence? object1:object2;
        HomeAQIListBean  after=misSequence? object2:object1;
//        int flag=(Integer.valueOf(before.getRank())).compareTo(Integer.valueOf(after.getRank()));
        Integer beforeRank=0;
        Integer afterRank=0;
        try{
            beforeRank=Integer.valueOf(before.getRank());
        }catch ( Exception  e  ){
            beforeRank=9999;
        }
        try{
            afterRank=Integer.valueOf(after.getRank());
        }catch ( Exception  e  ){
            afterRank=9999;
        }
//        int flag=(Integer.valueOf(before.getRank())).compareTo(Integer.valueOf(after.getRank()));
        int flag=beforeRank.compareTo( afterRank);
        if(flag==0)
            return before.getStation().toString().compareTo(after.getStation().toString());

        return flag;
    }
}
