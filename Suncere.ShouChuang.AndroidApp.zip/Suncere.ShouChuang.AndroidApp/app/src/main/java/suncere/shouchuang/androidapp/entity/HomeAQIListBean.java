package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/14 11:40.
 */

public class HomeAQIListBean extends BaseBean {

        /**
         * Rank : 1
         * Station : 东四
         * Value : 31
         * Value_Level : 1
         * Level : 优
         * Compare : —
         */
        private String Rank;
        private String Station;
        private String Value;
        private String Value_Level;
        private String Level;
        private String Compare;

    public String getRank() {
        return Rank;
    }

    public void setRank(String rank) {
        Rank = rank;
    }

    public String getValue_Level() {
        return Value_Level;
    }

    public void setValue_Level(String value_Level) {
        Value_Level = value_Level;
    }

    public String getStation() {
            return Station;
        }

        public void setStation(String Station) {
            this.Station = Station;
        }

        public String getValue() {
            return Value;
        }

        public void setValue(String Value) {
            this.Value = Value;
        }


        public String getLevel() {
            return Level;
        }

        public void setLevel(String Level) {
            this.Level = Level;
        }

        public String getCompare() {
            return Compare;
        }

        public void setCompare(String Compare) {
            this.Compare = Compare;
        }
    }

