package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/15 14:41.
 */

public class AllCityBean extends BaseBean{

        /**
         * Id : 007a1707-7e0e-4b40-8305-29c2a4d56b9d
         * Name : 周口市
         * ParentId : 3502a109-ec41-43aa-bcbb-3752750b1c94
         * Level : 2
         */
        private String Id;
        private String Name;
        private String ParentId;
        private int Level;


        public String getId() {
            return Id;
        }

        public void setId(String Id) {
            this.Id = Id;
        }

        public String getName() {
            return Name;
        }

        public void setName(String Name) {
            this.Name = Name;
        }

        public String getParentId() {
            return ParentId;
        }

        public void setParentId(String ParentId) {
            this.ParentId = ParentId;
        }

        public int getLevel() {
            return Level;
        }

        public void setLevel(int Level) {
            this.Level = Level;
        }

}
