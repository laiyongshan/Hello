package suncere.shouchuang.androidapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.mvp.ui.baseui.MvpActivity;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.StatusBarUtil;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.LeakCanaryUtil;
import suncere.shouchuang.androidapp.Utils.ToolUtils;
import suncere.shouchuang.androidapp.entity.LoginBean;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;


/**
 * Created by Hjo on 2017/6/23.
 */

public class LoginActivity extends MvpActivity<BasePresenterChild> implements IBaseView {

    @BindView(R.id.login_user)
    EditText login_user;

    @BindView(R.id.login_psw)
    EditText login_psw;

    @BindView(R.id.login_eye)
    ImageView login_eye;

    @BindView(R.id.login_go)
    Button login_go;

    BasePresenterChild mLoginPresenter;
    private String mUserName;
    private String mPsw;
    ToolUtils mToolUtils;
    boolean isSetPasswork2See=false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_act);
        ButterKnife.bind(this);
        StatusBarUtil.setTranslucent(this,30);
        inits();
    }

    private void inits(){
        mToolUtils=new ToolUtils();
        mUserName=mToolUtils.getNameAndPss()[0];
        mPsw=mToolUtils.getNameAndPss()[1];
        if (mUserName!=null) login_user.setText(mUserName);
        if (mPsw!=null) login_psw.setText(mPsw);

        boolean isLogin=getIntent().getBooleanExtra("isLogin",true);
        if (isLogin && mUserName!=null && mPsw!=null) loginAPP();
    }

    @Override
    protected BasePresenterChild createPresenter() {
        mLoginPresenter=new BasePresenterChild(this);
        return mLoginPresenter;
    }

    @Override
    public void getDataSuccess(Object response) {
        if (response!=null){
            LoginBean loginBean= (LoginBean) response;
            if (loginBean!=null) {
                if (loginBean.isSuccess()) { //登录成功
                    mToolUtils.setNameAndPss(mUserName,mPsw);
                    mToolUtils.setLoginTime();
                    Intent intent = new Intent(this, MainActivity.class);
                    startActivity(intent);
                }
            }
            if (!loginBean.isSuccess())
            Toast.makeText(this,loginBean.getError(),Toast.LENGTH_LONG).show();
        }
    }

    @OnClick({R.id.login_go,R.id.login_eye})
    public void on_Click(View view){
        switch (view.getId()){
            case R.id.login_go:
                mUserName=login_user.getText().toString().trim();
                mPsw=login_psw.getText().toString().trim();
                loginAPP();
                break;
            case  R.id.login_eye:
                if (isSetPasswork2See){
                    login_eye.setImageResource(R.mipmap.login_eye);
                    login_psw.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                } else {
                    login_eye.setImageResource(R.mipmap.login_eye_w);
                    login_psw.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
                isSetPasswork2See=!isSetPasswork2See;
                break;
        }
    }

    public void loginAPP(){
        mLoginPresenter.getCatchOrNetData(mLoginPresenter.getRetrofitSrevice().login(mUserName,mPsw)," ");
    }

    @Override
    public void showRefresh() {
        login_go.setFocusable(false);
        login_go.setBackgroundResource(R.drawable.bg_login_button_n);
    }

    @Override
    public void getDataFail(String msg) {
        Toast.makeText(this,msg,Toast.LENGTH_LONG).show();
    }

    @Override
    public void finishRefresh() {
        login_go.setFocusable(true);
        login_go.setBackgroundResource(R.drawable.bg_login_button);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (null != this.getCurrentFocus()) {
            /**
             * 点击空白位置 隐藏软键盘
             */
            InputMethodManager mInputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            return mInputMethodManager.hideSoftInputFromWindow(this.getCurrentFocus().getWindowToken(), 0);
        }
        return super.onTouchEvent(event);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exitAPP();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LeakCanaryUtil.fixMemoryLeak(this);
    }
}
