package suncere.shouchuang.androidapp.UI;


import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.prolificinteractive.materialcalendarview.CalendarDay;
import com.prolificinteractive.materialcalendarview.CalendarMode;
import com.prolificinteractive.materialcalendarview.MaterialCalendarView;
import com.prolificinteractive.materialcalendarview.OnDateSelectedListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;
import suncere.androidapp.lib.customview.TipView;
import suncere.androidapp.lib.mvp.ui.baseui.MvpFragment;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.ColorUtils;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.ColorTools;
import suncere.shouchuang.androidapp.Utils.MyLocation;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.customview.LoginProgressDialog;
import suncere.shouchuang.androidapp.entity.MapBean;
import suncere.shouchuang.androidapp.entity.MapChartBean;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;

/**
 * Created by Hjo on 2017/10/13.
 */


@RuntimePermissions
public class MapFragment extends MvpFragment<BasePresenterChild> implements IBaseView,SwipeRefreshLayout.OnRefreshListener{

    BasePresenterChild mBasePresenterChild;
    List<MapBean> mLiveDataBeans;
    TipView mTipView;

    @BindView(R.id.map_chart_layout_rela)
    RelativeLayout map_chart_layout_rela;

    @BindView(R.id.map_chart_text_time_start)
    TextView time_start;

    @BindView(R.id.map_chart_text_pollutant)
    TextView map_chart_text_pollutant;

    @BindView(R.id.map_chart_title_Station)
    TextView map_chart_title_Station;

    @BindView(R.id.map_chart_pollutant_selectItme)
    LinearLayout map_chart_pollutant_selectItme;

    @BindView(R.id.map_chart_text_time_end)
    TextView time_end;

    @BindView(R.id.map_piechart_1)
    PieChart mPiechart1;

    @BindView(R.id.map_piechart_2)
    PieChart mPiechart2;

    @BindView(R.id.map_webView)
    WebView map_webView;

    @BindView(R.id.map_chart_SwipeRefreshLayout)
    SwipeRefreshLayout map_chart_SwipeRefreshLayout;

    CustomPopWindow mCustomPopWindow;
    MaterialCalendarView materialCalendarView;
    CalendarDay mstartSelectCalendar;
    CalendarDay mendSelectCalendar;
    int TagSelectStartOrEndTime=0;  // 0是选择开始日期  1是结束日期

    String mChartPollutantName="AQI";
    String mStationId;
    String mStationName;
    String mstartTime;
    String mendTime;
    MapChartBean mMapChartBean;

    Handler mHandler;
    MyLocation mMyLocation;
//    MyWebView mMyWebView;
    LoginProgressDialog mProgressDialog;


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.map_fragment2,container,false);
        ButterKnife.bind(this,view);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        init();
    }

    @Override
    protected BasePresenterChild createPresenter() {
        mBasePresenterChild=new BasePresenterChild(this);
        return mBasePresenterChild;
    }




    @SuppressLint("JavascriptInterface")
    private void  init(){

        mProgressDialog=new LoginProgressDialog(getActivity());
        mProgressDialog.show();

        mHandler=new Handler(Looper.getMainLooper());
//        WebSettings webSettings = map_webView.getSettings();
//        String ua = webSettings.getUserAgentString();
//        webSettings.setUserAgentString(ua.replace("Android", "AndroidApp"));
//        webSettings.setJavaScriptEnabled(true);
//        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
//        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

//        WebSettings webSetting = map_webView.getSettings();
//        webSetting.setJavaScriptCanOpenWindowsAutomatically(true);
//        webSetting.setAllowFileAccess(true);
//        webSetting.setSupportZoom(true);
//        webSetting.setBuiltInZoomControls(true);
//        webSetting.setUseWideViewPort(true);
//        webSetting.setSupportMultipleWindows(true);
//        webSetting.setAppCacheEnabled(true);
//        webSetting.setDomStorageEnabled(true);
//        webSetting.setGeolocationEnabled(true);
//        webSetting.setAppCacheMaxSize(Long.MAX_VALUE);
//        webSetting.setPluginState(WebSettings.PluginState.ON_DEMAND);
//        webSetting.setCacheMode(WebSettings.LOAD_NO_CACHE);

       String url= mBasePresenterChild.BaseUrl();
        url=url.replace("AQIMonitor","Mock")+"MobileMap";
//        mMyWebView=new MyWebView(map_webView,url);


//        map_webView.clearCache(true);
//        map_webView.clearHistory();
        WebSettings webSettings = map_webView.getSettings();
        String ua = webSettings.getUserAgentString();
        webSettings.setUserAgentString(ua.replace("Android", "AndroidApp"));
        webSettings.setJavaScriptEnabled(true);
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        map_webView.loadUrl(url);
        Log.e("map","mapurl:"+map_webView.getUrl());
        map_webView.setWebViewClient(new MyWebViewClient());
        map_webView.addJavascriptInterface(this, "android");
        map_webView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                 if (100==newProgress)  {
                     if (mProgressDialog.isShowing()) mProgressDialog.dismiss();
                 }
            }
        });

        map_chart_SwipeRefreshLayout.setColorSchemeColors(ColorUtils.Colors);
        map_chart_SwipeRefreshLayout.setOnRefreshListener(this);
        map_chart_SwipeRefreshLayout.setEnabled(false);

        mLiveDataBeans=new ArrayList<>();
        mTipView=new TipView(getActivity(),R.layout.map_chart_data_layout);

        mstartSelectCalendar= CalendarDay.today();
        mendSelectCalendar= CalendarDay.today();
        mstartTime=CalendarDay2String(mstartSelectCalendar);
        time_start.setText(mstartTime);
        mendTime=CalendarDay2String(mendSelectCalendar);
        time_end.setText(mendTime);

        map_chart_text_pollutant.setText(mChartPollutantName);
        materialCalendarView= (MaterialCalendarView) mTipView.findViewById(R.id.map_chart_DataView);
        materialCalendarView.setSelectionColor(Color.parseColor("#27A68C"));//设置选中的日期背景色
        materialCalendarView.setArrowColor(Color.parseColor("#27A68C"));//设置头部左和右箭头的颜色
        materialCalendarView.setOnDateChangedListener(new OnDateSelectedListener() {

            public void onDateSelected(@NonNull MaterialCalendarView widget, @NonNull CalendarDay date, boolean selected) {
//                Toast.makeText(getActivity(),"日期："+date.getYear()+"年"+(date.getMonth()+1)+"月"+date.getDay(),Toast.LENGTH_LONG).show();
                if (TagSelectStartOrEndTime==0){
                    mstartSelectCalendar=date;
                    time_start.setText(CalendarDay2String(mstartSelectCalendar));
                }else{
                    mendSelectCalendar=date;
                    time_end.setText(CalendarDay2String(mendSelectCalendar));
                }
                mTipView.dismiss();
            }
        });

        creatChart(mPiechart1);
        creatChart(mPiechart2);
        mMyLocation=new MyLocation(getActivity());
//        mMyLocation.startLocation();
        MapFragmentPermissionsDispatcher.NeedLocationPermissionWithPermissionCheck(this);
    }

    private static class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
        }
    }

    private void  creatChart(PieChart chart){

        chart.setUsePercentValues(true);
        chart.getDescription().setEnabled(false);
        chart.setExtraOffsets(15, 0, 15, 10);
        chart.setDragDecelerationFrictionCoef(0.95f);
        chart.setHoleColor(Color.WHITE);
        chart.setTransparentCircleColor(Color.WHITE);
        chart.setTransparentCircleAlpha(110);

        chart.setDrawHoleEnabled(true);
        chart.setHoleRadius(20f); //设置PieChart内部圆的半径
        chart.setTransparentCircleRadius(30f);
        chart.setCenterTextRadiusPercent(30f);

        chart.setRotationAngle(0);
        chart.setRotationEnabled(true);
        chart.setHighlightPerTapEnabled(true);
        chart.highlightValues(null);// 不显示文字
        chart.setDrawEntryLabels(false);  //  设置是否绘制标签
        chart.setEntryLabelTextSize(11f);
        chart.setDrawSlicesUnderHole(false);
        chart.setDrawHoleEnabled(false);
    }

    public void getChartData(){
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().mapChartdata(mStationId,mChartPollutantName,mstartTime,mendTime),
                mStationId+mChartPollutantName+mstartTime+mendTime);
    }

    @JavascriptInterface
    public void visibilityChartView(String stationName,String stationid,String chartPollutantName){
        mStationId=stationid;
        mChartPollutantName=chartPollutantName;
        mStationName=stationName;
//        Log.e("map","mStationId="+stationid+"   mChartPollutantName="+chartPollutantName);
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                //已在主线程中，可以更新UI
                map_chart_title_Station.setText(mStationName+"污染概率分布统计");
                map_chart_text_pollutant.setText(mChartPollutantName);
                map_chart_layout_rela.setVisibility(View.VISIBLE);
                getChartData();
            }
        });
    }

    @Override
    public void getDataSuccess(Object response) {
        if (null!=response){
            mMapChartBean= (MapChartBean) response;
            bindChartData();
        }
    }

    private void bindChartData(){
        setChartDara(mPiechart1,1);
        setChartDara(mPiechart2,2);
    }

    private void setChartDara(PieChart chart,int tag){
        ArrayList<PieEntry> entries = new ArrayList<>();
        ArrayList<Integer> colors = new ArrayList<>();
        if (tag==1 &&mMapChartBean.getLevel()!=null && mMapChartBean.getLevel().size()>0){
            for (  MapChartBean.LevelBean bean : mMapChartBean.getLevel() ) {
                entries.add(new PieEntry((float) bean.getValue(),ColorUtils.getAbQualitysWithLevel(bean.getName()) ));//mParties[i % mParties.length]
                colors.add(ColorUtils.getColorFromQuality(bean.getName()));
            }
        }  else if (tag==2 &&mMapChartBean.getPrimaryPollutant()!=null && mMapChartBean.getPrimaryPollutant().size()>0){
            for (  MapChartBean.PrimaryPollutantBean bean :mMapChartBean.getPrimaryPollutant() ) {
                entries.add(new PieEntry((float) bean.getValue(),bean.getName()));//mParties[i % mParties.length]
                colors.add(ColorTools.getPollutantNameColor(bean.getName()));
            }
        }

        PieDataSet dataSet = new PieDataSet(entries,null);
        dataSet.setSliceSpace(3f);
        dataSet.setSelectionShift(5f);
        dataSet.setColors(colors);
//        dataSet.setValueLinePart1OffsetPercentage(80.f);
        dataSet.setValueLinePart1Length(0.2f);
        dataSet.setValueLinePart2Length(0.4f);
        dataSet.setYValuePosition(PieDataSet.ValuePosition.OUTSIDE_SLICE);


        PieData data = new PieData(dataSet);
        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.BLACK);

        chart.setData(data);
        chart.highlightValues(null);
        chart.invalidate();
        chart.animateY(1400, Easing.EasingOption.EaseInOutQuad);

        Legend l = chart.getLegend();
        l.setEnabled(true);                    //是否启用图列（true：下面属性才有意义）
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.BOTTOM);
//        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.LEFT);
        l.setOrientation(Legend.LegendOrientation.HORIZONTAL);
        l.setForm(Legend.LegendForm.CIRCLE); //设置图例的形状
        l.setFormSize(8f);                    //设置图例的大小
        l.setFormToTextSpace(5f);            //设置每个图例实体中标签和形状之间的间距
        l.setDrawInside(false);
        l.setWordWrapEnabled(true);           //设置图列换行(注意使用影响性能,仅适用legend位于图表下面)
        l.setXEntrySpace(6f);                //设置图例实体之间延X轴的间距（setOrientation = HORIZONTAL有效）
        l.setYEntrySpace(8f);                 //设置图例实体之间延Y轴的间距（setOrientation = VERTICAL 有效）
//        l.setYOffset(0f);                     //设置比例块Y轴偏移量
        l.setTextSize(7f);                   //设置图例标签文本的大小

//        l.setTextColor(Color.parseColor("#ff9933"));//设置图例标签文本的颜色
    }

    @Override
    public void showRefresh() {
        map_chart_SwipeRefreshLayout.setEnabled(true);
        map_chart_SwipeRefreshLayout.setRefreshing(true);
    }

    @Override
    public void finishRefresh() {
        map_chart_SwipeRefreshLayout.setRefreshing(false);
        map_chart_SwipeRefreshLayout.setEnabled(false);
    }

    @Override
    public void getDataFail(String msg) {
        Toast.makeText(getActivity(),msg,Toast.LENGTH_LONG).show();
    }

    @OnClick({//R.id.map_chart_layout_rela,
            R.id.map_chart_pollutant_selectItme,
            R.id.map_chart_rela_time_start,R.id.map_chart_rela_time_end,
            R.id.map_chart_submit,R.id.map_chart_layout_finish})
    public void on_click(View view){
        switch (view.getId()){
            case R.id.map_chart_pollutant_selectItme:
                // 选择污染物
                showPopMenu();
                break;
            case R.id.map_chart_rela_time_start:
                // 选择开始时间
                CalendarDay mincalendarDay=CalendarDay.today();
                creatSelectData(CalendarDay.from(mincalendarDay.getYear()-1,mincalendarDay.getMonth(),mincalendarDay.getDay()),mstartSelectCalendar);
                TagSelectStartOrEndTime=0;
                mTipView.show();
                break;
            case R.id.map_chart_rela_time_end:
                // 选择结束时间
                creatSelectData(mstartSelectCalendar,mendSelectCalendar); // 日期范围要比开始日期往前
                TagSelectStartOrEndTime=1;
                mTipView.show();
                break;
            case R.id.map_chart_submit:
                // 查询
                mChartPollutantName=map_chart_text_pollutant.getText().toString();
                mendTime=time_end.getText().toString();
                mstartTime=time_start.getText().toString();
                getChartData();
                break;
            case R.id.map_chart_layout_finish:
                // 退出该界面
                map_chart_layout_rela.setVisibility(View.GONE);
                break;
        }
    }

    private void creatSelectData(CalendarDay minCalendarDay,CalendarDay selectCalendarDay){
        materialCalendarView.state().edit()
                .setFirstDayOfWeek(Calendar.SUNDAY)
                .setMinimumDate(minCalendarDay)
                .setMaximumDate(CalendarDay.today())
                .setCalendarDisplayMode(CalendarMode.MONTHS)
                .commit();
        materialCalendarView.setSelectedDate(selectCalendarDay);
    }

    private String CalendarDay2String(CalendarDay day){
        return  day.getYear() + "-" + (day.getMonth()+1) + "-" + day.getDay() ;
    }

    private void showPopMenu(){
        View contentView = LayoutInflater.from(getActivity()).inflate(R.layout.map_chart_pollutant_itme,null);
        handleLogic(contentView);
        mCustomPopWindow= new CustomPopWindow.PopupWindowBuilder(getActivity())
                .setView(contentView)
                .create()
                .showAsDropDown(map_chart_pollutant_selectItme,0,10);
    }

    /**
     * 处理弹出显示内容、点击事件等逻辑
     * @param contentView
     */
    private void handleLogic(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCustomPopWindow!=null){
                    mCustomPopWindow.dissmiss();
                }
                mChartPollutantName=((TextView)v).getText().toString();
                map_chart_text_pollutant.setText(mChartPollutantName);
                getChartData();
            }
        };
        contentView.findViewById(R.id.AQI).setOnClickListener(listener);
        contentView.findViewById(R.id.SO2).setOnClickListener(listener);
        contentView.findViewById(R.id.NO2).setOnClickListener(listener);
        contentView.findViewById(R.id.CO).setOnClickListener(listener);
        contentView.findViewById(R.id.O3).setOnClickListener(listener);
        contentView.findViewById(R.id.PM2_5).setOnClickListener(listener);
        contentView.findViewById(R.id.PM10).setOnClickListener(listener);
    }

    @Override
    public void onRefresh() {

    }

//    private static class MyWebViewClient extends WebViewClient {
//        @Override
//        public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            view.loadUrl(url);
//            return true;
//        }
//        @Override
//        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
//            super.onReceivedError(view, errorCode, description, failingUrl);
//        }
//    }

//    @JavascriptInterface
//    public void location(){
//        MapFragmentPermissionsDispatcher.NeedLocationPermissionWithPermissionCheck(this);
//    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        MapFragmentPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
    }


    @NeedsPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
    void NeedLocationPermission() {
        mMyLocation.startLocation();
    }

    @OnShowRationale(Manifest.permission.ACCESS_COARSE_LOCATION)
    void showLocationPermission(final PermissionRequest request) {

    }

    @OnPermissionDenied(Manifest.permission.ACCESS_COARSE_LOCATION)
    void showNoLocationPermission() {
        Toast.makeText(getActivity(),"无定位权限，请开启！",Toast.LENGTH_LONG).show();
    }

    private void startAppSettings() {  // 跳转至设置页面
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        intent.setData(Uri.parse("package:" + getActivity().getPackageName()));
        startActivity(intent);
    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mMyLocation.destroyLocation();
    }
}
