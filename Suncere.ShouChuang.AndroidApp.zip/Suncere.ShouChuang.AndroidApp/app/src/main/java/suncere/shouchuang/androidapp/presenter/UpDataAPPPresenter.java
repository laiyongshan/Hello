package suncere.shouchuang.androidapp.presenter;

import okhttp3.ResponseBody;
import suncere.androidapp.lib.mvp.api.ApiNetCallBack;
import suncere.androidapp.lib.mvp.ui.MyApplication;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.NetWorkUtil;

/**
 * Created by Hjo on 2017/10/19.
 */

public class UpDataAPPPresenter extends BasePresenterChild <IBaseView> {

    public UpDataAPPPresenter(IBaseView iBaseView) {
        super(iBaseView);
    }

    public void updataAPP(String version){
        mIView.showRefresh();
        if (NetWorkUtil.isNetWorkAvailable(MyApplication.getMyApplicationContext())){
            getNetupdataAPP(version);
        }else{
            mIView.getDataFail("无网络连接！");
            mIView.getDataSuccess( null);
            mIView.finishRefresh();
        }
    }
    private void getNetupdataAPP(String version ){
        addSubscription(getRetrofitSrevice().updataAPP(version), new ApiNetCallBack<ResponseBody>() {
            @Override
            public void onSuccess(ResponseBody response) {
                mIView.getDataSuccess(response);
            }

            @Override
            public void onError(String msg) {
                mIView.getDataFail(msg);
            }
            @Override
            public void onFinish() {
                mIView.finishRefresh();
            }
        });

    }
}
