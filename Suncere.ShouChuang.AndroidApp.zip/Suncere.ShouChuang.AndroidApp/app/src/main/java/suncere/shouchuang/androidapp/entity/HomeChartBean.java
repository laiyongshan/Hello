package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/14 10:35.
 */

public class HomeChartBean  extends BaseBean {

        private String YValue;
        private String Level;
        private String TimePoint;

    public String getYValue() {
        return YValue;
    }

    public void setYValue(String YValue) {
        this.YValue = YValue;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String level) {
        Level = level;
    }

    public String getTimePoint() {
        return TimePoint;
    }

    public void setTimePoint(String timePoint) {
        TimePoint = timePoint;
    }
}
