package suncere.shouchuang.androidapp.UI;

import cn.jpush.android.api.JPushInterface;
import suncere.androidapp.lib.mvp.ui.MyApplication;

/**
 * Created by Hjo on 2018/1/16 11:47.
 */

public class ShouChuangAPP extends MyApplication{

    @Override
    public void onCreate() {
//        myApplication=this;
        super.onCreate();
        JPushInterface.setDebugMode(true);
        JPushInterface.init(this);
    }
}
