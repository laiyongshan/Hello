package suncere.shouchuang.androidapp.Utils;

import java.util.Comparator;

import suncere.shouchuang.androidapp.entity.CompareStationBean;

/**
 * Created by Hjo on 2017/6/6.
 */

public class CompareSort implements Comparator<CompareStationBean> {

    private boolean misSequence;//正序为true 倒序为false
    public CompareSort(boolean isSequence){
        this.misSequence=isSequence;
    }

    @Override
    public int compare(CompareStationBean object1,CompareStationBean object2) {
        CompareStationBean before=misSequence? object1:object2;
        CompareStationBean  after=misSequence? object2:object1;
        Integer beforeRank=0;
        Integer afterRank=0;
        try{
            beforeRank=Integer.valueOf(before.getRank());
        }catch ( Exception  e  ){
            beforeRank=9999;
        }
        try{
            afterRank=Integer.valueOf(after.getRank());
        }catch ( Exception  e  ){
            afterRank=9999;
        }
        int flag=beforeRank.compareTo( afterRank);

//        int flag=(Integer.valueOf(before.getRank())).compareTo(Integer.valueOf(after.getRank()));
        if(flag==0)
            return before.getStation().toString().compareTo(after.getStation().toString());

        return flag;
    }
}
