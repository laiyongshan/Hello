package suncere.shouchuang.androidapp.UI;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;

import com.tencent.smtt.sdk.WebChromeClient;
import com.tencent.smtt.sdk.WebSettings;
import com.tencent.smtt.sdk.WebView;
import com.tencent.smtt.sdk.WebViewClient;

import suncere.androidapp.lib.mvp.ui.baseui.MvpActivity;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.customview.LoginProgressDialog;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;

/**
 * Created by Hjo on 2017/11/27 16:51.
 */

public class AnalyzePreViewActivity extends MvpActivity<BasePresenterChild>implements IBaseView {

    WebView mWebView;
    BasePresenterChild mBasePresenterChild;
    LoginProgressDialog mProgressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.analyze_preview_activity);

    }

    @Override
    protected BasePresenterChild createPresenter() {
        mBasePresenterChild=new BasePresenterChild(this);
        return mBasePresenterChild;
    }

    @Override
    protected void onStart() {
        super.onStart();
        init();
    }

    @SuppressLint("JavascriptInterface")
    private void   init() {
        mWebView = findViewById(R.id.webView);

        mProgressDialog=new LoginProgressDialog(this);
        mProgressDialog.show();
        WebSettings webSettings = mWebView.getSettings();
        webSettings.setJavaScriptCanOpenWindowsAutomatically(true);
        webSettings.setUseWideViewPort(true);//设置webview推荐使用的窗口
        webSettings.setLoadWithOverviewMode(true);//设置webview加载的页面的模式
        webSettings.setDisplayZoomControls(false);//隐藏webview缩放按钮
        webSettings.setJavaScriptEnabled(true); //  设置支持javascript脚本
        webSettings.setAllowFileAccess(true); //    允许访问文件
        webSettings.setBuiltInZoomControls(true); //设置显示缩放按钮
        webSettings.setSupportZoom(true); // 支持缩放
        webSettings.setLoadWithOverviewMode(true);

        String id=getIntent().getStringExtra("Id");
        String url=mBasePresenterChild.BaseUrl()+"PreViewPDF?Id="+id;
        mWebView.loadUrl(url);
        Log.e("map","mapurl:"+mWebView.getUrl());
        mWebView.setWebViewClient(new MyWebViewClient());
        mWebView.addJavascriptInterface(this, "android");

        mWebView.setWebChromeClient(new WebChromeClient(){
            @Override
            public void onProgressChanged(WebView webView, int i) {
                super.onProgressChanged(webView, i);
                if (i==100) {
                    if (mProgressDialog.isShowing()) mProgressDialog.dismiss();
                }
            }
        });
    }

    private static class MyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
        }
    }

//    private static class myWebClic extends WebChromeClient{
//        @Override
//        public void onProgressChanged(android.webkit.WebView view, int newProgress) {
//            super.onProgressChanged(view, newProgress);
//            if (newProgress==100){
//                new Handler().postDelayed(new Runnable() {
//                    @Override
//                    public void run() {
//                        mProgressDialog.showDialog();
//                    }
//                },2000);
//            }
//        }
//    }

    @Override
    public void showRefresh() {

    }

    @Override
    public void getDataSuccess(Object response) {

    }

    @Override
    public void getDataFail(String msg) {

    }

    @Override
    public void finishRefresh() {

    }

//    private static class MyWebViewClient extends WebViewClient {
//        @Override
//        public boolean shouldOverrideUrlLoading(WebView view, String url) {
//            view.loadUrl(url);
//            return true;
//        }
//        @Override
//        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
//
//            super.onReceivedError(view, errorCode, description, failingUrl);
//        }
//    }

//    private static class my


}
