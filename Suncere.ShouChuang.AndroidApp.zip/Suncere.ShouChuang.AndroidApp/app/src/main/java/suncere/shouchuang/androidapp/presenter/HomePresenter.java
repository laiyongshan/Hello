package suncere.shouchuang.androidapp.presenter;

import java.util.List;

import rx.Observable;
import suncere.androidapp.lib.mvp.api.ApiNetCallBack;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.CatchManager;
import suncere.shouchuang.androidapp.entity.AllCityBean;
import suncere.shouchuang.androidapp.entity.BaseModelBean;

import static suncere.androidapp.lib.utils.CatchManager.getDataFromCatch;

/**
 * Created by Hjo on 2017/11/15 14:49.
 */

public class HomePresenter<V extends IBaseView> extends BasePresenterChild<V> {

    private static  String mKey;
    public HomePresenter(V v) {
        super(v);
    }
    public void getAllcity(Observable observable,String... key) {
        mKey=key.toString();
        mIView.showRefresh();
        Object object=getDataFromCatch( mKey );
        if (object==null){
            getAllCityNetData(observable);
        }else{
            mIView.getDataSuccess((List<AllCityBean>)object);
        }
        mIView.finishRefresh();
    }


    private void  getAllCityNetData(Observable observable){
        addSubscription(observable, new ApiNetCallBack() {
            @Override
            public void onSuccess(Object response) {
                if (response!=null){
                    BaseModelBean baseModelBean= (BaseModelBean) response;
                    mIView.getDataSuccess(baseModelBean.getData());
                    CatchManager.putData2Cache(mKey,baseModelBean.getData());
                }else{
                    mIView.getDataSuccess(null);
                }
            }
            @Override
            public void onError(String msg) {
                mIView.getDataFail(msg);
            }
            @Override
            public void onFinish() {

            }
        });
    }

}
