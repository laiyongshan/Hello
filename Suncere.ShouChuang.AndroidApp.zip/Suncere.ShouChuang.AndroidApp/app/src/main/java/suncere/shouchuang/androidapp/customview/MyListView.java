package suncere.shouchuang.androidapp.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ListView;

public class MyListView extends ListView{
	
	 private static final String TAG = "ListViewX";
	    private int mLastX = 0;
	    private int mLastY = 0;

	public MyListView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		// TODO Auto-generated constructor stub
	}

	public MyListView(Context context, AttributeSet attrs) {
		this(context, attrs,0);
		// TODO Auto-generated constructor stub
	}

	public MyListView(Context context) {
		this(context,null);
		// TODO Auto-generated constructor stub
	}


	  @Override
	    public boolean dispatchTouchEvent(MotionEvent ev) {
	        int x = (int) ev.getX();
	        int y = (int) ev.getY();      
	        
	        switch (ev.getAction()) {
	            case MotionEvent.ACTION_DOWN: {
	                //������������
	                getParent().requestDisallowInterceptTouchEvent(true);
	                break;
	            }
	            
	            case MotionEvent.ACTION_MOVE: {
	                int deltaX = x - mLastX;
	                int deltaY = y - mLastY;
	                if(atTopOrEnd(deltaY)) {
	                    getParent().requestDisallowInterceptTouchEvent(false);
	                }
	                break;
	            }
	            case MotionEvent.ACTION_UP: {          	
	                break;
	            }
	            default:
	                break;
	        }

	        mLastX = x;
	        mLastY = y;

	        return super.dispatchTouchEvent(ev);
	    }

	//如果listView滑到顶端时当前事件向上滑动，需要scrollview接管， 在底端时类似。
	    private boolean atTopOrEnd(int len) {
	        int count = getCount();
	        int topId = getFirstVisiblePosition();
	        int endId = getLastVisiblePosition();

			/****该部分是验证下拉到最后时  交于父类处理*****/
	        if((endId == count - 1 && len < 0)) {
	            View lastView = getChildAt(getChildCount() - 1);
	            if(lastView  !=null && lastView.getBottom() == getHeight()) {
	                return true;
	            }
	        }
	        if(topId == 0 && len > 0) {
	            View firstView = getChildAt(topId);
	            if(firstView!=null && firstView.getTop() == 0) {
	                return true;
	            }
	        }
	        return false;
	    }
	
}
