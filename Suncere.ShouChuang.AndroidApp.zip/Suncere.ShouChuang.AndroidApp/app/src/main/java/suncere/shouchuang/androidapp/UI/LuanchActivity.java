package suncere.shouchuang.androidapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import suncere.androidapp.lib.mvp.ui.MyApplication;
import suncere.androidapp.lib.mvp.ui.baseui.BaseActivity;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.LeakCanaryUtil;

/**
 * Created by Hjo on 2017/11/23 15:17.
 */

public class LuanchActivity extends BaseActivity {

   private   Handler mHandler=new Handler();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.luanch_act);
//        StatusBarUtil.setTranslucent(LuanchActivity.this , 0 );
        intoMainAct();
    }

    private void intoMainAct(){
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent = new Intent(LuanchActivity.this, LoginActivity.class);
//                Intent intent = new Intent(LuanchActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, 3000);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        LeakCanaryUtil.fixMemoryLeak(this);
        mHandler.removeCallbacksAndMessages(null);
        mHandler=null;
        MyApplication.getRefWatcher(this).watch(this);
    }
}
