package suncere.shouchuang.androidapp.UI;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.adapter.RecyclerViewAdapter;
import suncere.androidapp.lib.customview.PollutantNameTextView;
import suncere.androidapp.lib.mvp.ui.baseui.MvpActivity;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.ColorUtils;
import suncere.shouchuang.androidapp.BR;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.CompareSort;
import suncere.shouchuang.androidapp.Utils.TimeType;
import suncere.shouchuang.androidapp.Utils.ToolUtils;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.entity.CompareStationBean;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;

/**
 * Created by Hjo on 2017/11/14 20:33.
 */

public class HomeCompareStationActivity extends MvpActivity<BasePresenterChild> implements IBaseView ,
        SwipeRefreshLayout.OnRefreshListener{

    @BindView(R.id.home_comparestation_SwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    @BindView(R.id.home_comparestation_recyclerview)
    RecyclerView mRecyclerView;

    @BindView(R.id.home_comparestation_select_pollutant)
    PollutantNameTextView mpollutantItme;

    @BindView(R.id.home_comparestation_select_timeposition)
    TextView mtimeposition;

    @BindView(R.id.home_comparestation_time)
    TextView mtime;

    @BindView(R.id.home_comparestation_UpOrDown_image)
    ImageView mUpOrDown_image;

    @BindView(R.id.home_comparestation_title)
    TextView mcomparestation_title;
    @BindView(R.id.null_data)
    LinearLayout null_data;

    @BindView(R.id.home_comparestation_pollutant)
    PollutantNameTextView home_comparestation_pollutant;

    RecyclerViewAdapter<CompareStationBean>mAdapter;
    BasePresenterChild mBasePresenterChild;
    CustomPopWindow mCustomPopWindowPollutant;
    CustomPopWindow mCustomPopWindowTime;
    String mPollutantName="AQI";
    String mCityCode;
//    String CityName;
    String mReportTimeType="4";

    List<CompareStationBean>mlistCityData;
    boolean isUpOrDown=true;// true 为正序
    String mStationType;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.home_comparestation_activity);
        ButterKnife.bind(this);
        initView();
    }

    @Override
    protected void onStart() {
        super.onStart();
        getData();
    }

    @Override
    protected BasePresenterChild createPresenter() {
        mBasePresenterChild=new BasePresenterChild(this);
        return mBasePresenterChild;
    }

    private void initView(){
        mAdapter=new RecyclerViewAdapter<>(this,R.layout.home_compare_recyclerview_itme, BR.compareStationBean);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter);
        mSwipeRefreshLayout.setColorSchemeColors(ColorUtils.Colors);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        Intent intent=getIntent();
        mCityCode=intent.getStringExtra("id");
        mStationType=intent.getStringExtra("ReportTimeType");
        findStation();

        mlistCityData=new ArrayList<>();
    }

    private void findStation(){
        int station=Integer.valueOf(mStationType);
        switch (station){
            case 0:
                mcomparestation_title.setText("朝阳区各站点监测项及同期消减率");
                mCityCode="5158dc6a-7f52-4425-89eb-df4d774b2c16";
                break;
            case 1:
                mcomparestation_title.setText("顺义区各站点监测项及同期消减率");
                mCityCode="1d60bda6-6943-4c09-b37a-19005883411c";
                break;
            case 2:
                mcomparestation_title.setText("石景山区各站点监测项及同期消减率");
                mCityCode="4902485e-28b4-4eb1-917b-2587635346cf";
                break;
        }
    }

    private void getData(){
        if ("PM2.5".equals(mPollutantName))mPollutantName="PM2_5";
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().compareData(mCityCode,mPollutantName,mReportTimeType), mCityCode+mPollutantName);
    }

    @Override
    public void getDataSuccess(Object response) {
        mlistCityData.clear();
        if (response==null){
            null_data.setVisibility(View.VISIBLE);
        }else{
            mlistCityData.addAll((Collection<CompareStationBean>) response);
            null_data.setVisibility(View.GONE);

            if (mReportTimeType.equals(TimeType.DayTime.getIndex()+"")){  // 日
                mtime.setText(ToolUtils.getLastDay()+"更新");

            }else if (mReportTimeType.equals(TimeType.MonthTime.getIndex()+"")){
                mtime.setText(ToolUtils.getLastMonth()+"更新");

            }else if (mReportTimeType.equals(TimeType.YearTime.getIndex()+""))
            mtime.setText(ToolUtils.getLastYear()+"更新");
        }
        findCity2Frist();
    }

    private void findCity2Frist(){
        Collections.sort(mlistCityData,new CompareSort(isUpOrDown));
        mAdapter.setData(mlistCityData);
    }

    @OnClick({R.id.home_comparestation_select_pollutant,R.id.home_comparestation_select_timeposition,R.id.home_comparestation_top_back,R.id.home_comparestation_UpOrDown})
    public void  on_click(View view ){
        switch (view.getId()){
            case R.id.home_comparestation_select_pollutant:
                showPollutantMenu();
                break;
                case R.id.home_comparestation_select_timeposition:
                    showTimeMenu();
                break;
            case R.id.home_comparestation_top_back:
                finish();
                break;
            case R.id.home_comparestation_UpOrDown:
                isUpOrDown=!isUpOrDown;
                if (isUpOrDown){
                    mUpOrDown_image.setImageResource(R.mipmap.list_up);
                }else{
                    mUpOrDown_image.setImageResource(R.mipmap.list_down);
                }
                findCity2Frist();
                break;
        }
    }

    private void showPollutantMenu(){
        View contentView = LayoutInflater.from(this).inflate(R.layout.map_chart_pollutant_itme,null);
        PollutantMenuListener(contentView);
        mCustomPopWindowPollutant= new CustomPopWindow.PopupWindowBuilder(this).setView(contentView).create();
        mCustomPopWindowPollutant .showAsDropDown(mpollutantItme,6,-(mpollutantItme.getHeight()+mCustomPopWindowPollutant.getHeight()));
    }
    private void PollutantMenuListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCustomPopWindowPollutant!=null){
                    mCustomPopWindowPollutant.dissmiss();
                }
                mPollutantName=((TextView)v).getText().toString();
                mpollutantItme.setText(mPollutantName);
                home_comparestation_pollutant.setText(mPollutantName);
                getData();
            }
        };
        contentView.findViewById(R.id.AQI).setOnClickListener(listener);
        contentView.findViewById(R.id.SO2).setOnClickListener(listener);
        contentView.findViewById(R.id.NO2).setOnClickListener(listener);
        contentView.findViewById(R.id.CO).setOnClickListener(listener);
        contentView.findViewById(R.id.O3).setOnClickListener(listener);
        contentView.findViewById(R.id.PM2_5).setOnClickListener(listener);
        contentView.findViewById(R.id.PM10).setOnClickListener(listener);
    }


    private void showTimeMenu(){
        View contentView = LayoutInflater.from(this).inflate(R.layout.compare_time_itme,null);
        TimePositionListener(contentView);
        mCustomPopWindowTime= new CustomPopWindow.PopupWindowBuilder(this).setView(contentView).create();
        mCustomPopWindowTime .showAsDropDown(mtimeposition,6,-(mtimeposition.getHeight()+mCustomPopWindowTime.getHeight()));
    }

    private void TimePositionListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mCustomPopWindowTime!=null){
                    mCustomPopWindowTime.dissmiss();
                }
                mReportTimeType=((TextView)v).getTag().toString();
                String text=((TextView)v).getText().toString();
                mtimeposition.setText(text);
                getData();
            }
        };
        contentView.findViewById(R.id.compare_day).setOnClickListener(listener);
        contentView.findViewById(R.id.compare_month).setOnClickListener(listener);
        contentView.findViewById(R.id.compare_year).setOnClickListener(listener);
    }

    @Override
    public void onRefresh() {
        getData();
    }
    @Override
    public void showRefresh() {
        mSwipeRefreshLayout.setRefreshing(true);
    }

    @Override
    public void finishRefresh() {
        mSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void getDataFail(String msg) {

    }

//    @Override
//    public void OnBindItmeView(final View view, Object obejct, int position, int selectPosition, int tag) {
//        if (position==0){
//            view.setBackgroundColor(Color.parseColor("#D0E8F4"));
//        }
//        view.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                ViewHolder.getView(view,R.id.home_comparestation_itme_pollutantName).setFocusable(true);
//            }
//        });
//    }


}
