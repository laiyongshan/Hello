package suncere.shouchuang.androidapp.Utils;

/**
 * Created by Hjo on 2017/11/14 16:27.
 */

public enum  TimeType  {

    LiveTime("LiveTime",3),//实时
    DayTime("DayTime",4), //当日
    WeekTime("WeekTime",5), //星期
    MonthTime("MonthTime",6), //月
    SeasonTime("SeasonTime",7), //季
    YearTime("YearTime",8);//年

    private String name ;
    private int index ;
    private TimeType(String name , int index ){
        this.name = name ;
        this.index = index ;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getIndex() {
        return index;
    }
    public void setIndex(int index) {
        this.index = index;
    }

}
