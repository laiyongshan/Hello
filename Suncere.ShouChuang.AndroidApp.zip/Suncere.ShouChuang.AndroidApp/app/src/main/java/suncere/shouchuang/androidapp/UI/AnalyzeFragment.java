package suncere.shouchuang.androidapp.UI;

import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bigkoo.pickerview.listener.CustomListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.adapter.RecyclerViewAdapter;
import suncere.androidapp.lib.mvp.ui.baseui.MvpFragment;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.shouchuang.androidapp.BR;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.TimeType;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.customview.OptionsPickerView2;
import suncere.shouchuang.androidapp.customview.TimePickerView2;
import suncere.shouchuang.androidapp.entity.AnalyzeItmeBean;
import suncere.shouchuang.androidapp.entity.WeekOrSeasonBean;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;

/**
 * Created by Hjo on 2017/11/10 11:55.
 */
public class AnalyzeFragment extends MvpFragment<BasePresenterChild> implements IBaseView{

    @BindView(R.id.analyze_typetime_select)
    LinearLayout analyze_typetime_select;
    @BindView(R.id.analyze_typetime_select_text)
    TextView analyze_typetime_select_text;
    @BindView(R.id.analyze_itme_select)
    LinearLayout analyze_Stationitme_select;
    @BindView(R.id.analyze_itme_select_text)
    TextView analyze_Stationitme_select_text;
    @BindView(R.id.analyze_starttime_select_text)
    TextView analyze_starttime_select_text;
    @BindView(R.id.analyze_RecyclerView)
    RecyclerView mRecyclerView;
//    @BindView(R.id.analyze_SwipeRefreshLayout)
//    SwipeRefreshLayout mSwipeRefreshLayout;

    BasePresenterChild mBasePresenterChild;
    CustomPopWindow mSelectTimeItme;
    View mSelectTimeItmeView;
    CustomPopWindow mSelectStaionItme;
    View mSelectStationItmeView;
    RecyclerViewAdapter <AnalyzeItmeBean>mAdapter;
    TimePickerView2 mTimePickerView;
    OptionsPickerView2 pvOptions;
    int mTimeTypeTag=4;// 4:日  5：周  6:月  7：季  8：年
    List<AnalyzeItmeBean> mListData;
    String  mSelectItmeName="朝阳区";
    String  mSelectItmeNameId="5158dc6a-7f52-4425-89eb-df4d774b2c16";
    String  mSelectTimeType="日报";
    Date mSelectStartDate;
    Date mSelectEndDate;
    Calendar mSelectStartCalendar;
    Calendar mSelectEndCalendar;

    int mSelectStartYear;// 选择的开始年份
    int mSelectStartMonth;// 选择的开始月份
    int mSelectStartWeek;// 选择的开始星期
    int mSelectStartSeason;// 择的开始季度

    int mSelectEndYear;// 选择的结束年份
    int mSelectEndMonth;// 选择的结束月份
    int mSelectEndWeek;// 选择的结束星期
    int mSelectEndSeason;// 选择的结束季度
    int[]mSelectStartWeekPosition=new int[3]; // 开始默认选中的位置
    int[]mSelectStartSesionPosition=new int[2];
    int[]mSelectEndWeekPosition=new int[3];// 结束默认选中的位置
    int[]mSelectEndSesionPosition=new int[2];

    Calendar mRangStartDate; // 可选的开始时间
    Calendar mRangEndDate;  //  可选的结束时间
    int mStartYear; //可选的开始年份
    int mEndYear;   // 可选的结束年份
    int mEndMonth;// 可选的结束月份
    ArrayList<WeekOrSeasonBean> options1Items = new ArrayList<>();
    ArrayList<ArrayList<String>> options2MonthItems = new ArrayList<>();
    ArrayList<ArrayList<String>> options2SeasionItems = new ArrayList<>();
    ArrayList<ArrayList<ArrayList<String>>> options3WeekItems = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.analyze_fragment,container,false);
        ButterKnife.bind(this,view);
        initView();
        return view;
    }

    @Override
    protected BasePresenterChild createPresenter() {
        mBasePresenterChild=new BasePresenterChild(this);
        return mBasePresenterChild;
    }

    @Override
    public void onStart() {
        super.onStart();
        new Thread(){
            @Override
            public void run() {
                initYearData();
                initSeasonData();
                initMonthData();
                initWeekData();
            }
        }.start();
        initCustomTimePicker();
        initOptionPicker();
    }

    private void initView(){
        mSelectTimeItmeView = LayoutInflater.from(getActivity()).inflate(R.layout.analyze_time_itme,null);
        mSelectTimeItme= new CustomPopWindow.PopupWindowBuilder(getActivity()).setView(mSelectTimeItmeView).create();
        bindSelectTimeItmeListener(mSelectTimeItmeView);

        mSelectStationItmeView = LayoutInflater.from(getActivity()).inflate(R.layout.analyze_station_itme,null);
        mSelectStaionItme= new CustomPopWindow.PopupWindowBuilder(getActivity()).setView(mSelectStationItmeView).create();
        bindSelectStationItmeListener(mSelectStationItmeView);

        mListData=new ArrayList<>();
        String time=getTimeFromCalendar(Calendar.getInstance());
        mListData.add( new AnalyzeItmeBean(mSelectItmeName,mSelectItmeNameId,mSelectTimeType,mTimeTypeTag+"",time));

        mRangStartDate = Calendar.getInstance();
        mRangStartDate.set(2016, 0, 1);
        mRangEndDate= Calendar.getInstance();
        mStartYear=mRangStartDate.get(Calendar.YEAR);//      getIntCalendarTimeIndex(mRangStartDate,Calendar.YEAR);
        mEndYear =mRangEndDate.get(Calendar.YEAR);// (mRangEndDate,Calendar.YEAR);
        mEndMonth=mRangEndDate.get(Calendar.MONTH)+1;
        mSelectStartDate =new Date();
        mSelectEndDate=new Date();

        mAdapter=new RecyclerViewAdapter<>(getActivity(),R.layout.analyze_itme_layout, BR.analyzeItmeBean);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setData(mListData);
    }

    // 年份数据
    private void initYearData(){
        options1Items.clear();
        for (int i=mStartYear;i<=mEndYear;i++){
            options1Items.add(new WeekOrSeasonBean(i+""));
        }
        // 设置季度、星期默认选中的时间和位置  默认选择最后一个
        mSelectStartYear=Integer.valueOf(options1Items.get(options1Items.size()-1).getYear());
        mSelectEndYear =mSelectStartYear;
        mSelectStartWeekPosition[0]=options1Items.size()-1;
        mSelectStartSesionPosition[0]=options1Items.size()-1;
        mSelectEndWeekPosition[0]=options1Items.size()-1;
        mSelectEndSesionPosition[0]=options1Items.size()-1;
    }
    // 季节数据
    private void initSeasonData(){
        options2SeasionItems.clear();
        int nowSeason=mEndMonth%3==0? mEndMonth/3 : mEndMonth/3+1 ; // 余数为0 ： 3  6  9  12
        for (int i=mStartYear;i<=mEndYear;i++){
            ArrayList<String > seasons=new ArrayList<>();
            if (i!=mEndYear){
                for (int k=1;k<=4;k++){
                    seasons.add(k+"");
                }
            }else{ // 当前年份
                for (int k=1;k<=nowSeason;k++){
                    seasons.add(k+"");
                }
            }
            options2SeasionItems.add(seasons);
        }
        mSelectStartSeason=Integer.valueOf(options2SeasionItems.get(mSelectStartWeekPosition[0]).get(options2SeasionItems.get(mSelectStartWeekPosition[0]).size()-1));
        mSelectEndSeason=mSelectStartSeason;
        mSelectStartSesionPosition[1]=options2SeasionItems.get(mSelectStartWeekPosition[0]).size()-1;
        mSelectEndSesionPosition[1]=options2SeasionItems.get(mSelectStartWeekPosition[0]).size()-1;

    }
    // 月份数据
    private void initMonthData(){
        options2MonthItems.clear();
        for (int i=mStartYear;i<=mEndYear;i++){
            ArrayList <String > months=new ArrayList<>();
            if (i!=mEndYear){
                for (int k=1;k<=12;k++){
                    months.add(k+"");
                }
            }else{ // 当前年份
                for (int k=1;k<=mEndMonth;k++){
                    months.add(k+"");
                }
            }
            options2MonthItems.add(months);
        }
        mSelectStartMonth=Integer.valueOf(options2MonthItems.get(mSelectStartWeekPosition[0]).get(options2MonthItems.get(mSelectStartWeekPosition[0]).size()-1));
        mSelectEndMonth=mSelectStartMonth;
        mSelectStartWeekPosition[1]=options2MonthItems.get(mSelectStartWeekPosition[0]).size()-1;
        mSelectEndWeekPosition[1]= mSelectStartWeekPosition[1];
    }
    // 初始的星期数据
    private void initWeekData(){
        options3WeekItems.clear();

        mRangStartDate.setFirstDayOfWeek(Calendar.MONDAY);// 设置一周的开始是周一
        mRangEndDate.setFirstDayOfWeek(Calendar.MONDAY);
        for (int i=mStartYear;i<=mEndYear;i++){
            ArrayList<ArrayList<String>>monthWeek=new ArrayList<>();
            if (i!=mEndYear ){ // 不是当前年份
                for (int k=0;k<12;k++){  // 注意  需要构造日期  所以月份从0开始
                    int week=getMonthWeeks(i,k);  // 获取当前月有几周
                    ArrayList<String> weeks=new ArrayList<>();// 保存周的个数
                    for (int t=1;t<=week;t++){
                        weeks.add(t+"");
                    }
                    monthWeek.add(weeks);
                }
            }else{  // 当前年份
                for (int k=0;k<mEndMonth;k++){
                    ArrayList<String> weeks=new ArrayList<>();// 保存周的个数
                    if(k<mEndMonth-1){
                        int week=getMonthWeeks(i,k);
                        for (int t=1;t<=week;t++){
                            weeks.add(t+"");
                        }
                    }else {  // 当前月
                        int week = mRangEndDate.get(Calendar.WEEK_OF_MONTH);//获取当前日期是本月的第几周
                        for (int t=1;t<=week;t++){
                            weeks.add(t+"");
                        }
                    }
                    monthWeek.add(weeks);
                }
            }
            options3WeekItems.add(monthWeek);
        }

        ArrayList<ArrayList<String>>monthWeek=options3WeekItems.get(mSelectStartWeekPosition[0]);
        ArrayList<String> weeks=monthWeek.get(mSelectStartWeekPosition[1]);
//        mSelectStartWeek=Integer.valueOf(options3WeekItems.get(mSelectStartWeekPosition[0])// 最后一个年份
//                .get(mSelectStartWeekPosition[1])// 最后一个月份
//                .get(options3WeekItems.get(mSelectStartWeekPosition[1]).size()-1));//最后一个星期
        mSelectStartWeek=Integer.valueOf(weeks.get(weeks.size()-1));
        mSelectEndWeek=mSelectStartWeek;
        mSelectStartWeekPosition[2]=weeks.size();//options3WeekItems.get(mSelectStartWeekPosition[0]).get(options3WeekItems.get(mSelectStartWeekPosition[0]).size()-1).size()-1;
        mSelectEndWeekPosition[2]=  mSelectStartWeekPosition[2];

    }

    // 获取某年某月有几周
    private int  getMonthWeeks(int year,int month){
        Calendar calendar=Calendar.getInstance();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH,month);
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        int weeks=calendar.getActualMaximum(Calendar.WEEK_OF_MONTH);  // 获取当前月有几周
        return weeks;
    }
    @Override
    public void getDataSuccess(Object response) {

    }
    @Override
    public void getDataFail(String msg) {

    }
    @Override
    public void showRefresh() {

    }

    @Override
    public void finishRefresh() {

    }

    @OnClick({R.id.analyze_typetime_select,R.id.analyze_itme_select,R.id.analyze_starttime_select})//,R.id.analyze_endtime_select
    public void on_onclick(View view){
        switch (view.getId()){
            case R.id.analyze_typetime_select:
//                startActivity(new Intent(getActivity(),AnalyzePreViewActivity.class));
                showSelectTimeItme();
                break;
            case R.id.analyze_itme_select:
                showSelectStationItme();
                break;
            case R.id.analyze_starttime_select:
                if (mTimeTypeTag!=TimeType.WeekTime.getIndex() && mTimeTypeTag !=TimeType.SeasonTime.getIndex()){
                    final boolean  isMonth=mTimeTypeTag== TimeType.DayTime.getIndex() || mTimeTypeTag== TimeType.MonthTime.getIndex();
                    final boolean  isDay=mTimeTypeTag== TimeType.DayTime.getIndex();
                    mTimePickerView.setViewVisibility(new boolean[]{true, isMonth,isDay , false, false, false});
                    mTimePickerView.setDate(mSelectStartCalendar,mSelectEndCalendar);
                    mTimePickerView.show();
                } else{
                    if (mTimeTypeTag==TimeType.WeekTime.getIndex()){
                        pvOptions.setLabel("年","月","周");
                        pvOptions.setSelectOptions(mSelectStartWeekPosition[0],mSelectStartWeekPosition[1],mSelectStartWeekPosition[2],
                                mSelectEndWeekPosition[0],mSelectEndWeekPosition[1],mSelectEndWeekPosition[2]);
                        pvOptions.setPicker(options1Items, options2MonthItems,options3WeekItems);
                    } else{
                        pvOptions.setLabel("年","季","");
                        pvOptions.setSelectOptions(mSelectStartSesionPosition[0],mSelectStartSesionPosition[1],
                                mSelectEndSesionPosition[0],mSelectEndSesionPosition[1]);
                        pvOptions.setPicker(options1Items, options2SeasionItems);
                    }
                    pvOptions.show();
                }
                break;
        }
    }

    // 选择地区改变数据
    private void changeItemDataFormStationName(){
        for (int i=0;i<mListData.size();i++){
            mListData.get(i).setItmeName(mSelectItmeName);
            mListData.get(i).setItmeId(mSelectItmeNameId);
        }
        mAdapter.setData(mListData);
    }
    // 根据选择的年、月、日改变数据
    private void changeItemDataFormTime(){
        mListData.clear();
        if (mTimeTypeTag==TimeType.YearTime.getIndex()){ // 年
            int endYear=mSelectEndCalendar.get(Calendar.YEAR);
            for (int i=mSelectStartCalendar.get(Calendar.YEAR);i<=endYear;i++){
                addData(i+"");
            }
        }else if (mTimeTypeTag==TimeType.MonthTime.getIndex()){ // 月
            int startYear=mSelectStartCalendar.get(Calendar.YEAR);
            int endYear=mSelectEndCalendar.get(Calendar.YEAR);
            int startMonth=mSelectStartCalendar.get(Calendar.MONTH);
            int endMonth=mSelectEndCalendar.get(Calendar.MONTH);
            if (startYear==endYear){  // 选择的年份相同
                for (int k= startMonth;k<=endMonth;k++){
                    addData(startYear+"/"+(k+1));
                }
            }else{ // 不同年份
                for (int i=startYear;i<=endYear;i++){
                    if (i==startYear){
                        for (int k= startMonth;k<12;k++){
                            addData(i+"/"+(k+1));
                        }
                    }else if (i==endYear){
                        for (int k= 0;k<=endMonth;k++){
                            addData(i+"/"+(k+1));
                        }
                    }else{
                        for (int k= 0;k<12;k++){
                            addData(i+"/"+(k+1));
                        }
                    }
                }
            }
        }else if(mTimeTypeTag==TimeType.DayTime.getIndex()){  // 计算两个日期之间相差的天数 ，然后使用日期类从开始时间逐天增加
            Calendar calendar=Calendar.getInstance();
            calendar.setTime(mSelectStartDate);
            int startDay=mSelectStartCalendar.get(Calendar.DATE);

            // 格式化日期:这么处理后  2017-11-28 10:23:33 与 2017-11-29 8:10:10 相差天数为1
            //             2017-11-28 10:23:33 与 2017-11-29 12:10:10 相差天数也为1
            SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd 00:00:00");
            String  begint=format1.format(mSelectStartDate);
            String  end=format1.format(mSelectEndDate);
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date begintDate ;
            Date endDate;
            int days=0;
//            Calendar calendar=Calendar.getInstance();
            try {
                begintDate=format.parse(begint);
                endDate =format.parse(end);
                days = (int) ((endDate.getTime()-begintDate.getTime() ) / (1000*3600*24)) +1;
            } catch (ParseException e) {
                e.printStackTrace();
            }
            for (int i=0;i<days;i++) {
//                calendar.setTime(begintDate);
                addData(getTimeFromCalendar(calendar));
//                calendar.set(Calendar.DAY_OF_YEAR, startDay + i);
                calendar.add(Calendar.DATE,1);// 日期加1
            }
        }
        mAdapter.setData(mListData);
    }
    // 根据选择的季度改变数据
    private void  changeItmeDataFormSeason(){
        mListData.clear();
        if (mSelectStartYear==mSelectEndYear){  // 两个年份相等时
            for (int k=mSelectStartSeason;k<=mSelectEndSeason;k++){
                addData(mSelectStartYear+"-"+k);
            }
        }else{
            for (int i=mSelectStartYear;i<=mSelectEndYear;i++){
                if (i==mSelectStartYear){
                    for (int k=mSelectStartSeason;k<=4;k++){
                        addData(i+"-"+k);
                    }
                }else if (i==mSelectEndYear){
                    for (int k=1;k<=mSelectEndSeason;k++){
                        addData(i+"-"+k);
                    }
                }else{
                    for (int k=1;k<=4;k++){
                        addData(i+"-"+k);
                    }
                }
            }
        }
        mAdapter.setData(mListData);
    }
    // 根据选择的星期改变数据
    private void  changeItmeDataFormWeek(){ // 注意  这里月份都已经+1  所有不需要计较月份的显示是0-11
        mListData.clear();
        if (mSelectStartYear==mSelectEndYear){ // 年份相同
            if (mSelectStartMonth==mSelectEndMonth){ // 月份相同
                for (int w=mSelectStartWeek;w<=mSelectEndWeek;w++){
                    addData(mSelectStartYear+"/"+mSelectStartMonth+"-"+w);
                }
            }else{
                for (int m=mSelectStartMonth;m<=mSelectEndMonth;m++){
                    int week=getMonthWeeks(mSelectStartMonth,m);// 获取月份有几周
                    if (m==mSelectStartMonth){ // 开始月份
                        for(int w=mSelectStartWeek;w<=week;w++){
                            addData(mSelectStartYear+"/"+m+"-"+w);
                        }
                    }else if (m==mSelectEndMonth){ // 结束月份
                        for(int w=1;w<=mSelectEndWeek;w++){
                            addData(mSelectStartYear+"/"+m+"-"+w);
                        }
                    }else{
                        for(int w=1;w<=week;w++){
                            addData(mSelectStartYear+"/"+m+"-"+w);
                        }
                    }
                }
            }
        }else{  // 不同年份
            for(int y=mSelectStartYear;y<=mSelectEndYear;y++){
                if (y==mSelectStartYear){ // 开始年份
                    for(int m=mSelectStartMonth;m<=12;m++){
                        int week=getMonthWeeks(y,m);
                        if (m==mSelectStartMonth){ // 开始的月份与开始的星期
                            for (int w=mSelectStartWeek;w<=week;w++){ // 星期范围是从选择的第几星期到当月最后一个星期
                                addData(y+"/"+m+"-"+w);
                            }
                        }else{
                            for (int w=1;w<=week;w++){
                                addData(y+"/"+m+"-"+w);
                            }
                        }
                    }
                }else if (y==mSelectEndYear){  // 结束年份
                    for(int m=1;m<=mSelectEndMonth;m++){
                        int week=getMonthWeeks(y,m);
                        if (m==mSelectEndMonth){  // 等于结束的月份
                            for (int w=1;w<=mSelectEndWeek;w++){  // 星期范围是从1到选择的第几星期
                                addData(y+"/"+m+"-"+w);
                            }
                        }else{
                            for (int w=1;w<=week;w++){
                                addData(y+"/"+m+"-"+w);
                            }
                        }
                    }
                }else { // 其他年份 有12月  每个月有多少个星期就添加多少个
                    for (int m=1;m<=12;m++){
                        int week=getMonthWeeks(y,m);
                        for (int w=1;w<=week;w++){
                            addData(y+"/"+m+"-"+w);
                        }
                    }
                }

            }
        }
        mAdapter.setData(mListData);
    }

    private void  addData(String time){
        mListData.add(new AnalyzeItmeBean(mSelectItmeName,mSelectItmeNameId,mSelectTimeType, mTimeTypeTag+"",time));
    }

    private void initCustomTimePicker() {

        if (mSelectStartCalendar==null)mSelectStartCalendar=mRangEndDate;
        if (mSelectEndCalendar==null)mSelectEndCalendar=mRangEndDate;
        analyze_starttime_select_text.setText(getTimeFromCalendar (mSelectStartCalendar)+"~"+getTimeFromCalendar (mSelectEndCalendar));
        //时间选择器 ，自定义布局
        mTimePickerView = new TimePickerView2.Builder(getActivity(), new TimePickerView2.OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date,Date date2 ,View v) {//选中事件回调
                Calendar calendar1   =Calendar.getInstance();
                calendar1.setTime(date);
                mSelectStartCalendar=calendar1;

                Calendar calendar2   =Calendar.getInstance();
                calendar2.setTime(date2);
                mSelectEndCalendar=calendar2;

                mSelectStartDate=date;
                mSelectEndDate=date2;
                changeItemDataFormTime();
                analyze_starttime_select_text.setText(getTimeFromCalendar (mSelectStartCalendar)+"~"+getTimeFromCalendar (mSelectEndCalendar));
            }
        }).setDate(mSelectStartCalendar)
                .setDate2(mSelectEndCalendar)
                .setRangDate(mRangStartDate, mRangEndDate)
                .setLayoutRes(R.layout.pickerview_custom_time2, new CustomListener() {
                    @Override
                    public void customLayout(View v) {
                        final TextView tvSubmit = (TextView) v.findViewById(R.id.tv_finish);
                        ImageView ivCancel = (ImageView) v.findViewById(R.id.iv_cancel);
                        tvSubmit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mTimePickerView.returnData();
                                mTimePickerView.dismiss();
                            }
                        });
                        ivCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mTimePickerView.dismiss();
                            }
                        });
                    }
                })
                .setContentSize(18)
//                .setType(new boolean[]{true, isMonth,isDay , false, false, false})
                .setLabel("年", "月", "日", "", "", "")
                .setLineSpacingMultiplier(1.8f)
                .setTextXOffset(0, 0, 0, 40, 0, -40)
                .isCenterLabel(false)
                .setDividerColor(0xFF24AD9D)
                .build();
    }
    private void initOptionPicker() {//条件选择器初始化
        pvOptions = new OptionsPickerView2.Builder(getActivity(), new OptionsPickerView2.OnOptionsSelectListener() {
            @Override
            public void onOptionsSelect(int []po, int[] op2, View v) {
                // 注意 ：如果是三级联动的数据(省市区等)，请参照 JsonDataActivity 类里面的写法。
                //返回的分别是三个级别的选中位置
                mSelectStartYear=Integer.valueOf(options1Items.get(po[0]).getPickerViewText());
                mSelectEndYear=Integer.valueOf(options1Items.get(op2[0]).getPickerViewText());

                if (mTimeTypeTag==TimeType.WeekTime.getIndex()){
                    mSelectStartWeekPosition=po;
                    mSelectEndWeekPosition=op2;
                    mSelectStartMonth=Integer.valueOf(options2MonthItems.get(po[0]).get(po[1]));
                    mSelectEndMonth=Integer.valueOf( options2MonthItems.get(op2[0]).get(op2[1]));
                    mSelectStartWeek=Integer.valueOf(options3WeekItems.get(po[0]).get(po[1]).get(po[2]));
                    mSelectEndWeek=Integer.valueOf(options3WeekItems.get(op2[0]).get(op2[1]).get(op2[2]));
                    String tx1 =  mSelectStartYear+"/"+ mSelectStartMonth  +"-"+ mSelectStartWeek;
                    String tx2 = mSelectEndYear  +"/"+ mSelectEndMonth +"-"+ mSelectEndWeek;
                    analyze_starttime_select_text.setText(tx1+"~"+tx2);
                    changeItmeDataFormWeek();
                }else if (mTimeTypeTag==TimeType.SeasonTime.getIndex()){
                    mSelectStartSesionPosition=po;
                    mSelectEndSesionPosition=op2;
                    mSelectStartSeason=Integer.valueOf( options2SeasionItems.get(po[0]).get(po[1]));
                    mSelectEndSeason=Integer.valueOf( options2SeasionItems.get(op2[0]).get(op2[1]));
                    String tx1 = mSelectStartYear  +"-"+mSelectStartSeason ;
                    String tx2 =mSelectEndYear +"-"+mSelectEndSeason;
                    analyze_starttime_select_text.setText(tx1+"~"+tx2);
                    changeItmeDataFormSeason();
                }
            }
        })
                .setTitleText("")
                .setContentTextSize(18)//设置滚轮文字大小
                .setDividerColor(Color.LTGRAY)//设置分割线的颜色
                .setSelectOptions(0, 1)//默认选中项
                .setBgColor(Color.WHITE)
                .setTitleBgColor(Color.WHITE)
                .setTitleColor(Color.LTGRAY)
                .setCancelColor(Color.BLACK)
                .setSubmitColor(Color.BLACK)
                .setTextColorCenter(Color.BLACK)
                .setLayoutRes(R.layout.pickerview_custom_time3, new CustomListener() {
                    @Override
                    public void customLayout(View v) {
                        final TextView tvSubmit = (TextView) v.findViewById(R.id.tv_finish);
                        ImageView ivCancel = (ImageView) v.findViewById(R.id.iv_cancel);
                        tvSubmit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                pvOptions.returnData();
                                pvOptions.dismiss();
                            }
                        });
                        ivCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                pvOptions.dismiss();
                            }
                        });
                    }
                })
                .setLineSpacingMultiplier(1.8f)
                .isCenterLabel(false) //是否只显示中间选中项的label文字，false则每项item全部都带有label。
                .setLabels("", "", "")
                .setBackgroundId(0x66000000) //设置外部遮罩颜色
                .build();
        //pvOptions.setSelectOptions(1,1);
    }


    private String getTimeFromCalendar(Calendar calendar) {//可根据需要自行截取数据显示
        String yearStr=calendar.get(Calendar.YEAR)+"";
        String monthStr="";
        String dayStr="";
        String time=yearStr;
        if (mTimeTypeTag== TimeType.DayTime.getIndex() || mTimeTypeTag== TimeType.MonthTime.getIndex()){
            monthStr=calendar.get(Calendar.MONTH)+1+"";
            time=time+"-"+monthStr;
        }
        if (mTimeTypeTag== TimeType.DayTime.getIndex()){
            dayStr=calendar.get(Calendar.DATE)+"";
            time=time+"-"+dayStr;
        }
        return time  ;
    }

    private void showSelectTimeItme(){
        mSelectTimeItme .showAsDropDown(analyze_typetime_select,0,10);
    }
    /**
     * 处理弹出显示内容、点击事件等逻辑
     * @param contentView
     */
    private void bindSelectTimeItmeListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mSelectTimeItme!=null){
                    mSelectTimeItme.dissmiss();
                }
                mSelectTimeType=((TextView)v).getText().toString();
                analyze_typetime_select_text.setText(mSelectTimeType);
                mTimeTypeTag= Integer.valueOf( v.getTag().toString());
                if (mTimeTypeTag!=TimeType.WeekTime.getIndex() && mTimeTypeTag !=TimeType.SeasonTime.getIndex()){
                    analyze_starttime_select_text.setText(getTimeFromCalendar (mSelectStartCalendar)+"~"+getTimeFromCalendar (mSelectEndCalendar));
                    changeItemDataFormTime();
                }else{
                    if (mTimeTypeTag==TimeType.WeekTime.getIndex()){  // 周
                        String tx1 =  mSelectStartYear+"/"+ mSelectStartMonth  +"-"+ mSelectStartWeek;
                        String tx2 = mSelectEndYear  +"/"+ mSelectEndMonth +"-"+ mSelectEndWeek;
                        analyze_starttime_select_text.setText(tx1+"~"+tx2);
                        changeItmeDataFormWeek();
                    }else{  // 季度
                        String tx1 = mSelectStartYear  +"-"+mSelectStartSeason ;
                        String tx2 =mSelectEndYear +"-"+mSelectEndSeason;
                        analyze_starttime_select_text.setText(tx1+"~"+tx2);
                        changeItmeDataFormSeason();
                    }
                }
            }
        };
        contentView.findViewById(R.id.analyze_day).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_week).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_month).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_season).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_year).setOnClickListener(listener);

    }

    private void showSelectStationItme(){
        mSelectStaionItme .showAsDropDown(analyze_Stationitme_select,0,10);
    }
    private void bindSelectStationItmeListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mSelectStaionItme!=null){
                    mSelectStaionItme.dissmiss();
                }
                mSelectItmeName=((TextView)v).getText().toString();
                mSelectItmeNameId=v.getTag().toString();
                analyze_Stationitme_select_text.setText(mSelectItmeName);
                changeItemDataFormStationName();
            }
        };
        contentView.findViewById(R.id.analyze_chaoyangqu).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_shunyiqu).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_shijingshan).setOnClickListener(listener);
    }

}
