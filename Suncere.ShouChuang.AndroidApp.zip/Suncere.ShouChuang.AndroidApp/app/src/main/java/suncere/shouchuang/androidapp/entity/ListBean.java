package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;

/**
 * Created by Hjo on 2017/11/17 09:55.
 */

public class ListBean  extends BaseBean {
    /**
     * StatioinCode : 周口市
     * PrimaryPollutant : PM2_5
     * Value : 500
     * Level : 4
     * Rank : 1
     */

    private String StatioinCode;
    private String PrimaryPollutant;
    private String Value;
    private String Level;
    private String Rank;


    public String getStatioinCode() {
        return StatioinCode;
    }

    public void setStatioinCode(String statioinCode) {
        StatioinCode = statioinCode;
    }

    public String getPrimaryPollutant() {
        return PrimaryPollutant;
    }

    public void setPrimaryPollutant(String primaryPollutant) {
        PrimaryPollutant = primaryPollutant;
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        Value = value;
    }

    public String getLevel() {
        return Level;
    }

    public void setLevel(String level) {
        Level = level;
    }

    public String getRank() {
        return Rank;
    }

    public void setRank(String rank) {
        Rank = rank;
    }
}
