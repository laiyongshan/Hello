package suncere.shouchuang.androidapp.entity;

import suncere.androidapp.lib.mvp.entity.BaseBean;


/**
 * Created by Hjo on 2017/11/13 17:25.
 */
public class HomeCityBean extends BaseBean {

    /**
     * CityCode : 110000
     * PM2_5 : 5.9
     * PM2_5_Level : 1
     * O3_8h : null
     * O3_8h_Level : 0
     * CO : 0.22
     * CO_Level : 1
     * NO2 : 10.15
     * NO2_Level : 1
     * PM10 : 61.75
     * PM10_Level : 1
     * SO2 : 2.1
     * SO2_Level : 1
     * O3 : 59.55
     * O3_Level : 1
     * PrimaryPollutant : PM10
     * AQI : 56
     * AQI_Level : 2
     * Quantity : 良
     */

    private String CityCode;
    private String PM2_5;
    private String PM2_5_Level;
    private String O3_8h;
    private String O3_8h_Level;
    private String CO;
    private String CO_Level;
    private String NO2;
    private String NO2_Level;
    private String PM10;
    private String PM10_Level;
    private String SO2;
    private String SO2_Level;
    private String O3;
    private String O3_Level;
    private String PrimaryPollutant;
    private String AQI;
    private String AQI_Level;
    private String Quantity;

    public String getCityCode() {
        return CityCode;
    }

    public void setCityCode(String cityCode) {
        CityCode = cityCode;
    }

    public String getPM2_5() {
        return PM2_5;
    }

    public void setPM2_5(String PM2_5) {
        this.PM2_5 = PM2_5;
    }

    public String getPM2_5_Level() {
        return PM2_5_Level;
    }

    public void setPM2_5_Level(String PM2_5_Level) {
        this.PM2_5_Level = PM2_5_Level;
    }

    public String getO3_8h() {
        return O3_8h;
    }

    public void setO3_8h(String o3_8h) {
        O3_8h = o3_8h;
    }

    public String getO3_8h_Level() {
        return O3_8h_Level;
    }

    public void setO3_8h_Level(String o3_8h_Level) {
        O3_8h_Level = o3_8h_Level;
    }

    public String getCO() {
        return CO;
    }

    public void setCO(String CO) {
        this.CO = CO;
    }

    public String getCO_Level() {
        return CO_Level;
    }

    public void setCO_Level(String CO_Level) {
        this.CO_Level = CO_Level;
    }

    public String getNO2() {
        return NO2;
    }

    public void setNO2(String NO2) {
        this.NO2 = NO2;
    }

    public String getNO2_Level() {
        return NO2_Level;
    }

    public void setNO2_Level(String NO2_Level) {
        this.NO2_Level = NO2_Level;
    }

    public String getPM10() {
        return PM10;
    }

    public void setPM10(String PM10) {
        this.PM10 = PM10;
    }

    public String getPM10_Level() {
        return PM10_Level;
    }

    public void setPM10_Level(String PM10_Level) {
        this.PM10_Level = PM10_Level;
    }

    public String getSO2() {
        return SO2;
    }

    public void setSO2(String SO2) {
        this.SO2 = SO2;
    }

    public String getSO2_Level() {
        return SO2_Level;
    }

    public void setSO2_Level(String SO2_Level) {
        this.SO2_Level = SO2_Level;
    }

    public String getO3() {
        return O3;
    }

    public void setO3(String o3) {
        O3 = o3;
    }

    public String getO3_Level() {
        return O3_Level;
    }

    public void setO3_Level(String o3_Level) {
        O3_Level = o3_Level;
    }

    public String getPrimaryPollutant() {
        return PrimaryPollutant;
    }

    public void setPrimaryPollutant(String primaryPollutant) {
        PrimaryPollutant = primaryPollutant;
    }

    public String getAQI() {
        return AQI;
    }

    public void setAQI(String AQI) {
        this.AQI = AQI;
    }

    public String getAQI_Level() {
        return AQI_Level;
    }

    public void setAQI_Level(String AQI_Level) {
        this.AQI_Level = AQI_Level;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        Quantity = quantity;
    }
}