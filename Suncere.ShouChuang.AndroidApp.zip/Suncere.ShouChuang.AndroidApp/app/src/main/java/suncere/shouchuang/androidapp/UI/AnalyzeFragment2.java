package suncere.shouchuang.androidapp.UI;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.bigkoo.pickerview.listener.CustomListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.adapter.RecyclerViewAdapter;
import suncere.androidapp.lib.adapter.ViewHolder;
import suncere.androidapp.lib.mvp.ui.baseui.MvpFragment;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.ColorUtils;
import suncere.shouchuang.androidapp.BR;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.TimeType;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.customview.OptionsPickerView2;
import suncere.shouchuang.androidapp.customview.TimePickerView2;
import suncere.shouchuang.androidapp.entity.AnalyzeItmeBean2;
import suncere.shouchuang.androidapp.entity.WeekOrSeasonBean;
import suncere.shouchuang.androidapp.presenter.BasePresenterChild;

/**
 * Created by Hjo on 2017/11/10 11:55.
 */
public class AnalyzeFragment2 extends MvpFragment<BasePresenterChild> implements IBaseView,RecyclerViewAdapter.RecyclerViewOnBindItmeView,SwipeRefreshLayout.OnRefreshListener{

    @BindView(R.id.analyze_typetime_select)
    LinearLayout analyze_typetime_select;
    @BindView(R.id.analyze_typetime_select_text)
    TextView analyze_typetime_select_text;
    @BindView(R.id.analyze_itme_select)
    LinearLayout analyze_Stationitme_select;
    @BindView(R.id.analyze_itme_select_text)
    TextView analyze_Stationitme_select_text;
    @BindView(R.id.analyze_starttime_select_text)
    TextView analyze_starttime_select_text;
    @BindView(R.id.analyze_RecyclerView)
    RecyclerView mRecyclerView;
    @BindView(R.id.analyze_SwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    @BindView(R.id.null_data)
    LinearLayout null_data;

    BasePresenterChild mBasePresenterChild;
    CustomPopWindow mSelectTimeItme;
    View mSelectTimeItmeView;
    CustomPopWindow mSelectStaionItme;
    View mSelectStationItmeView;
    RecyclerViewAdapter <AnalyzeItmeBean2>mAdapter;
    TimePickerView2 mTimePickerView;
    OptionsPickerView2 pvOptions;
    int mTimeTypeTag=4;// 4:日  5：周  6:月  7：季  8：年
    List<AnalyzeItmeBean2> mListData;
    String  mSelectItmeName="朝阳区";
    String  mSelectItmeNameId="5158dc6a-7f52-4425-89eb-df4d774b2c16";
    String  mSelectTimeType="日报";
    Date mSelectStartDate;
    Date mSelectEndDate;
    Calendar mSelectStartCalendar;
    Calendar mSelectEndCalendar;

    int mSelectStartYear;// 选择的开始年份
    int mSelectStartMonth;// 选择的开始月份
    int mSelectStartWeek;// 选择的开始星期
    int mSelectStartSeason;// 择的开始季度

    int mSelectEndYear;// 选择的结束年份
    int mSelectEndMonth;// 选择的结束月份
    int mSelectEndWeek;// 选择的结束星期
    int mSelectEndSeason;// 选择的结束季度
    int[]mSelectStartWeekPosition=new int[3]; // 开始默认选中的位置
    int[]mSelectStartSesionPosition=new int[2];
    int[]mSelectEndWeekPosition=new int[3];// 结束默认选中的位置
    int[]mSelectEndSesionPosition=new int[2];

    Calendar mRangStartDate; // 可选的开始时间
    Calendar mRangEndDate;  //  可选的结束时间
    int mStartYear; //可选的开始年份
    int mEndYear;   // 可选的结束年份
    int mEndMonth;// 可选的结束月份
    ArrayList<WeekOrSeasonBean> options1Items = new ArrayList<>();
    ArrayList<ArrayList<String>> options2MonthItems = new ArrayList<>();
    ArrayList<ArrayList<String>> options2SeasionItems = new ArrayList<>();
    ArrayList<ArrayList<ArrayList<String>>> options3WeekItems = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view =inflater.inflate(R.layout.analyze_fragment,container,false);
        ButterKnife.bind(this,view);
        initView();
        return view;
    }

    @Override
    protected BasePresenterChild createPresenter() {
        mBasePresenterChild=new BasePresenterChild(this);
        new Thread(){
            @Override
            public void run() {
                initYearData();
                initSeasonData();
                initMonthData();
                initWeekData();
            }
        }.start();
        initCustomTimePicker();
        initOptionPicker();
        Calendar calendar=Calendar.getInstance();
        String enttime=getTimeFromCalendar(calendar);
        calendar.add(Calendar.DAY_OF_MONTH,-1); // 前一天
        String starttime=getTimeFromCalendar(calendar);
        analyze_starttime_select_text.setText(starttime+"~"+enttime);
        getData();
        return mBasePresenterChild;
    }

    @Override
    public void onStart() {
        super.onStart();
    }

    private void initView(){
        mSelectTimeItmeView = LayoutInflater.from(getActivity()).inflate(R.layout.analyze_time_itme,null);
        mSelectTimeItme= new CustomPopWindow.PopupWindowBuilder(getActivity()).setView(mSelectTimeItmeView).create();
        bindSelectTimeItmeListener(mSelectTimeItmeView);

        mSwipeRefreshLayout.setColorSchemeColors(ColorUtils.Colors);
        mSwipeRefreshLayout.setOnRefreshListener(this);

        mSelectStationItmeView = LayoutInflater.from(getActivity()).inflate(R.layout.analyze_station_itme,null);
        mSelectStaionItme= new CustomPopWindow.PopupWindowBuilder(getActivity()).setView(mSelectStationItmeView).create();
        bindSelectStationItmeListener(mSelectStationItmeView);

        mListData=new ArrayList<>();
//        String time=getTimeFromCalendar(Calendar.getInstance());
//        mListData.add( new AnalyzeItmeBean(mSelectItmeName,mSelectItmeNameId,mSelectTimeType,mTimeTypeTag+"",time));

        mRangStartDate = Calendar.getInstance();
        mRangStartDate.set(2016, 0, 1);
        mRangEndDate= Calendar.getInstance();
        mStartYear=mRangStartDate.get(Calendar.YEAR);//      getIntCalendarTimeIndex(mRangStartDate,Calendar.YEAR);
        mEndYear =mRangEndDate.get(Calendar.YEAR);// (mRangEndDate,Calendar.YEAR);
        mEndMonth=mRangEndDate.get(Calendar.MONTH)+1;
        mSelectStartDate =new Date();
        mSelectEndDate=new Date();

        mAdapter=new RecyclerViewAdapter<>(getActivity(),R.layout.analyze_itme_layout2, BR.analyzeItmeBean2);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setData(mListData);
        mAdapter.setOnBindItmeView(this);
    }


    private  void  getData(){
        String []time=analyze_starttime_select_text.getText().toString().split("~");
        String  startTime=time[0];
        String  endTime=time[1];
        mBasePresenterChild.getCatchOrNetData( mBasePresenterChild.getRetrofitSrevice().analyzeData(mSelectItmeNameId,mTimeTypeTag+"",startTime,endTime) ,
                mSelectItmeNameId+mTimeTypeTag+startTime+endTime);
    }


    // 年份数据
    private void initYearData(){
        options1Items.clear();
        for (int i=mStartYear;i<=mEndYear;i++){
            options1Items.add(new WeekOrSeasonBean(i+""));
        }
        // 设置季度、星期默认选中的时间和位置  默认选择最后一个
        mSelectStartYear=Integer.valueOf(options1Items.get(options1Items.size()-1).getYear());
        mSelectEndYear =mSelectStartYear;
        mSelectStartWeekPosition[0]=options1Items.size()-1;
        mSelectStartSesionPosition[0]=options1Items.size()-1;
        mSelectEndWeekPosition[0]=options1Items.size()-1;
        mSelectEndSesionPosition[0]=options1Items.size()-1;
    }
    // 季节数据
    private void initSeasonData(){
        options2SeasionItems.clear();
        int nowSeason=mEndMonth%3==0? mEndMonth/3 : mEndMonth/3+1 ; // 余数为0 ： 3  6  9  12
        for (int i=mStartYear;i<=mEndYear;i++){
            ArrayList<String > seasons=new ArrayList<>();
            if (i!=mEndYear){
                for (int k=1;k<=4;k++){
                    seasons.add(k+"");
                }
            }else{ // 当前年份
                for (int k=1;k<=nowSeason;k++){
                    seasons.add(k+"");
                }
            }
            options2SeasionItems.add(seasons);
        }
        mSelectStartSeason=Integer.valueOf(options2SeasionItems.get(mSelectStartWeekPosition[0]).get(options2SeasionItems.get(mSelectStartWeekPosition[0]).size()-1));
        mSelectEndSeason=mSelectStartSeason;
        mSelectStartSesionPosition[1]=options2SeasionItems.get(mSelectStartWeekPosition[0]).size()-1;
        mSelectEndSesionPosition[1]=options2SeasionItems.get(mSelectStartWeekPosition[0]).size()-1;

    }
    // 月份数据
    private void initMonthData(){
        options2MonthItems.clear();
        for (int i=mStartYear;i<=mEndYear;i++){
            ArrayList <String > months=new ArrayList<>();
            if (i!=mEndYear){
                for (int k=1;k<=12;k++){
                    months.add(k+"");
                }
            }else{ // 当前年份
                for (int k=1;k<=mEndMonth;k++){
                    months.add(k+"");
                }
            }
            options2MonthItems.add(months);
        }
        mSelectStartMonth=Integer.valueOf(options2MonthItems.get(mSelectStartWeekPosition[0]).get(options2MonthItems.get(mSelectStartWeekPosition[0]).size()-1));
        mSelectEndMonth=mSelectStartMonth;
        mSelectStartWeekPosition[1]=options2MonthItems.get(mSelectStartWeekPosition[0]).size()-1;
        mSelectEndWeekPosition[1]= mSelectStartWeekPosition[1];
    }
    // 初始的星期数据
    private void initWeekData(){
        options3WeekItems.clear();

        mRangStartDate.setFirstDayOfWeek(Calendar.MONDAY);// 设置一周的开始是周一
        mRangEndDate.setFirstDayOfWeek(Calendar.MONDAY);
        for (int i=mStartYear;i<=mEndYear;i++){
            ArrayList<ArrayList<String>>monthWeek=new ArrayList<>();
            if (i!=mEndYear ){ // 不是当前年份
                for (int k=0;k<12;k++){  // 注意  需要构造日期  所以月份从0开始
                    int week=getMonthWeeks(i,k);  // 获取当前月有几周
                    ArrayList<String> weeks=new ArrayList<>();// 保存周的个数
                    for (int t=1;t<=week;t++){
                        weeks.add(t+"");
                    }
                    monthWeek.add(weeks);
                }
            }else{  // 当前年份
                for (int k=0;k<mEndMonth;k++){
                    ArrayList<String> weeks=new ArrayList<>();// 保存周的个数
                    if(k<mEndMonth-1){
                        int week=getMonthWeeks(i,k);
                        for (int t=1;t<=week;t++){
                            weeks.add(t+"");
                        }
                    }else {  // 当前月
                        int week = mRangEndDate.get(Calendar.WEEK_OF_MONTH);//获取当前日期是本月的第几周
                        for (int t=1;t<=week;t++){
                            weeks.add(t+"");
                        }
                    }
                    monthWeek.add(weeks);
                }
            }
            options3WeekItems.add(monthWeek);
        }

        ArrayList<ArrayList<String>>monthWeek=options3WeekItems.get(mSelectStartWeekPosition[0]);
        ArrayList<String> weeks=monthWeek.get(mSelectStartWeekPosition[1]);
//        mSelectStartWeek=Integer.valueOf(options3WeekItems.get(mSelectStartWeekPosition[0])// 最后一个年份
//                .get(mSelectStartWeekPosition[1])// 最后一个月份
//                .get(options3WeekItems.get(mSelectStartWeekPosition[1]).size()-1));//最后一个星期
        mSelectStartWeek=Integer.valueOf(weeks.get(weeks.size()-1));
        mSelectEndWeek=mSelectStartWeek;
        mSelectStartWeekPosition[2]=weeks.size();//options3WeekItems.get(mSelectStartWeekPosition[0]).get(options3WeekItems.get(mSelectStartWeekPosition[0]).size()-1).size()-1;
        mSelectEndWeekPosition[2]=  mSelectStartWeekPosition[2];

    }

    // 获取某年某月有几周
    private int  getMonthWeeks(int year,int month){
        Calendar calendar=Calendar.getInstance();
        calendar.set(Calendar.YEAR,year);
        calendar.set(Calendar.MONTH,month);
        calendar.setFirstDayOfWeek(Calendar.MONDAY);
        int weeks=calendar.getActualMaximum(Calendar.WEEK_OF_MONTH);  // 获取当前月有几周
        return weeks;
    }

    @Override
    public void onRefresh() {
        getData();
    }

    @Override
    public void getDataSuccess(Object response) {
        mListData.clear();
        if (response!=null) {
            mListData.addAll((List<AnalyzeItmeBean2>) response);
        }
        if (mListData.size()>0){
            null_data.setVisibility(View.GONE);
        }else{
            null_data.setVisibility(View.VISIBLE);
        }
        mAdapter.setData(mListData);
    }
    @Override
    public void getDataFail(String msg) {

    }
    @Override
    public void showRefresh() {
        mSwipeRefreshLayout.setRefreshing(true);
    }

    @Override
    public void finishRefresh() {
        mSwipeRefreshLayout.setRefreshing(false);
    }

    @OnClick({R.id.analyze_typetime_select,R.id.analyze_itme_select,R.id.analyze_starttime_select})//,R.id.analyze_endtime_select
    public void on_onclick(View view){
        switch (view.getId()){
            case R.id.analyze_typetime_select:
//                startActivity(new Intent(getActivity(),AnalyzePreViewActivity.class));
                showSelectTimeItme();
                break;
            case R.id.analyze_itme_select:
                showSelectStationItme();
                break;
            case R.id.analyze_starttime_select:
                if (mTimeTypeTag!=TimeType.WeekTime.getIndex() && mTimeTypeTag !=TimeType.SeasonTime.getIndex()){
                    final boolean  isMonth=mTimeTypeTag== TimeType.DayTime.getIndex() || mTimeTypeTag== TimeType.MonthTime.getIndex();
                    final boolean  isDay=mTimeTypeTag== TimeType.DayTime.getIndex();
                    mTimePickerView.setViewVisibility(new boolean[]{true, isMonth,isDay , false, false, false});
                    mTimePickerView.setDate(mSelectStartCalendar,mSelectEndCalendar);
                    mTimePickerView.show();
                } else{
                    if (mTimeTypeTag==TimeType.WeekTime.getIndex()){
                        pvOptions.setLabel("年","月","周");
                        pvOptions.setSelectOptions(mSelectStartWeekPosition[0],mSelectStartWeekPosition[1],mSelectStartWeekPosition[2],
                                mSelectEndWeekPosition[0],mSelectEndWeekPosition[1],mSelectEndWeekPosition[2]);
                        pvOptions.setPicker(options1Items, options2MonthItems,options3WeekItems);
                    } else{
                        pvOptions.setLabel("年","季","");
                        pvOptions.setSelectOptions(mSelectStartSesionPosition[0],mSelectStartSesionPosition[1],
                                mSelectEndSesionPosition[0],mSelectEndSesionPosition[1]);
                        pvOptions.setPicker(options1Items, options2SeasionItems);
                    }
                    pvOptions.show();
                }
                break;
        }
    }

    private void initCustomTimePicker() {

        if (mSelectStartCalendar==null)mSelectStartCalendar=mRangEndDate;
        if (mSelectEndCalendar==null)mSelectEndCalendar=mRangEndDate;
        analyze_starttime_select_text.setText(getTimeFromCalendar (mSelectStartCalendar)+"~"+getTimeFromCalendar (mSelectEndCalendar));
        //时间选择器 ，自定义布局
        mTimePickerView = new TimePickerView2.Builder(getActivity(), new TimePickerView2.OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date,Date date2 ,View v) {//选中事件回调
                Calendar calendar1   =Calendar.getInstance();
                calendar1.setTime(date);
                mSelectStartCalendar=calendar1;

                Calendar calendar2   =Calendar.getInstance();
                calendar2.setTime(date2);
                mSelectEndCalendar=calendar2;
                mSelectStartDate=date;
                mSelectEndDate=date2;
                analyze_starttime_select_text.setText(getTimeFromCalendar (mSelectStartCalendar)+"~"+getTimeFromCalendar (mSelectEndCalendar));
                getData();
            }
        }).setDate(mSelectStartCalendar)
                .setDate2(mSelectEndCalendar)
                .setRangDate(mRangStartDate, mRangEndDate)
                .setLayoutRes(R.layout.pickerview_custom_time2, new CustomListener() {
                    @Override
                    public void customLayout(View v) {
                        final TextView tvSubmit = (TextView) v.findViewById(R.id.tv_finish);
                        ImageView ivCancel = (ImageView) v.findViewById(R.id.iv_cancel);
                        tvSubmit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mTimePickerView.returnData();
                                mTimePickerView.dismiss();
                            }
                        });
                        ivCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                mTimePickerView.dismiss();
                            }
                        });
                    }
                })
                .setContentSize(18)
//                .setType(new boolean[]{true, isMonth,isDay , false, false, false})
                .setLabel("年", "月", "日", "", "", "")
                .setLineSpacingMultiplier(1.8f)
                .setTextXOffset(0, 0, 0, 40, 0, -40)
                .isCenterLabel(false)
                .setDividerColor(0xFF24AD9D)
                .build();
    }
    private void initOptionPicker() { //条件选择器初始化
        pvOptions = new OptionsPickerView2.Builder(getActivity(), new OptionsPickerView2.OnOptionsSelectListener() {
            @Override
            public void onOptionsSelect(int []po, int[] op2, View v) {
                // 注意 ：如果是三级联动的数据(省市区等)，请参照 JsonDataActivity 类里面的写法。
                //返回的分别是三个级别的选中位置
                mSelectStartYear=Integer.valueOf(options1Items.get(po[0]).getPickerViewText());
                mSelectEndYear=Integer.valueOf(options1Items.get(op2[0]).getPickerViewText());

                if (mTimeTypeTag==TimeType.WeekTime.getIndex()){
                    mSelectStartWeekPosition=po;
                    mSelectEndWeekPosition=op2;
                    mSelectStartMonth=Integer.valueOf(options2MonthItems.get(po[0]).get(po[1]));
                    mSelectEndMonth=Integer.valueOf( options2MonthItems.get(op2[0]).get(op2[1]));
                    mSelectStartWeek=Integer.valueOf(options3WeekItems.get(po[0]).get(po[1]).get(po[2]));
                    mSelectEndWeek=Integer.valueOf(options3WeekItems.get(op2[0]).get(op2[1]).get(op2[2]));
                    String tx1 =  mSelectStartYear+"/"+ mSelectStartMonth  +"-"+ mSelectStartWeek;
                    String tx2 = mSelectEndYear  +"/"+ mSelectEndMonth +"-"+ mSelectEndWeek;
                    analyze_starttime_select_text.setText(tx1+"~"+tx2);
//                    getData(tx1,tx2);
                    getData();
//                    changeItmeDataFormWeek();
                }else if (mTimeTypeTag==TimeType.SeasonTime.getIndex()){
                    mSelectStartSesionPosition=po;
                    mSelectEndSesionPosition=op2;
                    mSelectStartSeason=Integer.valueOf( options2SeasionItems.get(po[0]).get(po[1]));
                    mSelectEndSeason=Integer.valueOf( options2SeasionItems.get(op2[0]).get(op2[1]));
                    String tx1 = mSelectStartYear  +"-"+mSelectStartSeason ;
                    String tx2 =mSelectEndYear +"-"+mSelectEndSeason;
                    analyze_starttime_select_text.setText(tx1+"~"+tx2);
//                    getData(tx1,tx2);
                    getData();
//                    changeItmeDataFormSeason();
                }
            }
        })
                .setTitleText("")
                .setContentTextSize(18)//设置滚轮文字大小
                .setDividerColor(Color.LTGRAY)//设置分割线的颜色
                .setSelectOptions(0, 1)//默认选中项
                .setBgColor(Color.WHITE)
                .setTitleBgColor(Color.WHITE)
                .setTitleColor(Color.LTGRAY)
                .setCancelColor(Color.BLACK)
                .setSubmitColor(Color.BLACK)
                .setTextColorCenter(Color.BLACK)
                .setLayoutRes(R.layout.pickerview_custom_time3, new CustomListener() {
                    @Override
                    public void customLayout(View v) {
                        final TextView tvSubmit = (TextView) v.findViewById(R.id.tv_finish);
                        ImageView ivCancel = (ImageView) v.findViewById(R.id.iv_cancel);
                        tvSubmit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                pvOptions.returnData();
                                pvOptions.dismiss();
                            }
                        });
                        ivCancel.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                pvOptions.dismiss();
                            }
                        });
                    }
                })
                .setLineSpacingMultiplier(1.8f)
                .isCenterLabel(false) //是否只显示中间选中项的label文字，false则每项item全部都带有label。
                .setLabels("", "", "")
                .setBackgroundId(0x66000000) //设置外部遮罩颜色
                .build();
    }

    private String getTimeFromCalendar(Calendar calendar) {  //可根据需要自行截取数据显示
        String yearStr=calendar.get(Calendar.YEAR)+"";
        String monthStr="";
        String dayStr="";
        String time=yearStr;
        if (mTimeTypeTag== TimeType.DayTime.getIndex() || mTimeTypeTag== TimeType.MonthTime.getIndex()){
            monthStr=calendar.get(Calendar.MONTH)+1+"";
            time=time+"/"+monthStr;
        }
        if (mTimeTypeTag== TimeType.DayTime.getIndex()){
            dayStr=calendar.get(Calendar.DATE)+"";
            time=time+"/"+dayStr;
        }
        return time  ;
    }

    private void showSelectTimeItme(){
        mSelectTimeItme .showAsDropDown(analyze_typetime_select,0,10);
    }
    /**
     * 处理弹出显示内容、点击事件等逻辑
     * @param contentView
     */
    private void bindSelectTimeItmeListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mSelectTimeItme!=null){
                    mSelectTimeItme.dissmiss();
                }
                mSelectTimeType=((TextView)v).getText().toString();
                analyze_typetime_select_text.setText(mSelectTimeType);
                mTimeTypeTag= Integer.valueOf( v.getTag().toString());
                if (mTimeTypeTag!=TimeType.WeekTime.getIndex() && mTimeTypeTag !=TimeType.SeasonTime.getIndex()){
                    analyze_starttime_select_text.setText(getTimeFromCalendar (mSelectStartCalendar)+"~"+getTimeFromCalendar (mSelectEndCalendar));
                    getData();
//                    getData(getTimeFromCalendar (mSelectStartCalendar),getTimeFromCalendar (mSelectEndCalendar));
//                    changeItemDataFormTime();
                }else{
                    if (mTimeTypeTag==TimeType.WeekTime.getIndex()){  // 周
                        String tx1 =  mSelectStartYear+"/"+ mSelectStartMonth  +"-"+ mSelectStartWeek;
                        String tx2 = mSelectEndYear  +"/"+ mSelectEndMonth +"-"+ mSelectEndWeek;
                        analyze_starttime_select_text.setText(tx1+"~"+tx2);
                        getData();

//                        getData(tx1,tx2);
//                        changeItmeDataFormWeek();
                    }else{  // 季度
                        String tx1 = mSelectStartYear  +"-"+mSelectStartSeason ;
                        String tx2 =mSelectEndYear +"-"+mSelectEndSeason;
                        analyze_starttime_select_text.setText(tx1+"~"+tx2);
                        getData();
//                        getData(tx1,tx2);
//                        changeItmeDataFormSeason();
                    }
                }
            }
        };
        contentView.findViewById(R.id.analyze_day).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_week).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_month).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_season).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_year).setOnClickListener(listener);

    }

    private void showSelectStationItme(){
        mSelectStaionItme .showAsDropDown(analyze_Stationitme_select,0,10);
    }
    private void bindSelectStationItmeListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mSelectStaionItme!=null){
                    mSelectStaionItme.dissmiss();
                }
                mSelectItmeName=((TextView)v).getText().toString();
                mSelectItmeNameId=v.getTag().toString();
                analyze_Stationitme_select_text.setText(mSelectItmeName);

                getData();
//                changeItemDataFormStationName();
            }
        };
        contentView.findViewById(R.id.analyze_chaoyangqu).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_shunyiqu).setOnClickListener(listener);
        contentView.findViewById(R.id.analyze_shijingshan).setOnClickListener(listener);
    }

    @Override
    public void OnBindItmeView(View view, Object obejct, final int position, int selectPosition, int tag) {
        RelativeLayout relativeLayout= ViewHolder.getView(view,R.id.analyze_itme_preview_rela);
        relativeLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AnalyzeItmeBean2 bean= mListData.get(position);
                Intent intent=new Intent(getActivity(),AnalyzePreViewActivity.class);
                intent.putExtra("Id",bean.getId());
                startActivity(intent);
            }
        });
    }


}
