package suncere.shouchuang.androidapp.UI;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import suncere.androidapp.lib.adapter.RecyclerViewAdapter;
import suncere.androidapp.lib.customview.PollutantNameTextView;
import suncere.androidapp.lib.mvp.entity.BaseBean;
import suncere.androidapp.lib.mvp.ui.baseui.MvpActivity;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.utils.ColorUtils;
import suncere.shouchuang.androidapp.BR;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.ListSort;
import suncere.shouchuang.androidapp.Utils.ToolUtils;
import suncere.shouchuang.androidapp.customview.CustomPopWindow;
import suncere.shouchuang.androidapp.entity.AllCityBean;
import suncere.shouchuang.androidapp.entity.ListBean;
import suncere.shouchuang.androidapp.presenter.HomePresenter;

/**
 * Created by Hjo on 2017/11/14 20:33.
 */

public class HomeCityStationActivity extends MvpActivity<HomePresenter> implements IBaseView ,SwipeRefreshLayout.OnRefreshListener,
        RecyclerViewAdapter.RecyclerViewOnBindItmeView,RecyclerViewAdapter.RecyclerViewOnItmeClickListener{

    @BindView(R.id.home_cityStation_SwipeRefreshLayout)
    SwipeRefreshLayout mSwipeRefreshLayout;

    @BindView(R.id.home_cityStation_recyclerview)
    RecyclerView mRecyclerView;

    @BindView(R.id.home_cityStation_select_pollutant)
    PollutantNameTextView mpollutantItme;
    @BindView(R.id.home_cityStation_UpOrDown_image)
    ImageView mUpOrDown_image;
    @BindView(R.id.home_station_title_name)
    TextView mtitle_name;
    @BindView(R.id.home_cityStation_select_Station)
    TextView mselect_Station;

    @BindView(R.id.home_cityStation_time)
    TextView mcityStation_time;

    @BindView(R.id.null_data)
    LinearLayout null_data;

    @BindView(R.id.home_cityStation_pollutant)
    PollutantNameTextView home_cityStation_title_pollutant;

    RecyclerViewAdapter<ListBean>mAdapter;
    RecyclerViewAdapter<AllCityBean>mStationAdapter;
    HomePresenter mBasePresenterChild;
    CustomPopWindow mSelectPollutantPopWindow;
    CustomPopWindow mSelectStationNamePopWindow;
    String mPollutantName="AQI";
    String mCityCode;
    String mStationCode;
    String mCityName;
    String mStationName;
    String mReportTimeType;

    View mSelectPollutantView;
    View mSelectStationNameView;

    List<ListBean>mlistCityData;
    List<AllCityBean>mAllCityBeanData;
    boolean isUpOrDown=true;// true 为正序
    RecyclerView mSelectStationNameRecyclerView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.home_citystation_activity);
        ButterKnife.bind(this);
        initView();
    }


    @Override
    protected void onStart() {
        super.onStart();
        getData();
        getAllStation();
    }

    @Override
    protected HomePresenter createPresenter() {
        mBasePresenterChild=new HomePresenter(this);
        return mBasePresenterChild;
    }

    private void initView(){
        mAdapter=new RecyclerViewAdapter<>(this,R.layout.home_citylist_recyclerview_itme, BR.listCityData);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mRecyclerView.setAdapter(mAdapter);
        mSwipeRefreshLayout.setColorSchemeColors(ColorUtils.Colors);
        mSwipeRefreshLayout.setOnRefreshListener(this);
        Intent intent=getIntent();
        mCityCode=intent.getStringExtra("CityCode");
        mStationCode=intent.getStringExtra("DefaultStationCode");
        mReportTimeType=intent.getStringExtra("ReportTimeType");
        mCityName=intent.getStringExtra("CityName");
        mStationName=intent.getStringExtra("StationName");
        mselect_Station.setText(mStationName);
//        CityName=intent.getStringExtra("CityName");

        mlistCityData=new ArrayList<>();
        mAllCityBeanData=new ArrayList<>();

        // 选择污染物列表
        mSelectPollutantView = LayoutInflater.from(this).inflate(R.layout.map_chart_pollutant_itme,null);
        bindSelectPollutantListener(mSelectPollutantView);
        if ("3".equals(mReportTimeType)){
           mtitle_name.setText(mCityName+"各项目所在区站点实时数据");
            ((PollutantNameTextView)(mSelectPollutantView.findViewById(R.id.O3))).setText("O3");
        }
        mSelectPollutantPopWindow= new CustomPopWindow.PopupWindowBuilder(this).setView(mSelectPollutantView).create();

        // 选择站点列表
        mStationAdapter=new RecyclerViewAdapter<>(this,R.layout.home_citystation_nameselect_itme,BR.allCityBean);
        mStationAdapter.setOnItmeClickListener(this);
        mSelectStationNameView =LayoutInflater.from(this).inflate(R.layout.home_citystation_nameselect_recyclerview,null,false);
        mSelectStationNameRecyclerView=mSelectStationNameView.findViewById(R.id.home_cityStation_select_recyclerview);
        mSelectStationNameRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mSelectStationNameRecyclerView.setAdapter(mStationAdapter);
    }

    private void getData(){
        if ("PM2.5".equals(mPollutantName))mPollutantName="PM2_5";
        mBasePresenterChild.getCatchOrNetData(mBasePresenterChild.getRetrofitSrevice().listStation(mStationCode,mReportTimeType,mPollutantName),
                mStationCode+mReportTimeType+mPollutantName);
    }

    private void getAllStation(){ // 只取北京市下的站点
        mBasePresenterChild.getAllcity(mBasePresenterChild.getRetrofitSrevice().
                allStation(mCityCode,"3"),mCityCode);
    }
    @Override
    public void getDataSuccess(Object response) {
        mlistCityData.clear();
        if (response!=null){
            List<BaseBean>list= (List<BaseBean>) response;
            if (list.size()>0&& list.get(0) instanceof ListBean){
                mlistCityData.addAll((List< ListBean>) response);
               if(null_data.getVisibility()==View.VISIBLE) null_data.setVisibility(View.GONE);
                mcityStation_time.setText(ToolUtils.getLastTimeHour()+"更新");
            }else if (list.size()>0&& list.get(0) instanceof AllCityBean){
                mAllCityBeanData.clear();
                mAllCityBeanData.addAll((List< AllCityBean>) response);
                mStationAdapter.setData(mAllCityBeanData);
            }
        }
//        else{
//            null_data.setVisibility(View.VISIBLE);
//        }
        findCity2Frist();
    }

    private void findCity2Frist(){
        Collections.sort(mlistCityData,new ListSort(isUpOrDown));
        mAdapter.setData(mlistCityData);
        if (mlistCityData.size()==0) {
            if(null_data.getVisibility()==View.GONE)null_data.setVisibility(View.VISIBLE);
        }
        mSwipeRefreshLayout.setRefreshing(false);
    }

    @OnClick({R.id.home_cityStation_select_pollutant,R.id.home_cityStation_top_back,R.id.home_cityStation_UpOrDown,R.id.home_cityStation_select_Station})
    public void  on_click(View view ){
        switch (view.getId()){
            case R.id.home_cityStation_select_pollutant:
                showSelectPollutant();
                break;
            case R.id.home_cityStation_top_back:
                finish();
                break;
            case R.id.home_cityStation_UpOrDown:
                isUpOrDown=!isUpOrDown;
                if (isUpOrDown){
                    mUpOrDown_image.setImageResource(R.mipmap.list_up);
                }else{
                    mUpOrDown_image.setImageResource(R.mipmap.list_down);
                }
                findCity2Frist();
                break;
            case R.id.home_cityStation_select_Station:
                showSelectStationName();
                break;
        }
    }

    private void showSelectPollutant(){
        mSelectPollutantPopWindow .showAsDropDown(mpollutantItme,6,-(mpollutantItme.getHeight()+mSelectPollutantPopWindow.getHeight()));
    }

    /**
     * 处理弹出显示内容、点击事件等逻辑
     * @param contentView
     */
    private void bindSelectPollutantListener(View contentView){
        View.OnClickListener listener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(mSelectPollutantPopWindow!=null){
                    mSelectPollutantPopWindow.dissmiss();
                }
                mPollutantName=((TextView)v).getText().toString();
                mpollutantItme.setText(mPollutantName);
                home_cityStation_title_pollutant.setText(mPollutantName);
                getData();
            }
        };
        contentView.findViewById(R.id.AQI).setOnClickListener(listener);
        contentView.findViewById(R.id.SO2).setOnClickListener(listener);
        contentView.findViewById(R.id.NO2).setOnClickListener(listener);
        contentView.findViewById(R.id.CO).setOnClickListener(listener);
        contentView.findViewById(R.id.O3).setOnClickListener(listener);
        contentView.findViewById(R.id.PM2_5).setOnClickListener(listener);
        contentView.findViewById(R.id.PM10).setOnClickListener(listener);
    }

    private void showSelectStationName(){
        mSelectStationNamePopWindow= new CustomPopWindow.PopupWindowBuilder(this).setView(mSelectStationNameView).create();
        mSelectStationNamePopWindow .showAsDropDown(mselect_Station,2,-(mselect_Station.getHeight()+mSelectStationNamePopWindow.getHeight()));
    }


    @Override
    public void onRefresh() {
        getData();
    }
    @Override
    public void showRefresh() {
        mSwipeRefreshLayout.setRefreshing(true);
    }

    @Override
    public void finishRefresh() {
//        mSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void getDataFail(String msg) {

    }


    @Override
    public void OnBindItmeView(View view, Object obejct, int position, int selectPosition, int tag) {
        if (position==0){
            view.setBackgroundColor(Color.parseColor("#D0E8F4"));
        }
    }

    @Override
    public void OnItemClick(Object obejct, int position, int tag) {
        mStationCode=mAllCityBeanData.get(position).getId();
        mselect_Station.setText(mAllCityBeanData.get(position).getName());
        mSelectStationNamePopWindow.dissmiss();
        getData();
    }
}
