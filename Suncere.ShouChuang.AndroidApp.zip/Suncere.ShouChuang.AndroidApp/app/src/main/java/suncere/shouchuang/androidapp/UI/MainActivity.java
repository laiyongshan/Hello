package suncere.shouchuang.androidapp.UI;

import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;

import suncere.androidapp.lib.customview.TabBar;
import suncere.androidapp.lib.mvp.ui.MyApplication;
import suncere.androidapp.lib.mvp.ui.baseui.MvpActivity;
import suncere.androidapp.lib.mvp.ui.iview.IBaseView;
import suncere.androidapp.lib.updataapp.UpdateManager;
import suncere.androidapp.lib.utils.StatusBarUtil;
import suncere.shouchuang.androidapp.R;
import suncere.shouchuang.androidapp.Utils.LeakCanaryUtil;
import suncere.shouchuang.androidapp.presenter.UpDataAPPPresenter;


public class MainActivity extends MvpActivity<UpDataAPPPresenter> implements IBaseView {

    TabBar mTabBar;
    UpDataAPPPresenter mUpDataAPPPresenter; // 更新APP

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        StatusBarUtil.setTranslucentForImageViewInFragment(this ,50, null);// 默认透明度为50
        initView();
    }

    @Override
    protected UpDataAPPPresenter createPresenter() {
        mUpDataAPPPresenter=new UpDataAPPPresenter(this);
        mUpDataAPPPresenter.updataAPP(MyApplication.getMyApplicationVersionName());
        return mUpDataAPPPresenter;
    }

    private void initView(){
        mTabBar= (TabBar) findViewById(R.id.tabbar);
        mTabBar.mTextVTitleArray = new String[]{"首页","地图","分析","报警","我的"};
        mTabBar.mSelectTextColor= Color.parseColor("#0F91FF");
        mTabBar.mUnSelectTextColor=Color.parseColor("#666666");
        mTabBar.mTabBarViewBackgroundColor=Color.parseColor("#102834");
        mTabBar.mSelectImageVIconArray = new int[]{R.mipmap.home_s,R.mipmap.map_s,R.mipmap.analyze_s,R.mipmap.warn_s,R.mipmap.my_s};
        mTabBar.mUnSelectImageVIconArray = new int[]{R.mipmap.home_u,R.mipmap.map_u,R.mipmap.analyze_u,R.mipmap.warn_u,R.mipmap.my_u};
        mTabBar.mTabFragmentClassArray = new Class<?>[]{HomeFragment.class,MapFragment.class,AnalyzeFragment2.class,WarnFragment.class,SetFragment.class};
//        mTabBar.mDefaultSelectIndex=1;
        mTabBar.refreshTabBar();
//        mTabBar.SwitchTabBar(0);
    }


    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            ShowExitAPP();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public void showRefresh() {

    }

    @Override
    public void getDataSuccess(Object response) {
        if (response != null) {
            String downloadUrl = response.toString();
            if (downloadUrl.startsWith("http") && downloadUrl.endsWith(".apk"))
                new UpdateManager(this).checkUpdate(downloadUrl);
        }
    }

    @Override
    public void getDataFail(String msg) {

    }

    @Override
    public void finishRefresh() {

    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        LeakCanaryUtil.fixMemoryLeak(this);
        if (mTabBar!=null){
            mTabBar=null;
        }
    }


}
